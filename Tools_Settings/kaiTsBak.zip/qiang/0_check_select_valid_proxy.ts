import {KaiLog} from "../utils/kai_log.js";
import minimist from "minimist";
import inquirer from "inquirer";
import Config from "./config.js";
import chalk from "chalk";
import {KaiUtils} from "../utils/kai_utils.js";
import {RestfulApi, RpcInterface} from "./restful_api.js";

interface RegularInterface {
    regularName: string
    selectorName: string
    proxyNameRegularList: string[]
}

export class CheckSelect {
    rpc: RpcInterface
    regular: RegularInterface
    api: RestfulApi

    constructor(rpc: RpcInterface, regular: RegularInterface) {
        this.rpc = rpc
        this.regular = regular
        this.api = new RestfulApi(rpc)
    }

    async checkValid() {
        const curSelectorInfo = await KaiUtils.asyncInsureExecute(() => this.api.getProxies(this.regular.selectorName));
        // KaiLog.log(`curSelectorInfo, selector name: ${curSelectorInfo.name} now=${curSelectorInfo.now}`);
        const delayMs = await KaiUtils.asyncInsureExecute(() => this.api.getDelay(this.regular.selectorName));
        if (delayMs >= RestfulApi.DELAY_TIMEOUT_MS) {
            KaiLog.log(`current selector name: '${curSelectorInfo.name}' proxy: '${curSelectorInfo.now}' delay: timout`)
        } else {
            KaiLog.log(`current selector name: '${curSelectorInfo.name}' proxy: '${curSelectorInfo.now}' delay: ${delayMs} ms`)
        }
        return delayMs < RestfulApi.DELAY_TIMEOUT_MS;
    }

    async selectValidProxy() {
        const targetProxyList = await this.getMatchRegularProxyName()
        // KaiLog.log(`name match len=${targetProxyList.length}`, targetProxyList);
        const delayList = await Promise.all(targetProxyList.map((proxyName => KaiUtils.asyncInsureExecute(() => this.api.getDelay(proxyName)))))
        // KaiLog.log(`delay result, len=${delayList.length}`, delayList);
        let minDelayIndex = 9999999, minDelay = 9999999;
        for (let delayIdx = 0; delayIdx < delayList.length; ++delayIdx) {
            if (delayList[delayIdx] < minDelay) {
                minDelayIndex = delayIdx;
                minDelay = delayList[delayIdx];
            }
        }
        if (minDelay >= RestfulApi.DELAY_TIMEOUT_MS) {
            KaiLog.log(chalk.red('no valid proxy.'))
            return
        }
        KaiLog.log(`will switch proxy to ${targetProxyList[minDelayIndex]}, delay is ${minDelay} ms`)
        await KaiUtils.asyncInsureExecute(() => this.api.putProxies(this.regular.selectorName, targetProxyList[minDelayIndex]));
    }

    async getMatchRegularProxyName(): Promise<string[]> {
        const allProxyListResult = await KaiUtils.asyncInsureExecute(() => this.api.getProxies());
        const allProxyObj = allProxyListResult['proxies'];
        const proxyKeys = Object.keys(allProxyObj);
        // KaiLog.log(`allProxyList len=${proxyKeys.length}`);
        const targetProxyList = []
        for (let proxyKey of proxyKeys) {
            let proxyName: string = allProxyObj[proxyKey].name;
            if (proxyName != null && this.proxyNameMatchRegular(proxyName)) {
                targetProxyList.push(proxyName);
            }
        }
        return targetProxyList;
    }

    proxyNameMatchRegular(name: string) {
        const regularList = this.regular.proxyNameRegularList;
        return regularList.every(regular => {
            const subRegularList = regular.split("or");
            return subRegularList.some(subRegular => name.indexOf(subRegular) >= 0);
        });
    }



    async updateYamlFile() {
        let status = this.api.localYmlFileStatus();
        if (status < 0) {
            KaiLog.log(chalk.red("yml file not exist or error format."))
        } else if (status >= 7) {
            // 超过7天，可以更新下
            let ymlFileContent = await this.api.getYamlFile("https://www.baidu.com/");
            if (ymlFileContent == null) {
                KaiLog.log(chalk.red("download yaml file failed."))
            } else {
                KaiLog.log(`download yaml success, update time: ${this.api.getUpdateDateTime(ymlFileContent)}`)
                // KaiFile.writeFileSync("local_path", ymlFileContent);
                // 是否需要触发个更新通知工具？ 能立即get proxies为新的吗？
            }
        }
    }
}

async function doSth() {
    const argObj = minimist(process.argv.slice(2))
    const rpcName = argObj['rpc'] ?? await getRpcName()
    const regularName = argObj['regular'] ?? await getRegularName()
    const targetRpcList = Config.rpcList.filter(value => value.rpcName === rpcName)
    const targetRegularList = Config.regularList.filter(value => value.regularName === regularName)
    if (targetRpcList.length <= 0) {
        KaiLog.log(`rpc name not exits, ${chalk.red(rpcName)}`);
        return
    }
    if (targetRegularList.length <= 0) {
        KaiLog.log(`regular name not exits, ${chalk.red(regularName)}`);
        return
    }
    KaiLog.log(`you choose rpcName=${rpcName} regularName=${regularName}`)



    const checkSelect = new CheckSelect(targetRpcList[0], targetRegularList[0]);
    const targetProxyList = await checkSelect.getMatchRegularProxyName();
    KaiLog.log(`preview target proxy, len=${targetProxyList.length}`, targetProxyList);

    // await checkSelect.updateYamlFile();
    // return;

    while (true) {
        if (await checkSelect.checkValid()) {
            KaiLog.log('selector proxy can use, ignore select other proxy.')
        } else {
            await checkSelect.selectValidProxy()
        }
        await KaiUtils.sleep(15 * 60 * 1000) // 15分钟
    }
}

async function getRpcName() {
    const rpcNameChoiceList = Config.rpcList.map(data => {
        return {name: data.rpcName, value: data.rpcName}
    });

    const rpcUrlResult = await inquirer.prompt([{
        type: "rawlist",
        message: "请选择使用哪个rpc",
        name: "rpc",
        choices: rpcNameChoiceList
    }])
    return rpcUrlResult.rpc
}


async function getRegularName() {
    const nameChoiceList = Config.regularList.map(data => {
        return {name: data.proxyNameRegularList, value: data.regularName}
    });

    const rpcUrlResult = await inquirer.prompt([{
        type: "rawlist",
        message: "请选择使用哪个proxyName",
        name: "name",
        choices: nameChoiceList
    }])
    return rpcUrlResult.name
}

doSth().then(r => {
    KaiLog.log('\n脚本结束')
})
