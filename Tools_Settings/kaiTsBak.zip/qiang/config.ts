const Config = {
    rpcList: [
        {
            rpcName: "mac2019",
            ipPort: "127.0.0.1:49920",
            secret: "2213de11-5484-468f-8798-554caeabe4a4",
            ymlPath: "~/.config/clash/profiles/1704299178535.yml",
        }
    ],
    regularList: [
        {
            regularName: "hk_1",
            selectorName: "🚀 节点选择",
            proxyNameRegularList: ["香港", "联通or移动"]
        },
        {
            regularName: "hk_zx",
            selectorName: "🚀 节点选择",
            proxyNameRegularList: ["香港", "专线"]
        },
    ]
}
export default Config;
