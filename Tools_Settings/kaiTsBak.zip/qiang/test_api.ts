import {KaiLog} from "../utils/kai_log.js";
import Config from "./config.js";
import {RestfulApi} from "./restful_api.js";

async function doSth() {
    const rpc = Config.rpcList.filter(value => value.rpcName === 'mac2019')[0]
    let api = new RestfulApi(rpc);
    let responseJson = await api.getConfigs();
    KaiLog.log(`getConfigs`, responseJson)
    responseJson = await api.getRules();
    // KaiLog.log(`getRules`, responseJson)
    // responseJson = await api.getTraffic(); //流式接口，每秒推一个json表示上下行流量
    // KaiLog.log(`getTraffic`, responseJson)
    // responseJson = await api.getLogs(); // 也是流式接口
    // KaiLog.log(`getLogs`, responseJson)

    responseJson = await api.getProxies();
    const proxies = responseJson['proxies'];
    // KaiLog.log(`getProxies`, responseJson)
    let keys = Object.keys(proxies);
    // KaiLog.log(`getProxies keys=`, keys)
    const nameList = [];
    for (let proxyKey of keys) {
        if (proxies[proxyKey].name != null) {
            nameList.push(proxies[proxyKey].name);
        }
    }
    KaiLog.log(`proxies name list count=${nameList.length}`, nameList)
    responseJson = await api.getProxies(nameList[0]);
    KaiLog.log(`proxy name 0 info`, responseJson)
    responseJson = await api.getProxies(nameList[8]);
    KaiLog.log(`proxy name 8 info`, responseJson)
    responseJson = await api.getDelay(nameList[8]);
    KaiLog.log(`delay name 8 info`, responseJson)
    responseJson = await api.getVersion();
    KaiLog.log(`version info`, responseJson)

    // const selectorName = 📢 谷歌FCM';
    // const proxyName1 = '🚀 节点选择';
    // const proxyName2 = '上海联通转台湾HiNet[M][Trojan][倍率:1]';
    // responseJson = await api.getProxies(selectorName);
    // KaiLog.log(`proxy ${selectorName} info:`, responseJson.now)
    // const useProxyName = responseJson.now === proxyName1 ? proxyName2 : proxyName1
    // responseJson = await api.putProxies(selectorName, useProxyName);
    // // KaiLog.log(`put proxies`, responseJson)
    // responseJson = await api.getProxies(selectorName);
    // KaiLog.log(`proxy ${selectorName} info2:`, responseJson.now)

    const invalidProxyName = '佛山移动转香港BGP2[M][Trojan][倍率:0.8]';
    const testSelectorName = 'Ⓜ️ 微软服务';
    responseJson = await api.getDelay(invalidProxyName);
    KaiLog.log(`delay ${invalidProxyName} info`, responseJson)

    responseJson = await api.getDelay(testSelectorName);
    KaiLog.log(`delay ${testSelectorName} info`, responseJson)

    // await api.putProxies(testSelectorName, invalidProxyName);
    // responseJson = await api.getDelay(testSelectorName);
    // KaiLog.log(`delay ${testSelectorName} info`, responseJson)

}

async function doSth2() {
    const rpc = Config.rpcList.filter(value => value.rpcName === 'mac2019')[0]
    let api = new RestfulApi(rpc);
    let dateTime = api.getUpdateDateTime("#!MANAGED-CONFIG http://www.xxxx.com\n" +
        "\n" +
        "#---------------------------------------------------#\n" +
        "## 上次更新于：2024-06-24 23:53:18\n" +
        "#---------------------------------------------------#\n" +
        "\n" +
        "port: 7890\n" +
        "socks-port: 7891")
    KaiLog.log(`dateTime=${dateTime}`)
    KaiLog.log(`ymlFileStatus=${api.localYmlFileStatus()}`)
}

// doSth().then(r => {
//     KaiLog.log('\n脚本结束')
// })

doSth2().then(r => {
    KaiLog.log('\n脚本结束')
})

