import {KaiHttpUtils} from "../utils/kai_http_utils.js";
import {KaiStr} from "../utils/kai_string_utils.js";
import {KaiLog} from "../utils/kai_log.js";
import {KaiFile} from "../utils/kai_file_utils.js";
import fs from "fs";
import moment from "moment";

export interface RpcInterface {
    rpcName: string
    ipPort: string
    secret: string
    ymlPath: string
}

export class RestfulApi {

    static DELAY_TIMEOUT_MS = 99999; //ms
    rpc: RpcInterface

    constructor(rpc: RpcInterface) {
        this.rpc = rpc
    }

    /*
    name 如果为空获取所有 (大小写敏感)
    { // 单个
  history: [],
  name: '上海联通转日本BGP2[M][Trojan][倍率:0.8]',
  type: 'Trojan',
  udp: true
}
     */
    async getProxies(name?: string): Promise<any> {
        let url = `http://${this.rpc.ipPort}/proxies`;
        if (KaiStr.isNotEmptyString(name)) {
            url += '/' + name
        }
        // KaiLog.log('get ' + url);
        let response = await KaiHttpUtils.fetch(url, this.getFetchOptions());
        // if (response.status !== 200) {
        //     throw `${response.url} : ${response.status} ${response.text}`
        // }
        return response.json();
    }

    async putProxies(selector: string, proxyName: string) {
        let url = `http://${this.rpc.ipPort}/proxies/${selector}`;
        KaiLog.log(`put proxies, selector: ${selector} proxyName: ${proxyName}`);
        let options = this.getFetchOptions();
        options['method'] = 'PUT';
        options['body'] = JSON.stringify({'name': proxyName});
        let response = await KaiHttpUtils.fetch(url, options);
        if (response.status !== 200 && response.status !== 204) {
            const logMsg = `putProxies error: ${response.url} : ${response.status} ${response.statusText}`
            KaiLog.log(logMsg);
            throw logMsg
        }
        // return response.json();
    }

    // 多少毫秒,超过5000说明不通
    async getDelay(name: string): Promise<number> {
        let url = `http://${this.rpc.ipPort}/proxies/${encodeURIComponent(name)}/delay?timeout=3000&url=${encodeURIComponent('http://www.gstatic.com/generate_204')}`;
        // KaiLog.log('getDelay: ' + url);
        let options = this.getFetchOptions();
        options['method'] = 'GET';
        let response = await KaiHttpUtils.fetch(url, options);
        if (response.status !== 200) {
            let text = await response.text();
            // KaiLog.log(`${response.url} : ${response.status} ${response.statusText} text=${text}`);
            return RestfulApi.DELAY_TIMEOUT_MS;
        }
        const jsonResult = await response.json()
        return jsonResult['meanDelay'] //  { delay: 356, meanDelay: 231 }
    }

    /**
     {
          port: 0,
          'socks-port': 0,
          'redir-port': 0,
          'tproxy-port': 0,
          'mixed-port': 7890,
          authentication: [],
          'allow-lan': true,
          'bind-address': '*',
          mode: 'rule',
          'log-level': 'info',
          ipv6: false
    }
     */
    async getConfigs(): Promise<any> {
        let url = `http://${this.rpc.ipPort}/configs`;
        let response = await KaiHttpUtils.fetch(url, this.getFetchOptions());
        return response.json();
    }

    async getVersion(): Promise<any> {
        let url = `http://${this.rpc.ipPort}/version`;
        let response = await KaiHttpUtils.fetch(url, this.getFetchOptions());
        return response.json();
    }

    // 某个规则是直连还是其它动作
    async getRules(): Promise<any> {
        let url = `http://${this.rpc.ipPort}/rules`;
        let response = await KaiHttpUtils.fetch(url, this.getFetchOptions());
        return response.json();
    }

    // 流式接口，每秒推一个json表示上下行流量
    async getTraffic(): Promise<any> {
        let url = `http://${this.rpc.ipPort}/traffic`;
        let response = await KaiHttpUtils.fetch(url, this.getFetchOptions());
        return response.json();
    }

    // 流式接口
    async getLogs(): Promise<any> {
        let url = `http://${this.rpc.ipPort}/logs`;
        let response = await KaiHttpUtils.fetch(url, this.getFetchOptions());
        return response.json();
    }

    // -1 不存在 - 2 文件内容不符要求  否则是现在日期大于yml文件里更新的日期的天数，如为0则是同一天，1则yml文件更新已过1天，7则yml文件已过7天
    localYmlFileStatus(): number {
        let absoluteYmlPath = KaiFile.merge_dir(null, this.rpc.ymlPath)
        if (!fs.existsSync(absoluteYmlPath)) {
            return -1;
        } else {
            let fileContentBuf = fs.readFileSync(absoluteYmlPath)
            let fileContentStr = fileContentBuf.toString()
            let ymlMoment = this.getUpdateDateTime(fileContentStr)
            if (ymlMoment == null) {
                return -2;
            }
            let curMoment = moment()
            //https://momentjs.cn/docs/displaying/difference.html
            return curMoment.diff(ymlMoment, "day", true)
        }
    }

    // 如果返回null代表未能成功从网络上获取到yml文件
    async getYamlFile(ymlUrl: string): Promise<string> {
        let response = await KaiHttpUtils.fetch(ymlUrl);
        let text = await response.text();
        let m = this.getUpdateDateTime(text);
        if (m == null) {
            return null
        } else {
            return text
        }
    }

    getUpdateDateTime(text: string): moment.Moment | null {
        let re = new RegExp("上次更新于：([\\d- :]+)")
        let res =  text.match(re)
        if (res != null) {
            let dateTimeStr = res[1]; //2024-06-24 23:53:18
            return moment(dateTimeStr).utcOffset(8)
        } else {
            return null;
        }
    }


    // --------    private    --------
    getFetchOptions(): {} {
        let headers = {}
        if (KaiStr.isNotEmptyString(this.rpc.secret)) {
            headers['Authorization'] = `Bearer ${this.rpc.secret}`
        }
        return {headers}
    }

}
