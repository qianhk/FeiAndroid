//
// Created by KaiKai on 2024/3/4.
//

#ifndef KAIXxx_KAIXxxMANAGER_H
#define KAIXxx_KAIXxxMANAGER_H

#include <iostream>

class KaiXxxManager {

};

std::string kaiXxxFindSolution(const std::string &jsonParam);

#endif //KAIXxx_KAIXxxMANAGER_H
