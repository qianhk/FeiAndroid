#ifndef __Calculate__
#define __Calculate__

class Calculate
{
public:
    static double add(double, double);
};

#endif
