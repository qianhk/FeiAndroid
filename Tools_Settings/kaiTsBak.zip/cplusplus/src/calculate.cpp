#include "calculate.h"

double Calculate::add(double a, double b)
{
    return a + b;
}
