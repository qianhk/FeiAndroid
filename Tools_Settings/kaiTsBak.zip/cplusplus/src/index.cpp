#include <napi.h>
#include "calculate.h"
#include "kaixxxmanager.h"

Napi::Value Add(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    if (info.Length() < 2)
    {
        Napi::TypeError::New(env, "参数个数异常").ThrowAsJavaScriptException();
        return env.Null(); // 返回JavaScript的null
    }
    if (!info[0].IsNumber() || !info[1].IsNumber())
    {
        Napi::TypeError::New(env, "参数类型异常").ThrowAsJavaScriptException();
        return env.Null();
    }
    // Napi::Value -> Napi::Number
    double arg0 = info[0].As<Napi::Number>().DoubleValue();
    double arg1 = info[1].As<Napi::Number>().DoubleValue();
    double sum = Calculate::add(arg0, arg1);
    Napi::Number result = Napi::Number::New(env, sum);
    return result;
}

void About(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    Napi::Function cb = info[0].As<Napi::Function>();
    // C++中向JavaScript传过来的函数传递参数并执行它
    cb.Call(env.Global(), { Napi::String::New(env, "这是一个计算类") });
}

// void cplusBenchmarkEntry(const Napi::CallbackInfo& info) {
//     testBenchmarkEntry();
// }

// void cplusEntryForNodejs(const Napi::CallbackInfo& info) {
//     testEntryForNodejs();
// }

// void findSolutionForNodejs(const Napi::CallbackInfo& info) {
//     Napi::Env env = info.Env();
//     if (info.Length() < 4)
//     {
//         Napi::TypeError::New(env, "参数个数异常，要4个").ThrowAsJavaScriptException();
//         return;
//     }
//     auto arg0 = info[0].As<Napi::String>().Utf8Value();
//     uint8_t arg2 = info[1].As<Napi::Number>().Uint32Value();
//     uint32_t arg3 = info[2].As<Napi::Number>().Uint32Value();
//     auto arg4 = info[0].As<Napi::String>().Utf8Value();
//     findSolution(arg0.c_str(), arg2, arg3, arg4.c_str());
// }

Napi::Value xxxForNodeJs(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    if (info.Length() < 1)
    {
        Napi::TypeError::New(env, "参数个数异常，要1个").ThrowAsJavaScriptException();
        return env.Null();
    }
    auto arg0 = info[0].As<Napi::String>().Utf8Value();
    auto result = kaiXxxFindSolution(arg0);
    return Napi::String::New(env, result);
}

Napi::Object Init(Napi::Env env, Napi::Object exports) {
    exports.Set( Napi::String::New(env, "add"), Napi::Function::New(env, Add));
    exports.Set( Napi::String::New(env, "about"), Napi::Function::New(env, About));
    // exports.Set( Napi::String::New(env, "cplusBenchmarkEntry"), Napi::Function::New(env, cplusBenchmarkEntry));
    // exports.Set( Napi::String::New(env, "cplusEntryForNodejs"), Napi::Function::New(env, cplusEntryForNodejs));
    // exports.Set( Napi::String::New(env, "findSolutionForNodejs"), Napi::Function::New(env, findSolutionForNodejs));
    exports.Set( Napi::String::New(env, "xxx"), Napi::Function::New(env, xxxForNodeJs));
    return exports;
}

// 第一个参数为模块名称，与binding.gyp中target_name对应
NODE_API_MODULE(kaicalc, Init);
