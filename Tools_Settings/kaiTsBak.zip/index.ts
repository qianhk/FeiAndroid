// import {PgTest} from "./practice/01_get_balance_pg.js"
import {fileURLToPath} from 'url';
import path from 'path'

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('哈哈，kai xxx js app')
console.log('__dirname in index.js', __dirname)

// PgTest.main()

