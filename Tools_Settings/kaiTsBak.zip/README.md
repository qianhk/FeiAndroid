
## 安装：

一、nodejs环境
https://nodejs.org
下载20.10版本安装nodejs环境。

配置镜像加速后续依赖文件下载：
npm config set registry https://registry.npmmirror.com

npm config get registry
如果返回https://registry.npmmirror.com，说明镜像配置成功。

二、yarn
https://yarn.bootcss.com/docs/install/index.html
或直接
npm install --global yarn

yarn global add typescript
yarn add --dev typescript

yarn global add ts-node
yarn add --dev ts-node

yarn add -D tsx
npm install -g tsx
Yarn 2 doesn't support global installation

tsx xxx.ts

三、安装通用依赖

在脚本根目录执行
yarn
等完成

四、编译c++模块
npm install -g node-gyp
node-gyp configure build
node-gyp rebuild --debug






