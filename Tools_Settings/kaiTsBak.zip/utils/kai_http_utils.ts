import {HttpsProxyAgent} from "https-proxy-agent";
import fetch, {RequestInit, Response} from "node-fetch";

const kaiFetch = async (url: string, options?: RequestInit, timeout?: number): Promise<Response> => {
    // console.log(`kaiFetch url=${url} options=${options} timeout=${timeout}`);
    if (timeout == null) {
        timeout = 15 * 1000 // 默认15秒
    }
    const controller = new AbortController();
    const handler = setTimeout(() => {
        controller.abort();
    }, timeout);
    let defaultHeader: Record<string, string> = {
        'Sec-Ch-Ua-Mobile': '?0',
    }
    if (process.platform === 'linux') {
        defaultHeader['User-Agent'] = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.23 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/535.23'
        defaultHeader['Sec-Ch-Ua-Platform'] = '"Linux"'
        defaultHeader['Sec-Ch-Ua'] = '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"'
    } else { //darwin
        defaultHeader['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
        defaultHeader['Sec-Ch-Ua-Platform'] = '"macOS"'
        defaultHeader['Sec-Ch-Ua'] = '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"'
    }
    if (options == null) {
        options = {}
    }
    const httpsProxyStr = process.env['https_proxy'];
    // console.log(`process.env=${JSON.stringify(process.env)}`);
    options.headers = {...defaultHeader, ...options.headers}
    if (options['redirect'] == null) {
        options['redirect'] = "follow"
    }
    let config: RequestInit = {...options, signal: controller.signal};
    if (httpsProxyStr != null && httpsProxyStr.length > 0) {
        // console.log(`url=${url} httpsProxyStr=${httpsProxyStr}`)
        config.agent = new HttpsProxyAgent(httpsProxyStr);
    }
    try {
        let response = await fetch(url, config);
        // KaiLog.log('kai clean time handle')
        clearTimeout(handler);
        return response;
    } catch (error) {
        // KaiLog.log('kai fetch error: ', error.type)
        if ('aborted' === error.type) {
            let _err = new Error("Http Request Timeout");
            _err.name = "TIME_OUT";
            throw _err;
        } else {
            throw error;
        }
    }
}

export const KaiHttpUtils = {
    fetch: kaiFetch,
}
