import path from "path"
import moment from "moment"

// @ts-ignore
BigInt.prototype.toJSON = function() {
    return this.toString();
};

const log = (...logstrs: any[]) => {
    if (logstrs != null && logstrs.length > 0) {
        let firstStr = logstrs[0]
        if (firstStr != null && firstStr.length > 0 && firstStr[0] === '\n') {
            console.log("\n" + moment().format("[[]HH:mm:ss.SSS[]]")
                , firstStr.substring(1), ...logstrs.slice(1))
        } else {
            console.log(moment().format("[[]HH:mm:ss.SSS[]]"), ...logstrs)
        }
    } else {
        console.log(moment().format("[[]HH:mm:ss.SSS[]]"), ...logstrs)
    }
}

export const KaiLog = {
    log
}
