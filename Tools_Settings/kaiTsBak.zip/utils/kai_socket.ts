import net from 'net'

const connectAsync = (client: net.Socket, port: number, host: string) => {
    return new Promise((resolve, reject) => {
        // 处理连接错误
        client.once('error', err => {
            reject(err) // 连接失败，Promise 拒绝
        })

        // 尝试连接
        client.connect(port, host, () => {
            // @ts-ignore
            resolve() // 连接成功，Promise 解析
        })
    })
}

export const KaiSocket = {
    connectAsync
}
