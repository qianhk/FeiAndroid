//
// Created by kai on 24-7-21.
//

#ifndef KAIMINERDEMO_KAIBITSET_H
#define KAIMINERDEMO_KAIBITSET_H

#include <climits>        /* for CHAR_BIT */

constexpr uint32_t MAX_UINT32 = 0xFFFFFFFF;


// Also (idx % WORD_BITS) can be simplified to (idx & (WORD_BITS - 1)) but a good compiler maybe does that optimization automatically.

#define BITMASK(b) (1 << ((b) % CHAR_BIT))
#define BITSLOT(b) ((b) / CHAR_BIT)
#define BITSET(a, b) ((a)[BITSLOT(b)] |= BITMASK(b))
#define BITCLEAR(a, b) ((a)[BITSLOT(b)] &= ~BITMASK(b))
#define BITTEST(a, b) ((a)[BITSLOT(b)] & BITMASK(b))
#define BITNSLOTS(nb) ((nb + CHAR_BIT - 1) / CHAR_BIT) // 注意，由于有个加法，如果nb超大，可能会溢出

#endif //KAIMINERDEMO_KAIBITSET_H
