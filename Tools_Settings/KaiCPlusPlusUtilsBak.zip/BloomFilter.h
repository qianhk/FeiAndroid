//
// Created by KaiKai on 2024/6/23.
//

#ifndef KAIMINERDEMO_BLOOMFILTER_H
#define KAIMINERDEMO_BLOOMFILTER_H


#include <bitset>
#include <string>

/*
 * 300万数据 len 1<<24  M 3 单一MurmurHash
[00:21:28.209] thread amount is 1, speed/s is 212032, total is 2121171. (mayBeContainCount=151959)
[00:21:38.210] thread amount is 1, speed/s is 212498, total is 4246555. (mayBeContainCount=303775)

300万数据 len 1<<25  M 3 单一MurmurHash
[23:22:09.405] thread amount is 1, speed/s is 200090, total is 2001724. (mayBeContainCount=26023)
[23:22:19.408] thread amount is 1, speed/s is 209483, total is 4097056. (mayBeContainCount=53274)

300万数据 len 1<<24  M 4 单一MurmurHash
[23:35:22.970] thread amount is 1, speed/s is 209046, total is 2090492. (mayBeContainCount=142874)
[23:35:32.972] thread amount is 1, speed/s is 202260, total is 4113493. (mayBeContainCount=280833)

300万数据 len 1<<25  M 4 单一MurmurHash
[23:36:11.304] thread amount is 1, speed/s is 200545, total is 2006258. (mayBeContainCount=16391)
[23:36:21.308] thread amount is 1, speed/s is 212462, total is 4131587. (mayBeContainCount=33649)



300万数据 len 1<<24  M 1 单一MurmurHash
[23:37:05.662] thread amount is 1, speed/s is 179060, total is 1791343. (mayBeContainCount=293895)
[23:37:15.663] thread amount is 1, speed/s is 207211, total is 3863686. (mayBeContainCount=632701)

300万数据 len 1<<24  M 1 单一BKDRHash
[00:02:13.408] thread amount is 1, speed/s is 188976, total is 1890583. (mayBeContainCount=308672)

300万数据 len 1<<24  M 1 单一APHash
[00:05:12.472] thread amount is 1, speed/s is 200756, total is 2008446. (mayBeContainCount=328351)


 */
// 23 800w
// 24 1600w
// 25 3300w
// 26 6700w 占用空间64MB
// 27 占用空间128MB
// 28 占用空间256MB
// 29 占用空间512MB
// 30 占用空间1024MB

//Define of BitVector and M
//#define LEN 1<<26
constexpr uint32_t LEN = 1 << 28;
constexpr uint32_t M = 4;
typedef std::bitset<LEN> BV;

class BloomFilter {
public:

    BloomFilter();

    BloomFilter(const char *in_path);

    ~BloomFilter();

    //Seralize bitset to file
    void Dump(const char *out_path);

    //Add to Bloom Filter and set M bit to True
    void Add(const std::string &key);

    //if all of the M bit was set to True -> return True;if any of the M bit was set to False -> Return False
    bool Test(const std::string &key);

    bool Test(const char *key, uint32_t len);

    //Test first, add it if not in and return false, else return false
    bool TestAndAdd(const std::string &key);

private:
    BV *pbv;
};


#endif //KAIMINERDEMO_BLOOMFILTER_H
