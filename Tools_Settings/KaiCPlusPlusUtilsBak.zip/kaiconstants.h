//
// Created by KaiKai on 2024/3/9.
//

#ifndef KAIMINERDEMO_KAICONSTANTS_H
#define KAIMINERDEMO_KAICONSTANTS_H


#include "coinHitter/cpuFastSecp256k1/SECP256k1.h"

extern const char *const VERIFY_CORRECTNESS;

namespace kai {
    constexpr int Keccak256_HASH_LEN = 32;
    constexpr int Ripemd160_HASH_LEN = 20;
    constexpr int Sha256_HASH_LEN = 32;
    constexpr int Sha512_HASH_LEN = 32;

    constexpr int AddressTypeHash160P2PKH = P2PKH; // 0
    constexpr int AddressTypeHash160P2SH = P2SH; // 1
    constexpr int AddressTypeEVM = 2;
}

#endif //KAIMINERDEMO_KAICONSTANTS_H
