//
// Created by KaiKai on 2024/6/23.
//

#include <string>
#include <fstream>
#include "BloomFilter.h"
#include "MurmurHash3.h"

BloomFilter::BloomFilter()
        : pbv(nullptr) {
    this->pbv = new BV();
    this->pbv->reset();
}

BloomFilter::BloomFilter(const char *in_path)
        : pbv(nullptr) {
    ::std::ifstream in(in_path);
    ::std::string str((std::istreambuf_iterator<char>(in)),
                      std::istreambuf_iterator<char>());
    this->pbv = new BV(str);
    in.close();
}

BloomFilter::~BloomFilter() {
    if (this->pbv) {
        delete pbv;
    }
}

void BloomFilter::Dump(const char *out_path) {
    ::std::ofstream out(out_path);
    out << this->pbv->to_string();
    out.close();
}

uint32_t BKDRHash(const char *str) {
    uint32_t seed = 131; // 31 131 1313 13131 131313 etc..
    uint32_t hash = 0;

    while (*str) {
        hash = hash * seed + (*str++);
    }

    return (hash & 0x7FFFFFFF);
}

unsigned int APHash(const char *str) {
    unsigned int hash = 0;
    int i;

    for (i = 0; *str; i++) {
        if ((i & 1) == 0) {
            hash ^= ((hash << 7) ^ (*str++) ^ (hash >> 3));
        } else {
            hash ^= (~((hash << 11) ^ (*str++) ^ (hash >> 5)));
        }
    }

    return (hash & 0x7FFFFFFF);
}


void BloomFilter::Add(const std::string &key) {
    uint32_t seed = 0;
    for (size_t i = 0; i < M; i++) {
        uint32_t pos = 0;
        MurmurHash3_x86_32(key.c_str(), key.length(), seed, &pos);
        seed = pos;
        pos %= LEN;
        this->pbv->set(pos);
    }
//    uint32_t hash = BKDRHash(key.c_str());
//    uint32_t hash = APHash(key.c_str());
//    hash %= LEN;
//    this->pbv->set(hash);
}

bool BloomFilter::Test(const std::string &key) {
    uint32_t seed = 0;
    for (size_t i = 0; i < M; i++) {
        uint32_t pos = 0;
        MurmurHash3_x86_32(key.c_str(), key.length(), seed, &pos);
        seed = pos;
        pos %= LEN;
        if (!this->pbv->test(pos)) {
            return false;
        }
    }
    return true;

//    uint32_t hash = BKDRHash(key.c_str());
//    uint32_t hash = APHash(key.c_str());
//    hash %= LEN;
//    return this->pbv->test(hash);
}

bool BloomFilter::Test(const char *key, uint32_t len) {
    uint32_t seed = 0;
    for (size_t i = 0; i < M; i++) {
        uint32_t pos = 0;
        MurmurHash3_x86_32(key, len, seed, &pos);
        seed = pos;
        pos %= LEN;
        if (!this->pbv->test(pos)) {
            return false;
        }
    }
    return true;
}

bool BloomFilter::TestAndAdd(const std::string &key) {
    if (this->Test(key)) {
        return true;
    } else {
        this->Add(key);
        return false;
    }
}