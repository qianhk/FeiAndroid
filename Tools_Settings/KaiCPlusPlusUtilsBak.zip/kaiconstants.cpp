//
// Created by KaiKai on 2024/3/9.
//

#include "kaiconstants.h"

const char *const VERIFY_CORRECTNESS = "verifyCorrectness";
