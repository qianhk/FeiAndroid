//
// Created by KaiKai on 2023/7/2.
//

#include "kaiutils.h"
#include <sstream>
#include <iomanip>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdarg>
#include <cctype>
#include <thread>
#include <csignal>

char *kai::logShortTimeStr() {
    static char buffer[32];
    static char buffer2[64];
//    const time_t now = time(nullptr);

//    struct timeval time_now = {0};
//    gettimeofday(&time_now, nullptr); // 不建议使用了

    struct timespec now = {0};
    clock_gettime(CLOCK_REALTIME, &now);
    struct tm *info = localtime(&now.tv_sec);
    strftime(buffer, sizeof(buffer), "%H:%M:%S", info); // tm不支持毫秒
    long nsec = (long) ((float) now.tv_nsec * 0.000001f); // nano second to millisecond
    snprintf(buffer2, sizeof(buffer2), "%s.%03ld", buffer, nsec);
    return buffer2;
}

//void kai::logWithOstream(std::ostream &ostream, const char *fmt, ...) {
//    const int BUF_SIZE = 8 * 1024;
//    static char buffer[BUF_SIZE];
//    va_list args;
//    va_start(args, fmt);
//    vsnprintf(buffer, BUF_SIZE, fmt, args);
//    va_end(args);
//    bool firstIsNewLine = buffer[0] == '\n';
//    if (firstIsNewLine) {
//        ostream << std::endl;
//    }
//    ostream << '[' << kai::logShortTimeStr() << "] ";
//    if (firstIsNewLine) {
//        ostream << &buffer[1];
//    } else {
//        ostream << buffer;
//    }
//    ostream << std::endl;
//}

void kai::errLog(bool error, const char *fmt, ...) {
//    kai::logWithOstream(std::cout, fmt, ...);
    const int BUF_SIZE = 8 * 1024;
    static char buffer[BUF_SIZE];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, BUF_SIZE, fmt, args);
    va_end(args);
    bool firstIsNewLine = buffer[0] == '\n';
//    std::ostream::sync_with_stdio(); //强制刷新输出，避免std:cerr先输出影响顺序，也不知道实际有没有用 (没用)
//    std::cout.flush(); //这个似乎没用，cerr还是在前面了，一个说法是只刷新到了内核缓冲区
    std::ostream &ouputStream = error ? std::cerr : std::cout;
    if (firstIsNewLine) {
        ouputStream << std::endl;
    }
    ouputStream << '[' << kai::logShortTimeStr() << "] ";
    if (firstIsNewLine) {
        ouputStream << &buffer[1];
    } else {
        ouputStream << buffer;
    }
    ouputStream << std::endl;
}

void kai::log(const char *fmt, ...) {
//    static std::mutex logMutex;
//    logMutex.lock();
    constexpr int BUF_SIZE = 8 * 1024;
    static char buffer[BUF_SIZE];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, BUF_SIZE, fmt, args);
    va_end(args);
    bool firstIsNewLine = buffer[0] == '\n';
    if (firstIsNewLine) {
        std::cout << std::endl;
    }
    std::cout << '[' << kai::logShortTimeStr() << "] ";
    if (firstIsNewLine) {
        std::cout << &buffer[1];
    } else {
        std::cout << buffer;
    }
    std::cout << std::endl;
//    logMutex.unlock();
}

// 可读字符串，形如："123ABC..."   =>   [0x31,0x32,0x33,0x40,0x41,0x42...]
kai::Bytes kai::convertAsciiStringToHexData(const char *str) {
    return kai::Bytes({str, str + std::strlen(str)});
}

inline int hexCharToInt(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return 0;
}

// sscanf 换成这个方法，速度从 10万/s 提高到 183万/s
// 16进制字符串，形如 0x "313233404142..."     =>   [0x31,0x32,0x33,0x40,0x41,0x42...]
kai::Bytes kai::convertHexStringToHexData(const char *str) {
    size_t length = std::strlen(str);
    assert(length > 0 && length % 2 == 0);
    auto *cResult = new uint8_t[length / 2 + 1];
    uint8_t n;
    int j = 0;
    size_t idx = 0;
    if (str[0] == '0' && str[1] == 'x') {
        idx = 2;
    }
    for (; idx < length; idx += 2) {
        int t1 = hexCharToInt(str[idx]);
        int t2 = hexCharToInt(str[idx + 1]);
        int t1_2 = t1 << 4;
        n = t1_2 | t2;
//        result.push_back(n); // 速度太慢
        cResult[j++] = n; // 换成这个从183万 提高到 438万/s
    }
    cResult[j] = 0;
    auto result = Bytes({cResult, cResult + j});
    delete[] cResult;
    return result;
}

// 形如 0x "313233404142..."     =>   [0x31,0x32,0x33,0x40,0x41,0x42...]
// 形如："123ABC..."   =>   [0x31,0x32,0x33,0x40,0x41,0x42...]
kai::Bytes kai::convertStringToHexData(const char *str) {
    assert(str != nullptr);
    size_t length = std::strlen(str);
    if (length <= 1) {
        return kai::Bytes({str, str + length});
    } else {
        if (str[0] == '0' && str[1] == 'x') {
            return convertHexStringToHexData(str);
        } else {
            return kai::Bytes({str, str + length});
        }
    }
}

// [0x31,0x32,0x33,0x40,0x41,0x42,0x4f...]   =>   "0x3132334041424f...." 涉及到字母的是小写 (默认含0x)
void kai::convertHexDataToHexCStr(const std::uint8_t *hexArray, size_t byteLen, char *buf, bool prefix) {
    const char tab[] = "0123456789abcdef";    // 0x0-0xF 的字符查找表
    int jdx = 0;
    if (prefix) {
        buf[0] = '0';
        buf[1] = 'x';
        jdx = 2;
    }
    for (int idx = 0; idx < byteLen; idx++) {
        buf[jdx++] = tab[hexArray[idx] >> 4];
        buf[jdx++] = tab[hexArray[idx] & 0x0F];
    }
    buf[jdx] = 0;
}

std::string kai::convertHexDataToHexString(const std::uint8_t *hexArray, size_t byteLen, bool hasPrefix) {
    auto *buf = new char[(byteLen << 2) + 4];
    kai::convertHexDataToHexCStr(hexArray, byteLen, buf, hasPrefix);
    std::string resultStr(reinterpret_cast<const char *>(buf));
    delete[]buf;
    return resultStr;
}

char *kai::logLongTimeStr() {
    static char buffer[64];
    const time_t now = time(nullptr);
    struct tm *info = localtime(&now);
    strftime(buffer, 64, "%Y-%m-%d %H:%M:%S", info);
    return buffer;
}

bool kai::allIsNum(const std::string &str) {
    for (char c: str) {
        int tmp = (int) c;
        if (tmp >= '0' && tmp <= '9') {
            continue;
        } else {
            return false;
        }
    }
    return true;
}

bool kai::startsWith(const std::string &str, const std::string &prefix) {
    return (str.rfind(prefix, 0) == 0);
}

bool kai::endsWith(const std::string &str, const std::string &suffix) {
    if (suffix.length() > str.length()) { return false; }
    return (str.rfind(suffix) == (str.length() - suffix.length()));
}

void kai::executeCMD(const char *cmd, char *result) {
    char buf_ps[1024];
    char ps[1024] = {0};
    FILE *ptr;
    strcpy(ps, cmd);
    if ((ptr = popen(ps, "r")) != nullptr) {
        while (fgets(buf_ps, 1024, ptr) != nullptr) {
            strcat(result, buf_ps);
            if (strlen(result) > 1024)
                break;
        }
        pclose(ptr);
        ptr = nullptr;
    } else {
        printf("popen %s error ", ps);
    }
}

char *kai::strlower(char *str) {
    char *orign = str;
    for (; *str != '\0'; str++)
        *str = tolower(*str);
    return orign;
}

uint32_t kai::convertThreadAmount(const std::string &threadStr) {
    long thread = 0;
    char *endPtr = nullptr;
    thread = strtol(threadStr.c_str(), &endPtr, 10);
    uint32_t concurrency = std::thread::hardware_concurrency();
    if (*endPtr != '\0') {
        float ratio = 1.0f * thread / 100;
        thread = long(concurrency * ratio + 0.5);
    }
    thread = thread < 1 ? 1 : thread;
    return thread > concurrency ? concurrency : thread;
}

void kai::swapMemCopy(void *_dst, const void *_src, size_t n) {
    auto *dst = static_cast<uint8_t *>(_dst);
    const auto *src = static_cast<const uint8_t *>(_src);
    assert(dst != nullptr && src != nullptr && n > 0);
    for (int idx = 0; idx < n; ++idx) {
        dst[n - idx - 1] = src[idx];
    }
}

int32_t kai::binarySearch(const uint64_t *buffer, int32_t size, uint64_t target) {
    int32_t mid;
    int32_t lo = 0, hi = size - 1;

    while (hi - lo > 1) {
        mid = (hi + lo) >> 1;
        if (buffer[mid] == target) {
            return mid;
        } else if (buffer[mid] < target) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }

    if (buffer[lo] == target) {
        return lo;
    } else if (buffer[hi] == target) {
        return hi;
    } else {
        return -1;
    }
}

void kai::clearScreen() {
#ifdef WINDOWS
    std::system("cls");
#else
    std::system("clear");
#endif
}

void kai::sleepMillis(uint32_t millis) {
#ifdef WIN64
    Sleep(millis);
#elif __APPLE__
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
#else
    usleep(millis * 1000);
#endif
}