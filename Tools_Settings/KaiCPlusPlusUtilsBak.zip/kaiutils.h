//
// Created by KaiKai on 2023/7/2.
//

#ifndef VCOINHIT_KAIUTILS_PP
#define VCOINHIT_KAIUTILS_PP

#include <iostream>
#include <sstream>
#include <iomanip>
#include <vector>

#include "kaiconstants.h"

//extern "C" {

//#define LOG(...) { \
//	fprintf(stdout, "%s: Line %d:\t", __FILE__, __LINE__); \
//	fprintf(stdout, __VA_ARGS__); \
//	fprintf(stdout, "\n"); \
//}

namespace kai {

    typedef std::vector<std::uint8_t> Bytes;

    bool allIsNum(const std::string &str);

    bool startsWith(const std::string &str, const std::string &prefix);

    bool endsWith(const std::string &str, const std::string &suffix);

    void executeCMD(const char *cmd, char *result);

    void log(const char *fmt, ...);

    void errLog(bool error, const char *fmt, ...);

    // 形如 "0x313233404142..."     =>   [0x31,0x32,0x33,0x40,0x41,0x42...]
    // 形如："123ABC..."   =>   [0x31,0x32,0x33,0x40,0x41,0x42...]
    Bytes convertStringToHexData(const char *str);

    // 可读字符串，形如："123ABC..."   =>   [0x31,0x32,0x33,0x40,0x41,0x42...]
    Bytes convertAsciiStringToHexData(const char *str);

    // 16进制字符串，形如 0x "313233404142..."     =>   [0x31,0x32,0x33,0x40,0x41,0x42...]
    // 支持带前缀0x，会自动忽略掉0x从后面开始填充
    Bytes convertHexStringToHexData(const char *str);

    // [0x31,0x32,0x33,0x40,0x41,0x42,0x4f...]   =>   "0x3132334041424f...." 涉及到字母的是小写 (默认含0x)
    std::string convertHexDataToHexString(const std::uint8_t *hexArray, size_t byteLen, bool hasPrefix = true);

    void convertHexDataToHexCStr(const std::uint8_t *hexArray, size_t byteLen, char *outputArray, bool hasPrefix = true);

    //转成小写
    char *strlower(char *str);

    // copy时顺便交换字节，dst的第一个到src最后一个，dst最后一个到src第一个
    void swapMemCopy(void *dst, const void *src, size_t n);

    static const char *BlankString = " \t\n\r\f\v";

// trim from end of string (right)
    inline std::string &rtrim(std::string &s, const char *t = BlankString) {
        s.erase(s.find_last_not_of(t) + 1);
        return s;
    }

// trim from beginning of string (left)
    inline std::string &ltrim(std::string &s, const char *t = BlankString) {
        s.erase(0, s.find_first_not_of(t));
        return s;
    }

// trim from both ends of string (right then left)
    inline std::string &trim(std::string &s, const char *t = BlankString) {
        return ltrim(rtrim(s, t), t);
    }


//    private

    char *logLongTimeStr();

    char *logShortTimeStr();

//    void logWithOstream(std::ostream &ostream, const char *fmt, ...);

    uint32_t convertThreadAmount(const std::string &threadStr);

    // 性能不如std::binary_search 大约只有80%
    int32_t binarySearch(const uint64_t *buffer, int32_t size, uint64_t target);

    void clearScreen();

    void sleepMillis(uint32_t millis);
}

#endif //VCOINHIT_KAIUTILS_PP
