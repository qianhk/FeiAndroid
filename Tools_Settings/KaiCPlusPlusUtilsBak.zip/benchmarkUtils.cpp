//
// Created by KaiKai on 2024/4/13.
//

#include "benchmarkUtils.h"
#include "kaiutils.h"
#include <chrono>

void benchmark(const char *name, uint64_t totalCount, void (*doSthOnce)()) {
#ifdef DEBUG
    totalCount /= 3;
#endif
    auto begin = std::chrono::high_resolution_clock::now();
    for (uint64_t idx = 0; idx < totalCount; ++idx) {
        doSthOnce();
    }
    auto end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin);
    double totalSecond = elapsed.count() * 0.001;
    double speed = totalCount / totalSecond;
    double speedW = speed / 10000;
    const char* unit = speedW >= 1 ? "WH/s" : "H/s";
    kai::log("benchmark %s: 耗时约 %.1f 秒，计算总次数: %u, 速率: %.1f %s",
             name, totalSecond, totalCount, speedW >= 1 ? speedW : speed, unit);
}

void gpuBenchmark(const char * name, uint64_t totalCount, void (*doSthBatch)()) {
    auto begin = std::chrono::high_resolution_clock::now();
    doSthBatch();
    auto end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin);
    double totalSecond = elapsed.count() * 0.001;
    double speed = totalCount / totalSecond;
    double speedW = speed / 10000;
    const char* unit = speedW >= 1 ? "WH/s" : "H/s";
    kai::log("gpu benchmark %s: 耗时约 %.1f 秒，计算总次数: %u, 速率: %.1f %s",
             name, totalSecond, totalCount, speedW >= 1 ? speedW : speed, unit);
}