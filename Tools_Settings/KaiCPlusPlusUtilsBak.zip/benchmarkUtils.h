//
// Created by KaiKai on 2024/4/13.
//

#ifndef KAIMINERDEMO_BENCHMARKUTILS_H
#define KAIMINERDEMO_BENCHMARKUTILS_H

#include <stdint.h>

class benchmarkUtils {

};

void benchmark(const char * name, uint64_t totalCount, void (*doSthOnce)());
void gpuBenchmark(const char * name, uint64_t totalCount, void (*doSthOnce)());

#endif //KAIMINERDEMO_BENCHMARKUTILS_H
