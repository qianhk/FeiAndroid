//
// Created by KaiKai on 2024/3/7.
//

#ifndef KAIMINER_RANDOMMANAGER_H
#define KAIMINER_RANDOMMANAGER_H

#include <random>

class RandomManager {
public:
    void fill(uint8_t *pData, uint32_t from, uint32_t length);
    void updateSeed();

//    RandomManager(const RandomManager &randomMgr);
//    RandomManager(const RandomManager &randomMgr) = delete;
//    RandomManager &operator=(RandomManager &&x);
public:
    RandomManager();
    virtual ~RandomManager();
private:
    uint64_t mGenCount = 0;
    std::mt19937 *pRandom = nullptr;
};


#endif //KAIMINER_RANDOMMANAGER_H
