//
// Created by KaiKai on 2024/3/7.
//

#include "randommanager.h"
#include "utils/kaiutils.h"

RandomManager::RandomManager() {
//    kai::log("RandomManager() %X", this);
    updateSeed();
}

RandomManager::~RandomManager() {
//    kai::log("~RandomManager() %X will delete rand=%X", this, pRandom);
    delete pRandom;
}

void RandomManager::fill(uint8_t *pData, uint32_t from, uint32_t length) {
    static uint64_t sMaxGenCount = 1e8;
    if (mGenCount >= sMaxGenCount) {
        updateSeed();
    }
    uint32_t wholeCount = length >> 2; //整 unsigned int 4字节填充次数
    auto *p = reinterpret_cast<uint32_t *>(pData + from);
    for (int idx = 0; idx < wholeCount; ++idx) {
        *p++ = pRandom->operator()();
        ++mGenCount;
    }
    auto *p2 = reinterpret_cast<uint8_t *>(p);
    for (; p2 < pData + from + length; ++p2) {
        *p2 = static_cast<uint8_t>(pRandom->operator()());
        ++mGenCount;
    }
}

void RandomManager::updateSeed() {
//    kai::log("RandomManager::updateSeed() %X will delete rand=%X", this, pRandom);
    delete pRandom;
    std::random_device rd;
    pRandom = new std::mt19937(rd());
    mGenCount = 0;
//    kai::log("RandomManager::updateSeed() %X, new rand=%X", this, pRandom);
}

//RandomManager::RandomManager(const RandomManager &randomMgr) {
//    kai::log("RandomManager:: copy contruct %X thisR=%X newR=%X", this, pRandom, randomMgr.pRandom);
//    pRandom = randomMgr.pRandom;
//}

//RandomManager &RandomManager::operator=(RandomManager&& x) {
//    kai::log("RandomManager:: operator= %X thisR=%X newR=%X", this, pRandom, x.pRandom);
//    pRandom = x.pRandom;
//    return *this;
//}
