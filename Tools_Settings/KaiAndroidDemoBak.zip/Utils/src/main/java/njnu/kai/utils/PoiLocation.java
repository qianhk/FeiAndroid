package njnu.kai.utils;

import java.io.Serializable;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public class PoiLocation implements Serializable {

    private String mDetailAddress;

    private String mProvince;
    private String mCity;
    private String mDistrict;

    public void setPoiLocation(PoiLocation location) {
        if (location != null) {
            mDetailAddress = location.mDetailAddress;
            mProvince = location.mProvince;
            mCity = location.mCity;
            mDistrict = location.mDistrict;
        }
    }

    public PoiLocation() {
    }

    public PoiLocation(String detailAddress, String province, String city, String district) {
        mDetailAddress = detailAddress;
        mProvince = province;
        mCity = city;
        mDistrict = district;
    }

    public void setDetailAddress(String detailAddress) {
        mDetailAddress = detailAddress;
    }

    public void setProvince(String province) {
        mProvince = province;
    }

    public void setCity(String city) {
        mCity = city;
    }

    public void setDistrict(String district) {
        mDistrict = district;
    }

    public String getDetailAddress() {
        return mDetailAddress;
    }

    public String getProvince() {
        return mProvince;
    }

    public String getCity() {
        return mCity;
    }

    public String getDistrict() {
        return mDistrict;
    }
}
