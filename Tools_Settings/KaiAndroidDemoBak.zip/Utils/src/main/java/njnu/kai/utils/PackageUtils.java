package njnu.kai.utils;

import android.content.Context;

/**
 * Created by Administrator on 14-1-13.
 *
 * @version 1.0.0
 */
public class PackageUtils {
    /**
     * 获取versionCode
     *
     * @param context Context
     * @return versionCode
     */
    public static int versionCode(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (Throwable e) {
            e.printStackTrace();
        }

        return 0;
    }
    /**
     * 获取versionCode
     *
     * @param context Context
     * @return versionCode
     */
    public static String versionName(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (Throwable e) {
            e.printStackTrace();
        }

        return "unknown";
    }
}
