package njnu.kai.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.media.ThumbnailUtils;
import android.os.Build;
import android.text.TextUtils;
import android.widget.ImageView;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/**
 * @author kai
 * @version 1.0.0
 */


public class BitmapUtils {

    /**
     * bitmap with alpha channel
     */
    public static final String LOG_TAG = "BitmapUtils";
    private static final String ALPHA_BITMAP_MIME_TYPE_END = "png";

    private static final int DEAFULT_QUALITY = 90;
    private BitmapFactory.Options mInitBitmapFactoryOptions;
    private BitmapFactory.Options mBitmapFactoryOptions;
    private boolean mPreferUseRgb8888 = true; //SDKVersionUtils.hasHoneycombMR2();
    private boolean mPreDecoded = false;

    /**
     * 构造方法
     *
     * @param bitmapFactoryOptions 解码参数
     */
    public BitmapUtils(BitmapFactory.Options bitmapFactoryOptions) {
        if (bitmapFactoryOptions != null) {
            mInitBitmapFactoryOptions = bitmapFactoryOptions;
        } else {
            mInitBitmapFactoryOptions = createDefaultOptions();
        }
    }

    /**
     * 默认的构造方法
     */
    public BitmapUtils() {
        mInitBitmapFactoryOptions = createDefaultOptions();
    }

    /**
     * @param bitmapOptions bitmap options
     * @param maxWidth      max width
     * @param maxHeight     max height
     * @return true if success
     */
    public static boolean initBitmapFactoryOptions(BitmapFactory.Options bitmapOptions, int maxWidth, int maxHeight) {
        if (bitmapOptions.inJustDecodeBounds && bitmapOptions.outHeight > 0 && bitmapOptions.outWidth > 0) {
            if (bitmapOptions.outWidth > (maxWidth << 1) || bitmapOptions.outHeight > (maxHeight << 1)) {
                bitmapOptions.inSampleSize = Math.max(
                        bitmapOptions.outWidth / maxWidth
                        , bitmapOptions.outHeight / maxHeight);
            }
            bitmapOptions.inJustDecodeBounds = false;
            return true;
        }
        return false;
    }

    /**
     * set bitmap options preferred config
     *
     * @param bitmapOptions bitmap options
     * @return true if options is valid
     */
    public static boolean initAlphaChannel(BitmapFactory.Options bitmapOptions) {
        if (!TextUtils.isEmpty(bitmapOptions.outMimeType)) {
            if (mayNotHasAlphaChannel(bitmapOptions)) {
                bitmapOptions.inPreferredConfig = Bitmap.Config.RGB_565;
                bitmapOptions.inDither = false;
            } else {
                bitmapOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;
            }
            return true;
        }
        return false;
    }

    /**
     * FavoriteIdLoader if bitmap may not contain alpha channel
     *
     * @param bitmapFactoryOptions bitmap factory option, which has decoded
     * @return true if yes
     */
    public static boolean mayNotHasAlphaChannel(BitmapFactory.Options bitmapFactoryOptions) {
        String outMimeType = bitmapFactoryOptions.outMimeType;
        return !TextUtils.isEmpty(outMimeType)
                && !outMimeType.toLowerCase(Locale.US).endsWith(ALPHA_BITMAP_MIME_TYPE_END);
    }

    /**
     * 裁剪图片为方形图片
     *
     * @param bitmap       图片
     * @param squareLength 长度
     * @return 位图
     */
    public static Bitmap cropBitmapToSquare(Bitmap bitmap, int squareLength) {
        if (bitmap != null) {
            int imageSquareLength = Math.min(bitmap.getWidth(), bitmap.getHeight());
            int croppedLength = Math.min(imageSquareLength, squareLength);
            float scale = (float) croppedLength / imageSquareLength;
            Matrix matrix = new Matrix();
            matrix.setScale(scale, scale);
            LogUtils.d(LOG_TAG, String.format("cropBitmapToSquare bitmapW=%d H=%d squareLen=%d scale=%f"
                    , bitmap.getWidth(), bitmap.getHeight(), squareLength, scale));
            try {
                Bitmap newBitmap = Bitmap.createBitmap(bitmap, 0, 0, imageSquareLength, imageSquareLength, matrix, true);
                newBitmap.setHasAlpha(bitmap.hasAlpha());
                return newBitmap;
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * 裁剪图片为方形图片
     *
     * @param bitmapPath   图片路径
     * @param squareLength 长度
     * @return 位图
     */
    public static Bitmap cropBitmapToSquare(String bitmapPath, int squareLength) {
        Bitmap bitmap = decodeSampledBitmapFromFile(bitmapPath, squareLength, squareLength);
        return cropBitmapToSquare(bitmap, squareLength);
    }

    /**
     * 从资源文件中解码图片, 会根据需要拉伸或压缩图片
     *
     * @param res       Resources
     * @param resId     resId
     * @param reqWidth  需要显示的图片的宽度
     * @param reqHeight 需要显示的图片的高度
     * @return The decoded bitmap, or null if the image data could not be
     * decoded
     */
    public static Bitmap decodeSampledBitmapFromResource(Resources res, int resId,
                                                         int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, resId, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(res, resId, options);
    }

    /**
     * 从资源文件中解码图片, 会根据需要拉伸或压缩图片
     *
     * @param filePath  文件全路径
     * @param reqWidth  需要显示的图片的宽度
     * @param reqHeight 需要显示的图片的高度
     * @return The decoded bitmap, or null if the image data could not be
     * decoded
     */
    public static Bitmap decodeSampledBitmapFromFile(String filePath, int reqWidth, int reqHeight) {
        if (TextUtils.isEmpty(filePath)) {
            return null;
        }

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        options.inPurgeable = true;
        options.inInputShareable = true;
        BitmapFactory.decodeFile(filePath, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;

        try {
            return BitmapFactory.decodeFile(filePath, options);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 根据要求的图片大小，和图片原来的小计算图片采样大小
     *
     * @param options   option
     * @param reqWidth  要求输出的图片宽度
     * @param reqHeight 要求输出的图片高度
     * @return 采样值
     */
    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {

        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if ((reqWidth > 0 && reqHeight > 0) && (height > reqHeight || width > reqWidth)) {
            if (width > height) {
                inSampleSize = Math.round((float) height / (float) reqHeight);
            } else {
                inSampleSize = Math.round((float) width / (float) reqWidth);
            }
        }
        return 0 == inSampleSize ? 1 : inSampleSize;
    }

    /**
     * 获取bitmap占用空间大小
     *
     * @param bitmap 位图实例
     * @return 位图占用空间大小
     */
    public static int getBitmapSize(Bitmap bitmap) {
        if (bitmap == null) {
            throw new IllegalArgumentException("bitmap must be not null!");
        }

        return bitmap.getByteCount();
    }

    /**
     * 保存bitMap图片
     *
     * @param bitmap   Bitmap对象
     * @param savePath 图片路径
     */

    public static void saveBitmap(final Bitmap bitmap, final String savePath) {
        DebugUtils.assertNotNull(bitmap, "bitmap");
        DebugUtils.assertNotNull(savePath, "savePath");
        FileUtils.delete(savePath);

        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(savePath);
            bitmap.compress(Bitmap.CompressFormat.JPEG, DEAFULT_QUALITY, fileOutputStream);
            fileOutputStream.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fileOutputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 保持等比例缩放图片
     * 当view宽度较大时，垂直方向顶部不剪裁，只剪裁下面，当view高度较大时，水平方向居中保留，裁剪左右。
     *
     * @param imageView image view
     */
    public static void amendMatrixForCenterCrop(ImageView imageView) {
        if (imageView == null) {
            return;
        }

        Drawable drawable = imageView.getDrawable();
        int drawableHeight = drawable != null ? drawable.getIntrinsicHeight() : 0;
        int drawableWidth = drawable != null ? drawable.getIntrinsicWidth() : 0;
        int viewWidth = imageView.getWidth();
        int viewHeight = imageView.getHeight();
        if (drawableHeight <= 0 || drawableWidth <= 0 || viewWidth <= 0 || viewHeight <= 0) {
            return;
        }
        LogUtils.d(LOG_TAG, String.format("amendMatrixForCenterCrop tag=%s view=%d,%d drawable=%d,%d"
                , imageView.getTag(), viewWidth, viewHeight, drawableWidth, drawableHeight));
        float horizontalScaleRatio = 1.0f * viewWidth / drawableWidth;
        float verticalScaleRatio = 1.0f * viewHeight / drawableHeight;
        if (verticalScaleRatio >= horizontalScaleRatio) {
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            LogUtils.d(LOG_TAG, String.format("use system center_crop %f %f", horizontalScaleRatio, verticalScaleRatio));
        } else {
            imageView.setScaleType(ImageView.ScaleType.MATRIX);
            float scaleRatio = Math.max(horizontalScaleRatio, verticalScaleRatio);
            Matrix matrix = new Matrix();
            matrix.postScale(scaleRatio, scaleRatio);
            imageView.setImageMatrix(matrix);
            LogUtils.d(LOG_TAG, String.format("use my matrix %f %f scale=%f", horizontalScaleRatio, verticalScaleRatio, scaleRatio));
        }
    }

    /**
     * 以FitCenter方式生成图片
     *
     * @param srcBitmap        原始图片
     * @param dstWidth         目标图片宽度
     * @param dstHeight        目标图片高度
     * @param tryRecycleSource 是否尽量回收原图
     * @return 如果创建不成功返回原图
     */
    public static Bitmap createFitXYBitmap(Bitmap srcBitmap, int dstWidth, int dstHeight, boolean tryRecycleSource) {
        if (srcBitmap == null || dstWidth <= 0 || dstHeight <= 0) {
            return srcBitmap;
        }

        Bitmap dstBitmap = srcBitmap;
        try {
            dstBitmap = Bitmap.createScaledBitmap(srcBitmap, dstWidth, dstHeight, true);
            if (dstBitmap != srcBitmap && tryRecycleSource) {
                srcBitmap.recycle();
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return dstBitmap;
    }

    /**
     * 以FitCenter方式生成图片
     *
     * @param srcBitmap        原始图片
     * @param dstWidth         目标图片宽度
     * @param dstHeight        目标图片高度
     * @param tryRecycleSource 是否尽量回收原图
     * @return 如果创建不成功返回原图
     */
    public static Bitmap createFitCenterBitmap(Bitmap srcBitmap, int dstWidth, int dstHeight, boolean tryRecycleSource) {
        if (srcBitmap == null || dstWidth <= 0 || dstHeight <= 0) {
            return srcBitmap;
        }

        int srcWidth = srcBitmap.getWidth();
        int srcHeight = srcBitmap.getHeight();
        int newWidth = srcWidth;
        int newHeight = srcHeight;

        if (newWidth > dstWidth) {
            newHeight = dstWidth * newHeight / newWidth;
            newWidth = dstWidth;
        }

        if (newHeight > dstHeight) {
            newWidth = dstHeight * newWidth / newHeight;
            newHeight = dstHeight;
        }

        return createFitXYBitmap(srcBitmap, newWidth, newHeight, tryRecycleSource);
    }

    /**
     * 以CenterCrop方式生成图片
     *
     * @param srcBitmap        原始图片
     * @param dstWidth         目标图片宽度
     * @param dstHeight        目标图片高度
     * @param tryRecycleSource 是否尽量回收原图
     * @return 如果创建不成功返回原图
     */
    public static Bitmap createCenterCropBitmap(Bitmap srcBitmap, int dstWidth, int dstHeight, boolean tryRecycleSource) {
        if (srcBitmap == null || dstWidth == 0 || dstHeight == 0) {
            return srcBitmap;
        }
        int srcWidth = srcBitmap.getWidth();
        int srcHeight = srcBitmap.getHeight();
        Bitmap dstBitmap = srcBitmap;
        try {
            if (srcWidth > dstWidth && srcHeight > dstHeight) {
                dstBitmap = Bitmap.createBitmap(srcBitmap, (srcWidth - dstWidth) / 2, (srcHeight - dstHeight) / 2, dstWidth, dstHeight);
            } else if ((dstHeight * srcWidth) > (srcHeight * dstWidth)) {
                int newWidth = (srcHeight * dstWidth) / dstHeight;
                dstBitmap = Bitmap.createBitmap(srcBitmap, (srcWidth - newWidth) / 2, 0, newWidth, srcHeight);
            } else {
                int newHeight = (dstHeight * srcWidth) / dstWidth;
                dstBitmap = Bitmap.createBitmap(srcBitmap, 0, (srcHeight - newHeight) / 2, srcWidth, newHeight);
            }
            if (dstBitmap != srcBitmap && tryRecycleSource) {
                srcBitmap.recycle();
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return dstBitmap;
    }

    /**
     * 对图片进行模糊处理
     *
     * @param context    context
     * @param sentBitmap 原始图片
     * @param radius     模糊度，如3
     * @return 模糊后的图片
     */
    public static Bitmap fastBlur(Context context, Bitmap sentBitmap, int radius) {
        // 当API版本大于16时，直接调用系统的模糊功能处理图片
        // HTC OneX部分固件bug，无法使用以下方式
/*        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN) {
            Bitmap bitmap = sentBitmap.copy(sentBitmap.getConfig(), true);
            final RenderScript rs = RenderScript.create(context);
            final Allocation input = Allocation.createFromBitmap(rs, sentBitmap
                    , Allocation.MipmapControl.MIPMAP_NONE
                    , Allocation.USAGE_SCRIPT);
            final Allocation output = Allocation.createTyped(rs, input.getType());
            final ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
            script.setRadius(radius);
            script.setInput(input);
            script.forEach(output);
            output.copyTo(bitmap);
            return bitmap;
        }*/
        return fastBlurInJava(sentBitmap, radius);
    }

    private static int[] fastBlurToColorsInJava(Bitmap sentBitmap, int radius) {

        int w = sentBitmap.getWidth();
        int h = sentBitmap.getHeight();

        int[] pix = new int[w * h];
        sentBitmap.getPixels(pix, 0, w, 0, 0, w, h);

        int wm = w - 1;
        int hm = h - 1;
        int wh = w * h;
        int div = radius + radius + 1;

        int r[] = new int[wh];
        int g[] = new int[wh];
        int b[] = new int[wh];
        int rsum, gsum, bsum, x, y, i, p, yp, yi, yw;
        int vmin[] = new int[Math.max(w, h)];

        int divsum = (div + 1) >> 1;
        divsum *= divsum;
        int dv[] = new int[256 * divsum];
        for (i = 0; i < 256 * divsum; i++) {
            dv[i] = (i / divsum);
        }

        yw = yi = 0;

        int[][] stack = new int[div][3];
        int stackpointer;
        int stackstart;
        int[] sir;
        int rbs;
        int r1 = radius + 1;
        int routsum, goutsum, boutsum;
        int rinsum, ginsum, binsum;

        for (y = 0; y < h; y++) {
            rinsum = ginsum = binsum = routsum = goutsum = boutsum = rsum = gsum = bsum = 0;
            for (i = -radius; i <= radius; i++) {
                p = pix[yi + Math.min(wm, Math.max(i, 0))];
                sir = stack[i + radius];
                sir[0] = (p & 0xff0000) >> 16;
                sir[1] = (p & 0x00ff00) >> 8;
                sir[2] = (p & 0x0000ff);
                rbs = r1 - Math.abs(i);
                rsum += sir[0] * rbs;
                gsum += sir[1] * rbs;
                bsum += sir[2] * rbs;
                if (i > 0) {
                    rinsum += sir[0];
                    ginsum += sir[1];
                    binsum += sir[2];
                } else {
                    routsum += sir[0];
                    goutsum += sir[1];
                    boutsum += sir[2];
                }
            }
            stackpointer = radius;

            for (x = 0; x < w; x++) {

                r[yi] = dv[rsum];
                g[yi] = dv[gsum];
                b[yi] = dv[bsum];

                rsum -= routsum;
                gsum -= goutsum;
                bsum -= boutsum;

                stackstart = stackpointer - radius + div;
                sir = stack[stackstart % div];

                routsum -= sir[0];
                goutsum -= sir[1];
                boutsum -= sir[2];

                if (y == 0) {
                    vmin[x] = Math.min(x + radius + 1, wm);
                }
                p = pix[yw + vmin[x]];

                sir[0] = (p & 0xff0000) >> 16;
                sir[1] = (p & 0x00ff00) >> 8;
                sir[2] = (p & 0x0000ff);

                rinsum += sir[0];
                ginsum += sir[1];
                binsum += sir[2];

                rsum += rinsum;
                gsum += ginsum;
                bsum += binsum;

                stackpointer = (stackpointer + 1) % div;
                sir = stack[(stackpointer) % div];

                routsum += sir[0];
                goutsum += sir[1];
                boutsum += sir[2];

                rinsum -= sir[0];
                ginsum -= sir[1];
                binsum -= sir[2];

                yi++;
            }
            yw += w;
        }
        for (x = 0; x < w; x++) {
            rinsum = ginsum = binsum = routsum = goutsum = boutsum = rsum = gsum = bsum = 0;
            yp = -radius * w;
            for (i = -radius; i <= radius; i++) {
                yi = Math.max(0, yp) + x;

                sir = stack[i + radius];

                sir[0] = r[yi];
                sir[1] = g[yi];
                sir[2] = b[yi];

                rbs = r1 - Math.abs(i);

                rsum += r[yi] * rbs;
                gsum += g[yi] * rbs;
                bsum += b[yi] * rbs;

                if (i > 0) {
                    rinsum += sir[0];
                    ginsum += sir[1];
                    binsum += sir[2];
                } else {
                    routsum += sir[0];
                    goutsum += sir[1];
                    boutsum += sir[2];
                }

                if (i < hm) {
                    yp += w;
                }
            }
            yi = x;
            stackpointer = radius;
            for (y = 0; y < h; y++) {
                // Preserve alpha channel: ( 0xff000000 & pix[yi] )
                pix[yi] = (0xff000000 & pix[yi]) | (dv[rsum] << 16) | (dv[gsum] << 8) | dv[bsum];

                rsum -= routsum;
                gsum -= goutsum;
                bsum -= boutsum;

                stackstart = stackpointer - radius + div;
                sir = stack[stackstart % div];

                routsum -= sir[0];
                goutsum -= sir[1];
                boutsum -= sir[2];

                if (x == 0) {
                    vmin[y] = Math.min(y + r1, hm) * w;
                }
                p = x + vmin[y];

                sir[0] = r[p];
                sir[1] = g[p];
                sir[2] = b[p];

                rinsum += sir[0];
                ginsum += sir[1];
                binsum += sir[2];

                rsum += rinsum;
                gsum += ginsum;
                bsum += binsum;

                stackpointer = (stackpointer + 1) % div;
                sir = stack[stackpointer];

                routsum += sir[0];
                goutsum += sir[1];
                boutsum += sir[2];

                rinsum -= sir[0];
                ginsum -= sir[1];
                binsum -= sir[2];

                yi += w;
            }
        }
        return pix;
    }

    private static Bitmap fastBlurInJava(Bitmap sentBitmap, int radius) {
        if (radius < 1 || sentBitmap == null) {
            return null;
        }
        int width = sentBitmap.getWidth(), height = sentBitmap.getHeight();
        if (width <= 0 || height <= 0) {
            return null;
        }
        return Bitmap.createBitmap(fastBlurToColorsInJava(sentBitmap, radius), 0, width, width, height, sentBitmap.getConfig());
    }

    /**
     * 将Bitmap存为png格式图片
     *
     * @param filename 文件名
     * @param bitmap   图片
     */
    public static void saveBitmapToPng(String filename, Bitmap bitmap) {
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(new File(filename));
            BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
            bitmap.compress(Bitmap.CompressFormat.PNG, 0, bos);
            bos.flush();
            bos.close();
        } catch (Exception ignored) {
            ignored.printStackTrace();
            if (fileOutputStream != null) {
                try {
                    fileOutputStream.close();
                } catch (Exception ignored2) {
                    ignored2.printStackTrace();
                }
            }
        }
    }

    /**
     * 转换drawable到bitmap
     *
     * @param drawable drawable
     * @param width    width
     * @param height   height
     * @return bitmap
     */
    public static Bitmap drawableToBitmap(Drawable drawable, int width, int height) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, width, height);
        drawable.draw(canvas);
        return bitmap;
    }

    /**
     * set prefer use rgb 8888
     *
     * @param enable enable
     */
    public void setPreferUseRgb8888(boolean enable) {
        mPreferUseRgb8888 = enable;
    }

    private BitmapFactory.Options createDefaultOptions() {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inDither = mPreferUseRgb8888;
        return options;
    }

    /**
     * @param cancelLastDecode 是否重新new解码参数，通常为false
     */
    private void resetBitmapFactoryOptions(boolean cancelLastDecode) {
        if (cancelLastDecode && mBitmapFactoryOptions != null) {
            mBitmapFactoryOptions.requestCancelDecode();
        }
        mBitmapFactoryOptions = newBitmapOptionsWithInitOptions();
        mPreDecoded = false;
    }

    private BitmapFactory.Options newBitmapOptionsWithInitOptions() {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inDither = mInitBitmapFactoryOptions.inDither;
        options.inJustDecodeBounds = mInitBitmapFactoryOptions.inJustDecodeBounds;
        options.inPreferredConfig = mInitBitmapFactoryOptions.inPreferredConfig;
        options.inDensity = mInitBitmapFactoryOptions.inDensity;
        options.inInputShareable = mInitBitmapFactoryOptions.inInputShareable;
        options.inTempStorage = mInitBitmapFactoryOptions.inTempStorage;
        options.inTargetDensity = mInitBitmapFactoryOptions.inTargetDensity;
        options.inScreenDensity = mInitBitmapFactoryOptions.inScreenDensity;
        options.inSampleSize = mInitBitmapFactoryOptions.inSampleSize;
        options.inPurgeable = mInitBitmapFactoryOptions.inPurgeable;
        return options;
    }

    /**
     * get bitmap factory options
     *
     * @return bitmap factory options
     */
    public BitmapFactory.Options getBitmapFactoryOptions() {
        return mInitBitmapFactoryOptions;
    }

    /**
     * 解码图片.
     *
     * @param filePath 文件路径
     * @return 位图
     */
    public Bitmap decodeBitmap(String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return null;
        }
        resetBitmapFactoryOptions(false);
        if (needResetAlphaChannel()) {
            mBitmapFactoryOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(filePath, mBitmapFactoryOptions);
            initAlphaChannel(mBitmapFactoryOptions);
            mBitmapFactoryOptions.inJustDecodeBounds = false;
        }
        return processBitmapAlpha(BitmapFactory.decodeFile(filePath, mBitmapFactoryOptions));
    }

    /**
     * 解码图片
     *
     * @param filePath  路径
     * @param maxWidth  最大宽度
     * @param maxHeight 最大高度
     * @return 图片
     */
    public Bitmap decodeBitmap(String filePath, int maxWidth, int maxHeight) {
        return decodeBitmap(filePath, maxWidth, maxHeight, false);
    }

    /**
     * 解码图片
     *
     * @param filePath         路径
     * @param maxWidth         最大宽度
     * @param maxHeight        最大高度
     * @param cancelLastDecode 是否重新new解码参数，通常为false
     * @return 图片
     */
    public Bitmap decodeBitmap(String filePath, int maxWidth, int maxHeight, boolean cancelLastDecode) {
        try {
            if (!TextUtils.isEmpty(filePath) && maxWidth > 0 && maxHeight > 0) {
                resetBitmapFactoryOptions(cancelLastDecode);
                mBitmapFactoryOptions.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(filePath, mBitmapFactoryOptions);
                if (initBitmapFactoryOptions(mBitmapFactoryOptions, maxWidth, maxHeight)) {
                    if (needResetAlphaChannel()) {
                        initAlphaChannel(mBitmapFactoryOptions);
                    }
                    LogUtils.d(LOG_TAG, "decodeBitmap, filePath: " + filePath);
                    return processBitmapAlpha(BitmapFactory.decodeFile(filePath, mBitmapFactoryOptions));
                }
            }
        } catch (OutOfMemoryError error) {
            LogUtils.d(LOG_TAG, "decodeBitmap OutOfMemoryError filePath=" + filePath);
        }

        return null;
    }

    private Bitmap processBitmapAlpha(Bitmap bitmap) {
        // 需要先判断是否为空才能设置，磁盘满或者其它情况都会导致传入的bitmap为空
        if (bitmap == null) {
            return null;
        }
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.HONEYCOMB) {
            bitmap.setHasAlpha(!mayNotHasAlphaChannel(mBitmapFactoryOptions));
        }
        return bitmap;
    }

    private boolean needResetAlphaChannel() {
        return mBitmapFactoryOptions.inPreferredConfig == Bitmap.Config.ARGB_8888 && !mPreferUseRgb8888;
    }

    /**
     * 解码资源图片
     *
     * @param res   资源
     * @param resId 资源id
     * @return bitmap
     */
    public Bitmap decodeBitmap(Resources res, int resId) {
        if (resId != 0) {
            resetBitmapFactoryOptions(false);
            if (needResetAlphaChannel()) {
                mBitmapFactoryOptions.inJustDecodeBounds = true;
                BitmapFactory.decodeResource(res, resId, mBitmapFactoryOptions);
                initAlphaChannel(mBitmapFactoryOptions);
                mBitmapFactoryOptions.inJustDecodeBounds = false;
            }
            return processBitmapAlpha(BitmapFactory.decodeResource(res, resId, mBitmapFactoryOptions));
        }
        return null;
    }

    /**
     * 解码资源图片
     *
     * @param res       资源
     * @param resId     资源id
     * @param maxWidth  最大宽度
     * @param maxHeight 最大高度
     * @return bitmap
     */
    public Bitmap decodeBitmap(Resources res, int resId, int maxWidth, int maxHeight) {
        if (resId != 0 && maxHeight > 0 && maxWidth > 0) {
            resetBitmapFactoryOptions(false);
            mBitmapFactoryOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeResource(res, resId, mBitmapFactoryOptions);
            if (initBitmapFactoryOptions(mBitmapFactoryOptions, maxWidth, maxHeight)) {
                if (needResetAlphaChannel()) {
                    initAlphaChannel(mBitmapFactoryOptions);
                }
                return processBitmapAlpha(BitmapFactory.decodeResource(res, resId, mBitmapFactoryOptions));
            }
        }
        return null;
    }

    /**
     * 从byte中解码
     *
     * @param bytes  数据
     * @param offset 偏移
     * @param length 长度
     * @return bitmap
     */
    public Bitmap decodeBitmap(byte[] bytes, int offset, int length) {
        if (bytes != null) {
            resetBitmapFactoryOptions(false);
            if (needResetAlphaChannel()) {
                mBitmapFactoryOptions.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, offset, length, mBitmapFactoryOptions);
                initAlphaChannel(mBitmapFactoryOptions);
                mBitmapFactoryOptions.inJustDecodeBounds = false;
            }
            return processBitmapAlpha(BitmapFactory.decodeByteArray(bytes, offset, length, mBitmapFactoryOptions));
        }
        return null;
    }

    /**
     * 解码图片
     *
     * @param bytes     数据
     * @param offset    偏移
     * @param length    长度
     * @param maxWidth  最大宽度
     * @param maxHeight 最大高度
     * @return 图片
     */
    public Bitmap decodeBitmap(byte[] bytes, int offset, int length, int maxWidth, int maxHeight) {
        if (bytes != null && maxHeight > 0 && maxWidth > 0) {
            resetBitmapFactoryOptions(false);
            mBitmapFactoryOptions.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, offset, length, mBitmapFactoryOptions);
            if (initBitmapFactoryOptions(mBitmapFactoryOptions, maxWidth, maxHeight)) {
                if (needResetAlphaChannel()) {
                    initAlphaChannel(mBitmapFactoryOptions);
                }
                return processBitmapAlpha(BitmapFactory.decodeByteArray(bytes, offset, length, mBitmapFactoryOptions));
            }
        }
        return null;
    }

    /**
     * 解码图片
     *
     * @param inputStream 输入流
     * @return 输出
     */
    public Bitmap decodeBitmap(InputStream inputStream) {
        if (inputStream != null) {
            if (!mPreDecoded) {
                resetBitmapFactoryOptions(false);
                if (needResetAlphaChannel()) {
                    mBitmapFactoryOptions.inJustDecodeBounds = true;
                    BitmapFactory.decodeStream(inputStream, null, mBitmapFactoryOptions);
                    initAlphaChannel(mBitmapFactoryOptions);
                    mBitmapFactoryOptions.inJustDecodeBounds = false;
                }
            }
            return processBitmapAlpha(BitmapFactory.decodeStream(inputStream, null, mBitmapFactoryOptions));
        }
        return null;
    }

    /**
     * 预解码图片，流数据需要重新打开以读取图片
     *
     * @param inputStream 输入流
     * @param maxWidth    最大宽度
     * @param maxHeight   最大高度
     */
    public void preDecodeBitmap(InputStream inputStream, int maxWidth, int maxHeight) {
        if (inputStream != null && maxHeight > 0 && maxWidth > 0) {
            resetBitmapFactoryOptions(false);
            mBitmapFactoryOptions.inJustDecodeBounds = true;
            try {
                inputStream.mark(inputStream.available());
            } catch (IOException e) {
                e.printStackTrace();
            }
            BitmapFactory.decodeStream(inputStream, null, mBitmapFactoryOptions);
            if (initBitmapFactoryOptions(mBitmapFactoryOptions, maxWidth, maxHeight) && needResetAlphaChannel()) {
                initAlphaChannel(mBitmapFactoryOptions);
            }
            mPreDecoded = true;
        }
    }

    /**
     * 解码图片为方形图片.
     *
     * @param filePath         文件路径
     * @param squareLength     长度
     * @param cancelLastDecode 是否重新new解码参数，通常为false
     * @return 位图
     */
    public Bitmap decodeFileToSquareBitmap(String filePath, int squareLength, boolean cancelLastDecode) {
//		TTLog.e(LOG_TAG, String.format("decodeFileToSquareBitmap ThreadId=%d %s squareLength=%d"
//				, Thread.currentThread().getId(), filePath, squareLength));

        Bitmap decodedBitmap = decodeBitmap(filePath, squareLength, squareLength, cancelLastDecode);
        if (decodedBitmap != null) {
            Bitmap bitmap = cropBitmapToSquare(decodedBitmap, squareLength);
            if (decodedBitmap != bitmap) {
                decodedBitmap.recycle();
            } else {
                LogUtils.e(LOG_TAG, "decodeFileToSquareBitmap bitmap == decodeBitmap");
            }
            return bitmap;
        }
        return null;
    }

    /**
     * 获取圆角位图的方法(效率不如RoundedImageView好，但该方法不会产生锯齿）
     *
     * @param bitmap 需要转化成圆角的位图
     * @param pixels 圆角的度数，数值越大，圆角越大
     * @return 处理后的圆角位图
     */
    public static Bitmap toRoundCorner(Bitmap bitmap, int pixels) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
                bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        final float roundPx = pixels;
        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }


    // 原PhotoUtils

    /**
     * 获取指定路径下的图片的指定大小的缩略图 getImageThumbnail
     *
     * @return Bitmap
     * @throws
     */
    public static Bitmap getImageThumbnail(String imagePath, int width,
                                           int height) {
        Bitmap bitmap = null;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        // 获取这个图片的宽和高，注意此处的bitmap为null
        bitmap = BitmapFactory.decodeFile(imagePath, options);
        options.inJustDecodeBounds = false; // 设为 false
        // 计算缩放比
        int h = options.outHeight;
        int w = options.outWidth;
        int beWidth = w / width;
        int beHeight = h / height;
        int be = 1;
        if (beWidth < beHeight) {
            be = beWidth;
        } else {
            be = beHeight;
        }
        if (be <= 0) {
            be = 1;
        }
        options.inSampleSize = be;
        // 重新读入图片，读取缩放后的bitmap，注意这次要把options.inJustDecodeBounds 设为 false
        bitmap = BitmapFactory.decodeFile(imagePath, options);
        // 利用ThumbnailUtils来创建缩略图，这里要指定要缩放哪个Bitmap对象
        bitmap = ThumbnailUtils.extractThumbnail(bitmap, width, height,
                ThumbnailUtils.OPTIONS_RECYCLE_INPUT);
        return bitmap;
    }

    public static void saveBitmap(String dirpath, String filename,
                                  Bitmap bitmap, boolean isDelete) {
        File dir = new File(dirpath);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        File file = new File(dirpath, filename);
        if (isDelete) {
            if (file.exists()) {
                file.delete();
            }
        }

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(file);
            if (bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                out.flush();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static File getFilePath(String filePath, String fileName) {
        File file = null;
        makeRootDirectory(filePath);
        try {
            file = new File(filePath + fileName);
            if (!file.exists()) {
                file.createNewFile();
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return file;
    }

    public static void makeRootDirectory(String filePath) {
        File file = null;
        try {
            file = new File(filePath);
            if (!file.exists()) {
                file.mkdirs();
            }
        } catch (Exception e) {

        }
    }

    /**
     * 读取图片属性：旋转的角度
     *
     * @param path 图片绝对路径
     * @return degree旋转的角度
     */

    public static int readPictureDegree(String path) {
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(path);
            int orientation = exifInterface.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return degree;

    }

    /**
     * 旋转图片一定角度
     * rotaingImageView
     *
     * @return Bitmap
     * @throws
     */
    public static Bitmap rotaingImageView(int angle, Bitmap bitmap) {
        // 旋转图片 动作
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        // 创建新的图片
        Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0,
                bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        return resizedBitmap;
    }


    /**
     * 将图片转化为圆形头像
     *
     * @throws
     * @Title: toRoundBitmap
     */
    public static Bitmap toRoundBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float roundPx;
        float left, top, right, bottom, dst_left, dst_top, dst_right, dst_bottom;
        if (width <= height) {
            roundPx = width / 2;

            left = 0;
            top = 0;
            right = width;
            bottom = width;

            height = width;

            dst_left = 0;
            dst_top = 0;
            dst_right = width;
            dst_bottom = width;
        } else {
            roundPx = height / 2;

            float clip = (width - height) / 2;

            left = clip;
            right = width - clip;
            top = 0;
            bottom = height;
            width = height;

            dst_left = 0;
            dst_top = 0;
            dst_right = height;
            dst_bottom = height;
        }

        Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final Paint paint = new Paint();
        final Rect src = new Rect((int) left, (int) top, (int) right,
                (int) bottom);
        final Rect dst = new Rect((int) dst_left, (int) dst_top,
                (int) dst_right, (int) dst_bottom);
        final RectF rectF = new RectF(dst);

        paint.setAntiAlias(true);// 设置画笔无锯齿

        canvas.drawARGB(0, 0, 0, 0); // 填充整个Canvas

        // 以下有两种方法画圆,drawRounRect和drawCircle
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);// 画圆角矩形，第一个参数为图形显示区域，第二个参数和第三个参数分别是水平圆角半径和垂直圆角半径。
        // canvas.drawCircle(roundPx, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));// 设置两张图片相交时的模式,参考http://trylovecatch.iteye.com/blog/1189452
        canvas.drawBitmap(bitmap, src, dst, paint); // 以Mode.SRC_IN模式合并bitmap和已经draw了的Circle

        return output;
    }

    public static String simpleCompressImage(String path, String newPath) {
        Bitmap bitmap = BitmapFactory.decodeFile(path);
        FileOutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(newPath);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        recycle(bitmap);
        return newPath;
    }

    public static void recycle(Bitmap bitmap) {
        // 先判断是否已经回收
        if (bitmap != null && !bitmap.isRecycled()) {
            // 回收并且置为null
            bitmap.recycle();
        }
        System.gc();
    }
}
