package njnu.kai.utils;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 蓝牙.
 *
 * @version 1.0.0
 */
public class BlueToothUtils {
    /**
     * 蓝牙发送文件
     *
     * @param context Context
     * @param files   需要发送的文件
     */
    public static void sendFile(Context context, File[] files) {
        if (files != null && files.length > 0) {
            if (isBlueToothEnable(context)) {
                startBlueToothActivity(context, files);
            } else {
                ToastUtils.showToast("你的设备不支持蓝牙功能。");
            }
        }
    }

    /**
     * 蓝牙是否有效
     *
     * @param context 上下文对象
     * @return 蓝牙是否有效
     */
    public static boolean isBlueToothEnable(Context context) {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        return bluetoothAdapter != null;
    }

    /**
     * @param context 上下文对象
     * @param files   传输的文件
     */
    public static void startBlueToothActivity(Context context, File[] files) {
        Intent shareIntent = new Intent();
        shareIntent.setType("*/*");

        if (files.length > 1) {
            ArrayList<Uri> uris = new ArrayList<Uri>(files.length);
            for (File file : files) {
                uris.add(Uri.fromFile(file));
            }
            shareIntent.putExtra(Intent.EXTRA_STREAM, uris);
            shareIntent.setAction(Intent.ACTION_SEND_MULTIPLE);
        } else {
            shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(files[0]));
            shareIntent.setAction(Intent.ACTION_SEND);
        }

        PackageManager packageManager = context.getPackageManager();
        List<ResolveInfo> shareInfo = packageManager.queryIntentActivities(shareIntent, PackageManager.COMPONENT_ENABLED_STATE_DEFAULT);
        String packageName = "";
        String activityName = "";
        for (ResolveInfo resolveInfo : shareInfo) {
            if (resolveInfo.activityInfo.packageName.contains("bluetooth")) {
                packageName = resolveInfo.activityInfo.packageName;
                activityName = resolveInfo.activityInfo.name;
                break;
            }
        }
        shareIntent.setClassName(packageName, activityName);

        if (context instanceof Activity) {
            try {
                ((Activity) context).startActivityForResult(shareIntent, 1);
            } catch (ActivityNotFoundException exception) {
                exception.printStackTrace();
            }
        }
    }
}
