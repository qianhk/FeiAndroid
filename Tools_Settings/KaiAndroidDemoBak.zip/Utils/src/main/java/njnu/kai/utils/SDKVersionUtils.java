//package njnu.kai.utils;
//
//import android.os.Build;
//
///**
// * @version 1.0.0
// */
//public class SDKVersionUtils {
//
////    /**
////     * 4.4及以上
////     *
////     * @return 4.4及以上
////     */
////    public static boolean hasKitKat() {
////        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;
////    }
////
////    /**
////     * 5.0及以上
////     *
////     * @return 5.0及以上
////     */
////    public static boolean hasLollipop() {
////        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
////    }
//}
