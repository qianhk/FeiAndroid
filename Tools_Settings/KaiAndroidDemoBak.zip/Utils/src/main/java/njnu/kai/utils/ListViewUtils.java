package njnu.kai.utils;

import android.widget.*;
import android.widget.AbsListView.OnScrollListener;

/**
 * ListView相关工具方法
 *
 * @version 1.0.0
 */
public class ListViewUtils {

    /**
     * 列表是否在滑动
     */
    private static boolean mIsListScrolling = false;

    /**
     * 获取有效的数据位置，排除列表头项及底部项对点击事件的影响
     *
     * @param headCount   列表头个数
     * @param srcPosition 列表项位置
     * @param total       列表数据总数（不包括头和底部UI数量）
     * @return 如果返回 > -1 则是有效的位置，否则为无效的位置
     */
    public static int getValidListViewItemPosition(int headCount, int srcPosition, int total) {
        if (headCount < 0 || srcPosition < 0 || total < 0) {
            throw new IllegalArgumentException("headCount,srcPosition,total must be >= 0");
        }

        int position = srcPosition - headCount;

        if (position >= 0 && position < total) {
            return position;
        }

        return -1;
    }

    /**
     * 是否允许页滚动
     *
     * @param firstVisibleItem 第一项位置
     * @param visibleItemCount 可见项数量
     * @param totalItemCount   总数据量
     * @return 是否允许页滚动
     */
    public static boolean isPageScrollEnable(int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        return (totalItemCount >= visibleItemCount) && ((totalItemCount - firstVisibleItem) <= visibleItemCount);
    }

    /**
     * 更新列表的滑动状态
     *
     * @param scroll      滑动状态
     * @param listAdapter listAdapter
     */
    public static void updateListScrollStatus(boolean scroll, BaseAdapter listAdapter) {
        mIsListScrolling = scroll;
        //停止滑动时，更新界面显示
        if (!mIsListScrolling) {
            listAdapter.notifyDataSetChanged();
        }
    }

    /**
     * 如果列表在滑动，则将一个图片绑定到ImageView，负责不做任何处理
     *
     * @param imageView   待绑定的Image view
     * @param drawableRes 图片资源id
     * @return true： 绑定到默认图片
     */
    public static boolean bindImageViewDrawable(ImageView imageView, int drawableRes) {
        if (mIsListScrolling) {
            if (drawableRes > 0) {
                imageView.setImageResource(drawableRes);
            }
            imageView.setTag(" ");
            return true;
        }
        return false;
    }

    /**
     * 列表滑动的监听器
     */
    public static class OnListViewScrollingListener implements OnScrollListener {
        @Override
        public void onScrollStateChanged(AbsListView view, int scrollState) {
            Adapter adapter = view.getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }
            updateListScrollStatus(SCROLL_STATE_IDLE != scrollState, (BaseAdapter) adapter);
        }

        @Override
        public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

        }
    }

}
