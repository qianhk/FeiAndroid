package njnu.kai.utils;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

import njnu.kai.AppConfig;

/**
 * @author kai
 * @version 1.0.0
 */
public final class ClipboardUtils {

    /**
     * 设置剪贴板的文字内容
     *
     * @param context context
     * @param text    text
     */
    public static void setText(Context context, CharSequence text) {
        ClipboardManager cbManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clipData = ClipData.newPlainText(AppConfig.getDirName(), text);
        cbManager.setPrimaryClip(clipData);
    }
}
