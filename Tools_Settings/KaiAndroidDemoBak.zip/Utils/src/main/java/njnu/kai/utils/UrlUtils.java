package njnu.kai.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.URLUtil;
import okhttp3.HttpUrl;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class UrlUtils {
    /**
     * 由url ＋ 参数创建带参数的Url
     *
     * @param url    url
     * @param params 参数
     * @return 拼接好的URL地址
     */
    public static HttpUrl buildUrl(String url, Map<String, Object> params) {
        HttpUrl baseHttpUrl = null;
        if (url != null) {
            baseHttpUrl = HttpUrl.parse(url);
        }
        HttpUrl.Builder builder;
        if (baseHttpUrl == null) {
            builder = new HttpUrl.Builder();
            builder.scheme("http");
            builder.host("127.0.0.1");
        } else {
            builder = baseHttpUrl.newBuilder();
        }
        if (params != null) {
            for (Map.Entry<String, Object> stringObjectEntry : params.entrySet()) {
                builder.addQueryParameter(stringObjectEntry.getKey(), stringObjectEntry.getValue().toString());
            }
        }
        return builder.build();
    }

    /**
     * 解析url中的参数
     *
     * @param url 用于解析的Url
     * @return 参数的map
     */
    public static Map<String, Object> getParams(String url) {
        Map<String, Object> params = new LinkedHashMap<String, Object>();

        if (!StringUtils.isEmpty(url)) {
            int idx = url.indexOf('?');
            if (idx != -1) {
                url = url.substring(idx + 1);
                String[] parameter = url.split("&");
                for (String param : parameter) {
                    String[] values = param.split("=");
                    params.put(values[0], values[1]);
                }
            }
        }

        return params;
    }

    /**
     * 解析主机地址
     *
     * @param url 用于解析的Url
     * @return 主机地址
     */
    public static String getHost(String url) {
        if (!StringUtils.isEmpty(url)) {
            return url.substring(0, url.indexOf('?'));
        }

        return url;
    }

    /**
     * 从url解析文件名 如：http://www.baidu.com/xxx.jpg 解析的结果为:xxx.jpg
     *
     * @param url 用于解析的Url
     * @return 文件名
     */
    public static String getFileName(String url) {
        return FileUtils.getFileName(url);
    }

    /**
     * 将url参数转成bundle
     *
     * @param url url地址
     * @return 返回bundle
     */
    public static Bundle parseUrlParameter(String url) {
        try {
            URL u = new URL(url);
            Bundle b = decodeUrlParameter(u.getQuery());
            b.putAll(decodeUrlParameter(u.getRef()));
            return b;
        } catch (MalformedURLException e) {
            return new Bundle();
        }
    }

    /**
     * 将参数，转成bundler
     *
     * @param s url参数部分
     * @return bunlder对象
     */
    public static Bundle decodeUrlParameter(String s) {
        Bundle bundle = new Bundle();
        if (s != null) {
            String[] array = s.split("&");
            for (String parameter : array) {
                String[] v = parameter.split("=");
                if (v != null && v.length > 1) {
                    bundle.putString(URLDecoder.decode(v[0]), URLDecoder.decode(v[1]));
                }
            }
        }
        return bundle;
    }

    /**
     * 将bundler转成url参数
     *
     * @param bundle bunlder对象
     * @return url参数
     */
    public static String encodeUrlParameter(Bundle bundle) {
        if (bundle == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        Iterator<String> it = bundle.keySet().iterator();
        while (it.hasNext()) {
            if (first) {
                first = false;
            } else {
                sb.append("&");
            }
            String key = it.next();
            String value = bundle.getString(key);
            if (value != null) {
                sb.append(URLEncoder.encode(key) + "=" + URLEncoder.encode(value));
            }
        }
        return sb.toString();
    }

    /**
     * 修正网络url
     *
     * @param url url
     * @return 修正后的url
     */
    private static String amendNetworkUrl(String url) {
        if (!URLUtil.isNetworkUrl(url)) {
            url = "http://" + url;
        }
        return url;
    }

    /**
     * 启动外部浏览器
     *
     * @param context context
     * @param url     url
     */
    public static void startupExternalBrowser(Context context, String url) {
        try {
            Intent localIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(amendNetworkUrl(url)));
            localIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(localIntent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
