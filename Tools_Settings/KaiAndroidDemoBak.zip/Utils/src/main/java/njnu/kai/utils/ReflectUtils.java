package njnu.kai.utils;

import java.lang.reflect.Method;

/**
 * @version 7.0.0
 */
public class ReflectUtils {

    /**
     * 获取方法实例
     *
     * @param cls            方法所在的类
     * @param methodName     方法名
     * @param parameterTypes 方法参数
     * @return 方法引用
     * @throws NoSuchMethodException NoSuchMethodException
     */
    public static Method getMethod(Class cls, String methodName, Class<?>... parameterTypes) throws NoSuchMethodException {
        DebugUtils.assertNotNull(cls, "cls");
        DebugUtils.assertNotNull(methodName, "methodName");
        try {
            try {
                return cls.getMethod(methodName, parameterTypes);
            } catch (Exception e) {
                return cls.getDeclaredMethod(methodName, parameterTypes);
            }
        } catch (Exception e) {
            Class tmpCls = cls;
            do {
                try {
                    Method[] methods = null;
                    try {
                        methods = tmpCls.getMethods();
                    } catch (Exception e2) {
                        methods = tmpCls.getDeclaredMethods();
                    }

                    for (Method method : methods) {
                        if (method.getName().equals(methodName)) {
                            if (isParametersMatch(parameterTypes, method.getParameterTypes())) {
                                return method;
                            }
                        }
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }

                tmpCls = tmpCls.getSuperclass();
            } while (tmpCls != null);

            throw new NoSuchMethodException(methodName + " not found in class " + cls.getName());
        }
    }

    private static boolean isParametersMatch(Class[] types1, Class[] types2) {
        if (types1 == null && types2 == null) {
            return true;
        }

        if (types1 != null && types2 != null && types1.length == types2.length) {
            int paramCount = types1.length;
            for (int i = 0; i < paramCount; i++) {
                if (!types1[i].getName().equals(types2[i].getName())) {
                    return false;
                }
            }

            return true;
        }

        return false;
    }
}
