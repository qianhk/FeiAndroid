package njnu.kai.utils;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public class ConstantUtils {

    /**
     * 百(十进制)
     */
    public static final int HUNDRED = 100;

    /**
     * 十(十进制)
     */
    public static final int TEN = 10;

    /**
     * 千1000
     */
    public static final int THOUSAND = 1000;


    /**
     * 一天有多少毫秒
     */
    public static final int MILLS_PER_DAY = 24 * 60 * 60 * 1000;

    /**
     * 一小时有多少毫秒
     */
    public static final int MILLS_PER_HOUR = 60 * 60 * 1000;

    /**
     * 半秒里有多少毫秒.
     */
    public static final int HALF_SECOND_IN_MILLS = 500;

    /**
     * 一分钟60秒
     */
    public static final int SECONDS_PER_MINUTE = 60;

    /**
     * 一小时60分
     */
    public static final int MINUTE_PER_HOUR = 60;

    /**
     * 一分钟有多少毫秒
     */
    public static final int MILLS_PER_MIN = 60 * 1000;

    /**
     * 一秒有多少毫秒
     */
    public static final int MILLIS_PER_SECOND = 1000;


    /**
     * 高16位掩码
     */
    public static final int MASK_HIGH_16_BITS = 0xFFFF0000;

    /**
     * 低16位掩码
     */
    public static final int MASK_LOW_16_BITS = 0x0000FFFF;

    /**
     * 16位偏移
     */
    public static final int OFFSET_16_BITS = 16;

    /**
     * hashCode()使用的系数
     */
    public static final int HASHCODE_FACTOR = 31;

    /**
     * KB字节数
     */
    public static final int KILO = 1024;

    /**
     * 空字符串，用于避免字符串为null的场合
     */
    public static final String BLANK_STRING = "";

    /**
     * 临时文件扩展名
     */
    public static final String TMP_EXT = ".tmp";

    /**
     * http请求错误码最小值，小于这个值的为正常的http请求，否则为错误的http请求
     */
    public static final int HTTP_ERROR_CODE_BASE_LINE = 400;

    /**
     * request code base value
     */
    public static final int REQUEST_CODE_BASE = 0x8000;

    /**
     * KB *
     */
    public static final int KB_BYTE = 1024;
    /**
     * MB *
     */
    public static final int MB_BYTE = 1024 * KB_BYTE;
    /**
     * GB *
     */
    public static final int GB_BYTE = 1024 * MB_BYTE;

    /** page title */
    public static final String KEY_PAGE_TITLE = "key_page_title";
}
