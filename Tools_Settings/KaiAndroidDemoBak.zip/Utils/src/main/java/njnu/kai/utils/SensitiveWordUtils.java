package njnu.kai.utils;

import android.content.Context;

/**
 * 敏感词过滤管理
 *
 * @author kai
 * @version 4.1.0
 * @since: 13-7-16 下午5:50
 */
final public class SensitiveWordUtils {

    private static final String LOG_TAG = "SensitiveWordUtils";
    private static final String SENSITY_WORDS = "16进制字符";
    private static final Object SYNC_OBJECT = new Object();
    private static SensitiveWordUtils mInstance;
    private String[] mSensitiveWords = new String[0];

    /**
     * 敏感词过滤
     * @param context context
     *
     * @return 敏感词过滤对象
     */
    public synchronized static SensitiveWordUtils getInstance(Context context) {
        if (mInstance == null) {
            synchronized (SYNC_OBJECT) {
                if (mInstance == null) {
                    mInstance = new SensitiveWordUtils();
                }
            }
        }
        return mInstance;
    }

    private SensitiveWordUtils() {
        try {
            mSensitiveWords = parseSensityWords(SecurityUtils.AES.decrypt(SENSITY_WORDS));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 是否包含敏感词
     *
     * @param text 文本
     * @return true, false
     */
    public boolean contain(String text) {
        if (!StringUtils.isEmpty(text)) {
            for (String word : mSensitiveWords) {
                if (text.contains(word)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 解析敏感字符串
     *
     * @param sourceString 敏感字符串
     * @return 敏感词列表
     */
    private String[] parseSensityWords(String sourceString) {
        return sourceString.split(" +|\\r\\n|\\r|\\n");
    }
}
