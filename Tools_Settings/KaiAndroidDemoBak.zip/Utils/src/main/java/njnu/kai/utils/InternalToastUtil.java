package njnu.kai.utils;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import njnu.kai.AppRuntime;

/**
 * @author kai
 * @version 1.0.0
 *
 */
class InternalToastUtil {
    private static final int SHOW_TIME = 2000; // 显示时间
    private static final int WHAT_SHOW = 1000; // 显示
    private static final int WHAT_HIDE = 1001; // 隐藏

    private static InternalToastUtil mToast;

    private WindowManager mWindowManager;
    private WindowManager.LayoutParams mParams;
    private View mToastView;
    private TextView mTvContent;

    private InternalToastUtil(Context context) {
        mWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        mParams = new WindowManager.LayoutParams();
        mParams.type = WindowManager.LayoutParams.TYPE_TOAST; //TYPE_SYSTEM_OVERLAY
        mParams.windowAnimations = android.R.style.Animation_Toast;
        mParams.format = PixelFormat.TRANSLUCENT;
        mParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        mParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        mParams.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;
        mParams.alpha = 1.0f;// 透明度，0全透 ，1不透
        mParams.verticalMargin = 0.1f;
        mParams.flags = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;

        mToastView = LayoutInflater.from(context).inflate(R.layout.utils_layout_toast, null);
        mTvContent = (TextView) mToastView.findViewById(R.id.tv_content);
    }

    /**
     * 初始化消息显示
     */
    private static void init() {
        if (null == mToast) {
            mToast = new InternalToastUtil(AppRuntime.getContext());
        }
    }

    private Handler mHandler = new Handler(Looper.getMainLooper()) {

        public void handleMessage(android.os.Message msg) {
            int what = msg.what;
            switch (what) {
                case WHAT_SHOW:
                    String str = msg.obj.toString();
                    if (!TextUtils.isEmpty(str)) {
                        showMsg(str);
                    }
                    break;
                case WHAT_HIDE:
                    hideMsg();
                    break;

                default:
                    break;
            }
        }

        ;
    };

    private void showMsg(String msg) {
        try {
            boolean removed = false;
            if (null != mToastView.getParent()) {
//                mParams.windowAnimations = 0;
//                mWindowManager.updateViewLayout(mToastView, mParams);
                mWindowManager.removeView(mToastView);
                removed = true;
            }
            mTvContent.setText(msg);
            if (null == mToastView.getParent()) {
                mWindowManager.addView(mToastView, mParams);
                if (removed) {
//                    mParams.windowAnimations = android.R.style.Animation_Toast;
//                    mWindowManager.updateViewLayout(mToastView, mParams);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideMsg() {
        try {
            if (null != mToastView.getParent()) {
                mWindowManager.removeView(mToastView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 显示消息
     *
     * @param msg 显示的内容
     */
    public static void show(String msg) {
        init();
        mToast.mHandler.removeCallbacksAndMessages(null);
        mToast.mHandler.sendMessage(mToast.mHandler.obtainMessage(WHAT_SHOW, msg));
        mToast.mHandler.sendEmptyMessageDelayed(WHAT_HIDE, SHOW_TIME);
    }

}
