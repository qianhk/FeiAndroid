package njnu.kai.utils;

import njnu.kai.AppRuntime;

import java.util.HashMap;

/**
 * @version 7.4.0
 * @author kai
 */
public class RomRecognizer {
    private static final String MIUI_IDENTIFY = "xiaomi";

    /**
     * 是否为miui rom
     * @return isOrNot
     */
    public static boolean isMiuiRom() {
        return containsRomIdentify(MIUI_IDENTIFY);
    }

    private static boolean containsRomIdentify(String identify) {
        HashMap<String, Object> parameters = AppRuntime.GeneralParameters.parameters();
        String rom = (String)parameters.get(AppRuntime.GeneralParameters.KEY_ROM_FINGER_PRINTER);
        rom = rom.toLowerCase();
        return rom.contains(identify);
    }
}
