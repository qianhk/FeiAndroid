package njnu.kai.utils;

import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Build;

import androidx.annotation.NonNull;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author kai
 * @version 1.0.0
 */

public final class ViewUtils {
    private static final int DISPLAY_VIEW_TAG_INTERVAL = 3 * 24 * 60 * 60 * 1000;
    private static final long TIME_DURATION = TimeUnit.MILLISECONDS.toNanos(500);
    private static long sLastClickTime;

    private ViewUtils() {

    }

    /**
     * Look for all child view with the given tag.
     *
     * @param v   view which want to find tag
     * @param tag The tag to search for, using "tag.equals(getTag())".
     * @return The View that has the given tag in the hierarchy or null
     */
    public static List<View> findAllViewWithTag(View v, Object tag) {
        if (tag == null || v == null) {
            return null;
        }
        ArrayList<View> listView = new ArrayList<View>();
        findAllViewWithTag(v, tag, listView);
        return listView.isEmpty() ? null : listView;
    }

    private static void findAllViewWithTag(View v, Object tag, ArrayList<View> listView) {
        if (tag.equals(v.getTag())) {
            listView.add(v);
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) v;
            for (int idx = viewGroup.getChildCount() - 1; idx >= 0; --idx) {
                View child = viewGroup.getChildAt(idx);
                findAllViewWithTag(child, tag, listView);
            }
        }
    }

    /**
     * 从view树里移除
     *
     * @param view view
     * @return true if success
     */
    public static boolean safeRemoveFromParent(View view) {
        if (view == null) {
            return false;
        }
        ViewParent viewParent = view.getParent();
        if (viewParent instanceof ViewGroup) {
            ((ViewGroup) viewParent).removeView(view);
        }
        return view.getParent() == null;
    }

    /**
     * 获取parent view
     *
     * @param view view
     * @return if not have view group for its parent, return null
     */
    public static ViewGroup safeGetParentView(View view) {
        if (view == null) {
            return null;
        }
        ViewParent viewParent = view.getParent();
        if (viewParent instanceof ViewGroup) {
            return (ViewGroup) viewParent;
        }
        return null;
    }

    /**
     * @param view              view
     * @param disallowIntercept True if the child does not want the parent to
     *                          intercept touch events.
     */
    public static void safeRequestParentDisallowInterceptTouchEvent(View view, boolean disallowIntercept) {
        ViewParent viewParent = view != null ? view.getParent() : null;
        if (viewParent != null) {
            viewParent.requestDisallowInterceptTouchEvent(true);
        }
    }

    /**
     * 判断是否为快速双击事件（用来判断在一个view上连续双击），目前的时间间隔为500毫秒
     *
     * @return true： 是快速双击事件
     */
    public static boolean isFastDoubleClick() {
        long time = System.nanoTime();
        if (time - sLastClickTime < TIME_DURATION) {
            return true;
        }
        sLastClickTime = time;
        return false;
    }

    /**
     * 根据日期设置View的可见性
     *
     * @param date 日期，单位为毫秒
     * @param view 被设置是否可见性的View
     */
    public static void setVisibleByDate(long date, View view) {
        long currentTime = System.currentTimeMillis();
        if (date + DISPLAY_VIEW_TAG_INTERVAL >= currentTime) {
            view.setVisibility(View.VISIBLE);
        } else {
            view.setVisibility(View.GONE);
        }
    }

    /**
     * 给某个view设置一个background
     *
     * @param view     view
     * @param drawable drawable
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public static void setBackgroundDrawable(View view, Drawable drawable) {
        if (view != null) {
            view.setBackground(drawable);
        }
    }

    public static void prepareView(int totalCount, @NonNull ViewGroup viewGroup, @NonNull ViewSwitcher.ViewFactory viewFactory) {
        int childCount = viewGroup.getChildCount();
        if (childCount > totalCount) {
            for (int idx = childCount - 1; idx >= totalCount; --idx) {
                viewGroup.removeViewAt(idx);
            }
        } else if (childCount < totalCount) {
            for (int idx = childCount; idx < totalCount; ++idx) {
                viewGroup.addView(viewFactory.makeView());
            }
        }
    }

    public static void enableAllView(View rootView, Boolean enabled) {
        rootView.setEnabled(enabled);
        if (rootView instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) rootView;
            for (int idx = viewGroup.getChildCount() - 1; idx >= 0; --idx) {
                enableAllView(viewGroup.getChildAt(idx), enabled);
            }
        }
    }

    public static TextView findTextViewById(View view, int viewId) {
        return (TextView) view.findViewById(viewId);
    }

    public static ListView findListViewById(View view, int viewId) {
        return (ListView) view.findViewById(viewId);
    }

    public static EditText findEditTextById(View view, int viewId) {
        return (EditText) view.findViewById(viewId);
    }

    public static ImageView findImageViewById(View view, int viewId) {
        return (ImageView) view.findViewById(viewId);
    }

    public static View findViewById(View view, int viewId) {
        return view.findViewById(viewId);
    }

//    public static SimpleGridView findSimpleGridViewById(View view, int viewId) {
//        return (SimpleGridView) view.findViewById(viewId);
//    }

    public static ViewGroup findViewGroupById(View view, int viewId) {
        return (ViewGroup) view.findViewById(viewId);
    }

//    public static IconTextTextView findIconTextTextViewById(View view, int viewId) {
//        return (IconTextTextView) view.findViewById(viewId);
//    }

//    public static IconTextView findIconTextViewById(View view, int viewId) {
//        return (IconTextView) view.findViewById(viewId);
//    }


    private static void bindViewListener(View view, View.OnClickListener listener) {
        if (view != null) {
            view.setOnClickListener(listener);
        }
    }

    public static void bindClickListener(View view, View.OnClickListener listener) {
        bindViewListener(view, listener);
    }

    /**
     * @param views
     * @param listener
     */
    public static void bindClickListener(View.OnClickListener listener, View... views) {
        if (null != views) {
            for (View view : views) {
                bindViewListener(view, listener);
            }
        }
    }

    /**
     * 根据id绑定OnClickListener
     *
     * @param rootView 根View
     * @param listener View.OnClickListener
     * @param ids      R.id
     */
    public static void bindClickListener(View rootView, View.OnClickListener listener, int... ids) {
        for (int id : ids) {
            View view = rootView.findViewById(id);
            bindViewListener(view, listener);
        }
    }

    /**
     * 批量根据id绑定OnClickListener
     *
     * @param activity activity实例
     * @param listener View.OnClickListener
     * @param ids      R.id
     */
    public static void bindClickListener(Activity activity, View.OnClickListener listener, int... ids) {
        for (int id : ids) {
            View view = activity.findViewById(id);
            bindViewListener(view, listener);
        }
    }


    private static void bindViewTag(View view, int key, final Object tag) {
        if (view != null) {
            view.setTag(key, tag);
        }
    }

    public static void bindTag(int key, final Object tag, View... views) {
        if (null != views) {
            for (View view : views) {
                bindViewTag(view, key, tag);
            }
        }
    }

    public static void bindClickListenerAndTag(View rootView, View.OnClickListener listener, int key, final Object tag, int... ids) {
        for (int id : ids) {
            View view = rootView.findViewById(id);
            bindViewListener(view, listener);
            bindViewTag(view, key, tag);
        }
    }

}
