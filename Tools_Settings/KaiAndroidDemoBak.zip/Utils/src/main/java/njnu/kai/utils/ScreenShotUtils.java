package njnu.kai.utils;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.view.View;

/**
 * @version 7.0.0
 *          截屏工具类工具类
 */
public class ScreenShotUtils {
    /**
     * @param activity Activity
     * @param savePath savePath
     */
    public static void takeScreenShot(final Activity activity, String savePath) {
        Activity topActivity = (getTopActivity(activity));
        Rect frame = new Rect();
        topActivity.getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int statusBarHeight = frame.top;
        if (statusBarHeight < 0) {
            statusBarHeight = 0;
        }
        View view = topActivity.getWindow().getDecorView();
        try {
            view.setDrawingCacheEnabled(true);
            view.buildDrawingCache();
            Bitmap bitmapCache = view.getDrawingCache();
            bitmapCache = Bitmap.createBitmap(bitmapCache
                    , 0
                    , statusBarHeight
                    , bitmapCache.getWidth()
                    , bitmapCache.getHeight() - statusBarHeight);
            BitmapUtils.saveBitmap(bitmapCache, savePath);
        } catch (Throwable e) {
            e.printStackTrace();
        } finally {
            if (view != null) {
                view.destroyDrawingCache();
            }
        }
    }

    private static Activity getTopActivity(Activity activity) {
        while (activity.getParent() != null) {
            activity = activity.getParent();
        }
        return activity;
    }
}
