package njnu.kai.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;

import java.io.File;

/**
 * 1. 安装apk
 * 2. 获取本机安装的应用程序信息-包名、版本
 *
 * @version 4.1.0
 */
public final class ApkUtils {

    private static final String LOG_TAG = "ApkUtil";

    public static final String APK_MIME_TYPE = "application/vnd.android.package-archive";

    private static final int KILL_PROCESS_DELAY_MS = 500;

    /**
     * 安装应用程序
     *
     * @param aContext context
     * @param apkPath  安装程序路径
     * @return 成功返回true。失败返回fals
     */
    public static boolean install(Context aContext, String apkPath) {
        if (FileUtils.fileExists(apkPath)) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setDataAndType(Uri.fromFile(new File(apkPath)), APK_MIME_TYPE);
            aContext.startActivity(intent);
            return true;
        }
        return false;
    }

    /**
     * kill process
     */
    public static void killMyProcess() {
        // 终止进程
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        }, KILL_PROCESS_DELAY_MS);
    }
}
