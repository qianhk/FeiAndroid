package njnu.kai.utils;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.SparseIntArray;

/**
 * @version 7.0.0
 */
public class NotificationUtils {
    /**
     * 播放服务的通知 *
     */
    public static final int NOTIFICATION_PLAYER_ID = 15121720;
    /**
     * 任务错误通知 *
     */
    public static final int NOTIFICATION_DOWNLOAD_ERROR_ID = 15121740;
    /**
     * 任务完成通知 *
     */
    public static final int NOTIFICATION_DOWNLOAD_COMPLETE_ID = 15121730;
    /**
     * 正在下载任务通知 *
     */
    public static final int NOTIFICATION_TASK_DOWNLOADING_ID = 15121750;

    /**
     * 默认通知栏优先级
     */
    public static final int NOTIFICATION_PRIORITY_DEFAULT = 0;
    /**
     * 高通知栏优先级
     */
    public static final int NOTIFICATION_PRIORITY_HIGH = 1;
    /**
     * 最大通知栏优先级
     */
    public static final int NOTIFICATION_PRIORITY_MAX = 2;
    /**
     * 低通知栏优先级
     */
    public static final int NOTIFICATION_PRIORITY_LOW = -1;
    /**
     * 最小通知栏优先级
     */
    public static final int NOTIFICATION_PRIORITY_MIN = -2;

    /**
     * 在intent中指定目标页面号时使用的键值
     */
    public static final String FROM_NOTIFICATION_TO_PAGE_INDEX = "fragment_page_index";

    private static final int NOTIFICATION_HEIGHT_DP = 64;
    private static final SparseIntArray PRIORITY_MAP = new SparseIntArray();
    static {
        PRIORITY_MAP.put(NOTIFICATION_PRIORITY_DEFAULT, Notification.PRIORITY_DEFAULT);
        PRIORITY_MAP.put(NOTIFICATION_PRIORITY_HIGH, Notification.PRIORITY_HIGH);
        PRIORITY_MAP.put(NOTIFICATION_PRIORITY_LOW, Notification.PRIORITY_LOW);
        PRIORITY_MAP.put(NOTIFICATION_PRIORITY_MAX, Notification.PRIORITY_MAX);
        PRIORITY_MAP.put(NOTIFICATION_PRIORITY_MIN, Notification.PRIORITY_MIN);
    }
    private static long mFirstAddNotificationTime = 0;

    /**
     * 创建默认样式的通知
     *
     * @param context       上下文
     * @param popIconRes    弹出图标
     * @param title         主标题
     * @param subTitle      副标题
     * @param largeIcon     大图标
     * @param contentIntent 点击后的动作Intent
     * @return 通知类实例
     */
//    public static Notification makeDefaultNotification(
//            Context context
//            , int popIconRes
//            , CharSequence title
//            , CharSequence subTitle
//            , Bitmap largeIcon
//            , PendingIntent contentIntent) {
//        return makeDefaultNotification(context, popIconRes, title, subTitle, largeIcon, 0, contentIntent);
//    }

    /**
     * 创建默认样式的通知
     *
     * @param context       上下文
     * @param popIconRes    弹出图标
     * @param title         主标题
     * @param subTitle      副标题
     * @param largeIcon     大图标
     * @param when          显示时间的毫秒数
     * @param contentIntent 点击后的动作Intent
     * @return 通知类实例
     */
//    public static Notification makeDefaultNotification(
//            Context context
//            , int popIconRes
//            , CharSequence title
//            , CharSequence subTitle
//            , Bitmap largeIcon
//            , long when
//            , PendingIntent contentIntent) {
////        NotificationBuilder notificationBuilder = new NotificationBuilder(context);
////        if (largeIcon != null) {
////            try {
////                largeIcon = BitmapUtils.cropBitmapToSquare(largeIcon, DisplayUtils.dp2px(NOTIFICATION_HEIGHT_DP));
////            } catch (Throwable t) {
////                t.printStackTrace();
////            }
////        }
////        if (largeIcon == null && popIconRes != 0) {
////            largeIcon = BitmapFactory.decodeResource(context.getResources(), popIconRes);
////        }
////        if (SDKVersionUtils.hasHoneycomb()) {
////            notificationBuilder.setContentTitle(title);
////            notificationBuilder.setContentText(subTitle);
////            notificationBuilder.setLargeIcon(largeIcon);
////        } else {
////            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.notification_default);
////            views.setTextViewText(R.id.textview_title, title);
////            views.setTextColor(R.id.textview_title, NotificationBuilder.getDefaultNotificationTextFontColor());
////            views.setTextViewText(R.id.textview_sub_title, subTitle);
////            views.setTextColor(R.id.textview_sub_title, NotificationBuilder.getDefaultNotificationTextFontColor());
////            views.setImageViewBitmap(R.id.imgview_largeicon, largeIcon);
////            notificationBuilder.setContent(views);
////        }
////
////        notificationBuilder.setIcon(popIconRes);
////        notificationBuilder.setContentIntent(contentIntent);
////        notificationBuilder.setWhen(when);
//        return notificationBuilder.getNotification();
//    }
//
//    /**
//     * 播放相关通知
//     *
//     * @param context                context
//     * @param title                  title
//     * @param playStatus             playStatus
//     * @param subTitle               subTitle
//     * @param subTitle2              subTitle2
//     * @param largeIcon              largeIcon
//     * @param contentIntent          contentIntent
//     * @param previousPendingIntent  previousPendingIntent
//     * @param playPasuePendingIntent playPasuePendingIntent
//     * @param nextPendingIntent      nextPendingIntent
//     * @param exitPendingIntent      exitPendingIntent
//     * @return Notification
//     */
//    public static Notification makePlayNotification(Context context,
//                                                    PlayStatus playStatus,
//                                                    CharSequence title,
//                                                    CharSequence subTitle,
//                                                    CharSequence subTitle2,
//                                                    Bitmap largeIcon,
//                                                    PendingIntent contentIntent,
//                                                    PendingIntent previousPendingIntent,
//                                                    PendingIntent playPasuePendingIntent,
//                                                    PendingIntent nextPendingIntent,
//                                                    PendingIntent exitPendingIntent) {
//        NotificationBuilder notificationBuilder = new NotificationBuilder(context);
//        notificationBuilder.setIcon(R.drawable.img_notification_tickericon);
//
//        notificationBuilder.setContentIntent(contentIntent);
//        if (mFirstAddNotificationTime <= 0) {
//            mFirstAddNotificationTime = System.currentTimeMillis();
//        }
//        notificationBuilder.setWhen(mFirstAddNotificationTime);
//
//        RemoteViews contentViews = new RemoteViews(context.getPackageName(), R.layout.notification_play);
//        contentViews.setTextViewText(R.id.title, title);
//        contentViews.setTextColor(R.id.title, NotificationBuilder.getDefaultNotificationTitleFontColor());
//        contentViews.setTextViewText(R.id.text, subTitle);
//        contentViews.setTextColor(R.id.text, NotificationBuilder.getDefaultNotificationTextFontColor());
//        if (largeIcon != null) {
//            contentViews.setImageViewBitmap(R.id.imageview_notification_play, largeIcon);
//        }
//        notificationBuilder.setContent(contentViews);
//
//        if (SDKVersionUtils.hasIceCreamSandwich()) {
//            contentViews.setViewVisibility(R.id.control_bar, View.VISIBLE);
//            contentViews.setViewVisibility(R.id.button_previous_notification_play,
//                    Preferences.isShowPreviousInNotificationEnabled() ? View.VISIBLE : View.GONE);
//            contentViews.setViewVisibility(R.id.button_exit_notification_play,
//                    Preferences.isShowCloseInNotificationEnabled() ? View.VISIBLE : View.GONE);
//
//            if (playStatus == PlayStatus.STATUS_PLAYING) {
//                contentViews.setViewVisibility(R.id.button_play_notification_play, View.GONE);
//                contentViews.setViewVisibility(R.id.button_pause_notification_play, View.VISIBLE);
//                contentViews.setOnClickPendingIntent(R.id.button_pause_notification_play, playPasuePendingIntent);
//            } else {
//                contentViews.setViewVisibility(R.id.button_pause_notification_play, View.GONE);
//                contentViews.setViewVisibility(R.id.button_play_notification_play, View.VISIBLE);
//                contentViews.setOnClickPendingIntent(R.id.button_play_notification_play, playPasuePendingIntent);
//            }
//
//            contentViews.setOnClickPendingIntent(R.id.button_previous_notification_play, previousPendingIntent);
//            contentViews.setOnClickPendingIntent(R.id.button_next_notification_play, nextPendingIntent);
//            contentViews.setOnClickPendingIntent(R.id.button_exit_notification_play, exitPendingIntent);
//        }
//
//        Notification notification = notificationBuilder.getNotification();
//        if (SDKVersionUtils.hasJellyBean()) {
//            notification.priority = PRIORITY_MAP.get(Preferences.getNotificationPriority());
//            final RemoteViews bigContentViews = new RemoteViews(context.getPackageName(), R.layout.notification_play_hasjellybean);
//            if (title != null) {
//                bigContentViews.setTextViewText(R.id.title, title);
//                bigContentViews.setTextColor(R.id.title, NotificationBuilder.getDefaultNotificationTitleFontColor());
//                bigContentViews.setTextViewText(R.id.text, subTitle);
//                bigContentViews.setTextColor(R.id.text, NotificationBuilder.getDefaultNotificationTextFontColor());
//                bigContentViews.setTextViewText(R.id.text2, subTitle2);
//                bigContentViews.setTextColor(R.id.text2, NotificationBuilder.getDefaultNotificationTextFontColor());
//
//            }
//            if (largeIcon != null) {
//                bigContentViews.setImageViewBitmap(R.id.imageview_notification_play_hasjellybean, largeIcon);
//            }
//            notification.bigContentView = bigContentViews;
//
//            if (playStatus == PlayStatus.STATUS_PLAYING) {
//                bigContentViews.setViewVisibility(R.id.button_play_notification_play_hasjellybean, View.GONE);
//                bigContentViews.setViewVisibility(R.id.button_pause_notification_play_hasjellybean, View.VISIBLE);
//                bigContentViews.setOnClickPendingIntent(R.id.button_pause_notification_play_hasjellybean, playPasuePendingIntent);
//            } else {
//                bigContentViews.setViewVisibility(R.id.button_pause_notification_play_hasjellybean, View.GONE);
//                bigContentViews.setViewVisibility(R.id.button_play_notification_play_hasjellybean, View.VISIBLE);
//                bigContentViews.setOnClickPendingIntent(R.id.button_play_notification_play_hasjellybean, playPasuePendingIntent);
//            }
//
//            bigContentViews.setOnClickPendingIntent(R.id.button_previous_notification_play_hasjellybean, previousPendingIntent);
//            bigContentViews.setOnClickPendingIntent(R.id.button_next_notification_play_hasjellybean, nextPendingIntent);
//            bigContentViews.setOnClickPendingIntent(R.id.button_exit_notification_play_hasjellybean, exitPendingIntent);
//
//            bigContentViews.setViewVisibility(R.id.button_exit_notification_play_hasjellybean
//                    , Preferences.isShowPreviousInNotificationEnabled() ? View.VISIBLE : View.GONE);
//            bigContentViews.setViewVisibility(R.id.button_exit_notification_play_hasjellybean,
//                    Preferences.isShowCloseInNotificationEnabled() ? View.VISIBLE : View.GONE);
//
//        }
//
//        return notification;
//    }
//
//    /**
//     * 发送Notification
//     *
//     * @param notificationID notificationID
//     * @param notification   notification
//     */
//    public static void notify(int notificationID, Notification notification) {
//        ((NotificationManager) BaseApplication.getApp()
//                .getSystemService(Context.NOTIFICATION_SERVICE)).notify(notificationID, notification);
//    }
//
//    /**
//     * 发送Notification
//     *
//     * @param notificationID notificationID
//     * @param notification   notification
//     */
//    public static void notifyWithCancel(int notificationID, Notification notification) {
//        NotificationManager notificationManager =
//                ((NotificationManager) BaseApplication.getApp().getSystemService(Context.NOTIFICATION_SERVICE));
//        notificationManager.cancel(notificationID);
//        notificationManager.notify(notificationID, notification);
//    }
//
//    /**
//     * 取消notification
//     *
//     * @param notificationID notificationID
//     */
//    public static void cancel(int notificationID) {
//        try {
//            ((NotificationManager) BaseApplication.getApp()
//                    .getSystemService(Context.NOTIFICATION_SERVICE)).cancel(notificationID);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    /**
//     * 取消所有下载相关通知
//     */
//    public static void cancelAllDownloadNotification() {
//        NotificationUtils.cancel(NOTIFICATION_TASK_DOWNLOADING_ID);
//        NotificationUtils.cancel(NOTIFICATION_DOWNLOAD_COMPLETE_ID);
//        NotificationUtils.cancel(NOTIFICATION_DOWNLOAD_ERROR_ID);
//    }
}
