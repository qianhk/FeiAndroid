/**
 * @(#)TTDateTimeUtils.java 2012-11-12
 */
package njnu.kai.utils;

import android.content.Context;
import android.text.TextUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author kai
 * @version 1.0.0
 * @since 2012-11-12
 */
public final class DateTimeUtils {

    /**
     * 0字符串表示
     */
    public static final String ZERO_SINGLE_STRING = "0";
    /**
     * 00 字符串表示
     */
    public static final String ZERO_DOUBLE_STRING = "00";
    private static final int YEAR_STRING_LENGTH = 4;
    private static final int MONTH_STRING_LENGTH = 6;
    private static final int DAY_STRING_LENGTH = 8;
    private static final String COLON = ":";
    public static final String[] ENGLISH_MONTH_NAMES = {"January", "February", "March", "April", "May", "June"
            , "July", "August", "September", "October", "November", "December", "Undecember"};

    private static final String[] ENGLISH_WEEK_NAMES = {"", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

//    private static final String[] ENGLISH_SHORT_MONTH_NAMES = {"Jan", "February", "March", "April", "May", "June"
//            , "July", "August", "September", "October", "November", "December", "Undecember"};

    public static final String[] CHINESE_MONTH_NAMES = {"一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月"
            , "九月", "十月", "十一月", "十二月"};

    public static String getEnglisthMonthName(int month) {
        return ENGLISH_MONTH_NAMES[month];
    }

    public static String getEnglisthWeekName(int week) {
        return ENGLISH_WEEK_NAMES[week];
    }

    /**
     * 解析字符串表示的毫秒数值
     *
     * @param time 形如：xx:xx.xx的时间字符串 以及xx:xx:xx
     * @return 毫秒
     */
    public static long parseTimeTag(String time) {
        if (StringUtils.isEmpty(time)) {
            return 0;
        }

        String[] split = time.split(COLON);
        if (split != null && split.length == 3) {
            try {
                int hour = Integer.parseInt(split[0]);
                int minute = Integer.parseInt(split[1]);
                String strSecondWithMS = split[2];
                int msPos = strSecondWithMS.indexOf('.');
                int second;
                int millisecond = 0;
                if (msPos < 0) {
                    second = Integer.parseInt(strSecondWithMS);
                } else {
                    second = Integer.parseInt(strSecondWithMS.substring(0, msPos));
                    millisecond = millisecondToInt(strSecondWithMS.substring(msPos + 1));
                }
                return (((hour * ConstantUtils.MINUTE_PER_HOUR + minute) * ConstantUtils.SECONDS_PER_MINUTE) + second) * ConstantUtils.MILLIS_PER_SECOND + millisecond;
            } catch (Exception e) {
                return 0;
            }
        }
        return doParseTimeTag(time);
    }

    /**
     * 解析字符串表示的毫秒数值
     *
     * @param timeTag 形如：xx:xx.xx的时间字符串
     * @return 毫秒
     */
    private static long doParseTimeTag(String timeTag) {
        long timeTagLong = Long.MIN_VALUE;
        try {
            int index = timeTag.indexOf(COLON);
            if (index > 0) {
                boolean negative = false;
                String willToInt = timeTag.substring(0, index).trim();
                if (willToInt.length() > 0) {
                    if (willToInt.charAt(0) == '-') {
                        negative = !negative;
                        willToInt = willToInt.substring(1);
                    }
                }
                long minute = Long.parseLong(willToInt);
                int start = index + 1;
                int sec;
                int millis = 0;

                index = timeTag.indexOf('.', start);
                if (index < 0) {
                    index = timeTag.indexOf(COLON, start);
                }
                if (index > 0) {
                    willToInt = timeTag.substring(start, index).trim();
                    if (willToInt.length() > 0) {
                        if (willToInt.charAt(0) == '-') {
                            negative = !negative;
                            willToInt = willToInt.substring(1);
                        }
                    }
                    sec = Integer.parseInt(willToInt);
                    String strMillisecond = timeTag.substring(++index).trim();
                    int lenMillis = strMillisecond.length();
                    if (lenMillis > 0) {
                        if (strMillisecond.charAt(0) == '-') {
                            negative = !negative;
                            strMillisecond = strMillisecond.substring(1);
                            --lenMillis;
                        }
                        millis = millisecondToInt(strMillisecond);
                    }
                } else {
                    willToInt = timeTag.substring(start).trim();
                    if (willToInt.length() > 0) {
                        if (willToInt.charAt(0) == '-') {
                            negative = !negative;
                            willToInt = willToInt.substring(1);
                        }
                    }
                    sec = Integer.parseInt(willToInt);
                }

                timeTagLong = ((minute * ConstantUtils.SECONDS_PER_MINUTE) + sec) * ConstantUtils.MILLIS_PER_SECOND + millis;
                if (negative) {
                    timeTagLong = -timeTagLong;
                }

            }
        } catch (NumberFormatException e) {
            timeTagLong = Long.MIN_VALUE;
            e.printStackTrace();
        }

        return timeTagLong;
    }

    private static int millisecondToInt(String strMillisToInt) {
        int lenMillisecond = strMillisToInt.length();
        int millisecond = lenMillisecond > 0 ? Integer.parseInt(strMillisToInt) : 0;
        if (lenMillisecond == 1) {
            millisecond *= 100;
        } else if (lenMillisecond == 2) {
            millisecond *= 10;
        }
        return millisecond;
    }

    /**
     * yyyymmdd to yyyy-mm-dd
     *
     * @param formation 格式
     * @param date      日期
     * @return String
     */
    public static String format(String formation, String date) {
        StringBuilder dateBuilder = new StringBuilder();

        String year = date.substring(0, YEAR_STRING_LENGTH);
        String month = date.substring(YEAR_STRING_LENGTH, MONTH_STRING_LENGTH);
        String day = date.substring(MONTH_STRING_LENGTH, DAY_STRING_LENGTH);

        dateBuilder.append(year);
        dateBuilder.append(formation);
        dateBuilder.append(month);
        dateBuilder.append(formation);
        dateBuilder.append(day);

        return dateBuilder.toString();
    }

    /**
     * access weekDay 星期几文字描述
     * @param date dataTime
     * @param context 上下文对象
     * @return String
     */
    public static String getWeekOfDate(Context context, Date date) {
        String[] weekDays = {
                context.getString(R.string.app_sunday),
                context.getString(R.string.app_monday),
                context.getString(R.string.app_tuesday),
                context.getString(R.string.app_wednesday),
                context.getString(R.string.app_thursday),
                context.getString(R.string.app_friday),
                context.getString(R.string.app_saturday)};
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) {
            w = 0;
        }
        return weekDays[w];
    }

    /**
     * format time 01:02
     *
     * @param time time parameter long
     * @return String
     */
    public static String formatLongToTimeStr(long time) {
        String strMinute;
        String strSecond;
        int minute = 0;
        int second = (int) (time / ConstantUtils.MILLIS_PER_SECOND);
        if (second > ConstantUtils.SECONDS_PER_MINUTE) {
            minute = second / ConstantUtils.SECONDS_PER_MINUTE;
            second = second % ConstantUtils.SECONDS_PER_MINUTE;
        }

        if (minute / 10 == 0) {
            strMinute = ZERO_SINGLE_STRING + minute;
        } else {
            strMinute = "" + minute;
        }
        if (second / 10 == 0) {
            strSecond = ZERO_SINGLE_STRING + second;
        } else {
            if (second == ConstantUtils.SECONDS_PER_MINUTE) {
                strMinute = "" + minute + 1;
                strSecond = ZERO_DOUBLE_STRING;
            } else {
                strSecond = "" + second;
            }
        }
        return strMinute + ":" + strSecond;
    }

    /**
     * generate time 01:02:03 02:03
     *
     * @param time      time
     * @param formation 格式
     * @return formatted time string
     */
    public static String generateTime(long time, String formation) {
        String format = TextUtils.isEmpty(formation) ? ":" : formation;
        int totalSeconds = (int) (time / 1000);
        int seconds = totalSeconds % ConstantUtils.SECONDS_PER_MINUTE;
        int minutes = totalSeconds / ConstantUtils.SECONDS_PER_MINUTE % ConstantUtils.SECONDS_PER_MINUTE;
        int hours = totalSeconds / ConstantUtils.SECONDS_PER_MINUTE / 1000;

        return hours > 0 ? String.format("%02d" + format + "%02d" + format + "%02d", hours, minutes, seconds)
                : String.format("%02d" + format + "%02d", minutes, seconds);
    }

}
