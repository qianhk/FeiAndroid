package njnu.kai.utils;

import java.io.UnsupportedEncodingException;

/**
 * 文本解码/编码辅助工具类
 * @author kai
 * @version 1.0.0
 */
public class CodeUtils {

    /**
     * GBK
     */
    public static final String GBK = "GBK";

    /**
     * UTF-8
     */
    public static final String UTF_8 = "UTF-8";

    /**
     * UTF-16BE
     */
    public static final String UTF_16BE = "UTF-16BE";

    /**
     * UTF-16LE
     */
    public static final String UTF_16LE = "UTF-16LE";

    /**
     * 按UTF16BE编码字符串
     * @param s 传入的字符串
     * @param startOffset 开始便宜
     * @param len 长度
     * @return 编码数据
     */
    public static byte[] encodeUTF16BE(String s, int startOffset, int len) {
        byte[] uc = new byte[len << 1];
        len += startOffset;
        int j = 0;
        char ch;
        for (int i = startOffset; i < len; i++) {
            ch = s.charAt(i);
            uc[j++] = (byte)ch;
            uc[j++] = (byte)(ch >> 8);
        }
        return uc;
    }

    /**
     * UTF-16BE解码
     * @param b 传入的数据
     * @param startOffset 开始位置
     * @param len 长度
     * @return 完成解码后的字符串
     */
    public static String decodeUTF16BE(byte[] b, int startOffset, int len) {
        char[] uc = new char[len >> 1];
        int l = 0;
        len += startOffset - 1;
        while (startOffset < len) uc[l++] = (char)((b[startOffset++] & 0xff) | (b[startOffset++] << 8));
        return new String(uc);
    }

    /**
     * UTF-16LE解码
     * @param b 传入的数据
     * @param startOffset 开始位置
     * @param len 长度
     * @return 完成解码后的字符串
     */
    public static String decodeUTF16LE(byte[] b, int startOffset, int len) {
        char[] uc = new char[len >> 1];
        int l = 0;
        len += startOffset - 1;
        while (startOffset < len) uc[l++] = (char)((b[startOffset++] << 8) | (b[startOffset++] & 0xff));
        return new String(uc);
    }

    /**
     * UTF-8解码
     * @param b 传入的数据
     * @param startOffset 开始位置
     * @param len 长度
     * @return 完成解码后的字符串
     */
    public static String decodeUTF8(byte[] b, int startOffset, int len) {
        len += startOffset;
        char[] uc = new char[len];
        int l = 0;
        while (startOffset < len) {
            int c = b[startOffset++] & 0xff;
            if ((c >> 5) == 0x6 && startOffset < len) { //双字节编码
                uc[l++] = (char)(((c & 0x1f) << 6) | (b[startOffset++] & 0x3f));
            } else if ((c >> 4) == 0xe && startOffset < len - 1) { //三字节编码
                uc[l++] = (char)(
                        ((c & 0xf) << 12) | ((b[startOffset++] & 0x3f) << 6) | (b[startOffset++] & 0x3f));
            } else {
                uc[l++] = (char)c;
            }
        }
        return new String(uc, 0, l);
    }

    /**
     * GBK解码
     * @param b 传入的数据
     * @param startOffset 开始位置
     * @param len 长度
     * @return 完成解码后的字符串
     */
    public static String decodeGBK(byte[] b, int startOffset, int len) {
        try {
            return new String(b, startOffset, len, GBK);
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }

    /**
     * 查看传入的数据是否为UTF8编码
     * @param contentByteArray 内容
     * @return true if yes
     */
    public static boolean isUTF8(byte[] contentByteArray) {
        int nBytes = 0;
        int chr;
        boolean bAllAscii = true; // 如果全部都是ASCII, 说明不是UTF-8
        int i = 0, size = contentByteArray.length;
        for (; i < size; ++i) {
            chr = contentByteArray[i] & 0xFF;
            if ((chr & 0x80) != 0) // 判断是否ASCII编码,如果不是,说明有可能是UTF-8,ASCII用7位编码,但用一个字节存,最高位标记为0,o0xxxxxxx
                bAllAscii = false;
            if (nBytes == 0) { // 如果不是ASCII码,应该是多字节符,计算字节数
                if (chr >= 0x80) {
                    if (chr >= 0xFC && chr <= 0xFD)
                        nBytes = 6;
                    else if (chr >= 0xF8)
                        nBytes = 5;
                    else if (chr >= 0xF0)
                        nBytes = 4;
                    else if (chr >= 0xE0)
                        nBytes = 3;
                    else if (chr >= 0xC0)
                        nBytes = 2;
                    else {
                        return false;
                    }
                    --nBytes;
                }
            } else { // 多字节符的非首字节,应为 10xxxxxx
                if ((chr & 0xC0) != 0x80) {
                    return false;
                }
                --nBytes;
            }
        }

        // 违返规则
        if (nBytes > 0 && i < size) {
            return false;
        }

        // 如果全部都是ASCII, 说明不是UTF-8
        return !bAllAscii;
    }
}
