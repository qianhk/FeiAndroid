package njnu.kai.utils;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.Date;

/**
 * @author kai
 * @version 1.0.0
 */
public final class DateTimeViewUtils {

    /**
     * 默认起始年份
     */
    private static int DEFAULT_START_YEAR = 1900;

    /**
     * 默认结束年份
     */
    private static int DEFAULT_END_YEAR = 2100;

    /**
     * 最大月份
     */
    public static int MAX_MONTH = 12;

    /**
     * 最大天数
     */
    private static int MAX_MONTH_DATA = 31;

//    public static void onClickDateTimeView(final Context context, long defaultDate, final DateViewListener listener) {
//        BirthdayDate date = new BirthdayDate(defaultDate != 0 ? defaultDate : System.currentTimeMillis());
//        if (!validBirthdayDate(date)) {
//            Calendar calendar = Calendar.getInstance();
//            // 注意看系统代码，阴历时，calendar.get(Calendar.MONTH) 会返回 12, 有13个月。
//            int month = calendar.get(Calendar.MONTH);
//            date = new BirthdayDate(calendar.get(Calendar.YEAR), ((month >= MAX_MONTH) ? (MAX_MONTH - 1) : month)
//                    , calendar.get(Calendar.DAY_OF_MONTH));
//        }
//        DateTimePickerDialog dialog = new DateTimePickerDialog(context, TimePopupWindow.Type.ALL, dlg -> {
//            if (listener != null) {
//                listener.onDateChoosed(dlg.getCurrentTime().getTime());
//            }
//        }, null);
//        dialog.show(date.toMillisecond());
//    }
//
//    public static void onClickTimePopupWindow(final View view, long defaultDate, final DateViewListener listener) {
//        BirthdayDate date = new BirthdayDate(defaultDate != 0 ? defaultDate : System.currentTimeMillis());
//        if (!validBirthdayDate(date)) {
//            Calendar calendar = Calendar.getInstance();
//            // 注意看系统代码，阴历时，calendar.get(Calendar.MONTH) 会返回 12, 有13个月。
//            int month = calendar.get(Calendar.MONTH);
//            date = new BirthdayDate(calendar.get(Calendar.YEAR), ((month >= MAX_MONTH) ? (MAX_MONTH - 1) : month)
//                    , calendar.get(Calendar.DAY_OF_MONTH));
//        }
//
//        TimePopupWindow pwTime = new TimePopupWindow(view.getContext(), TimePopupWindow.Type.ALL);
//        pwTime.setOnTimeSelectListener(new TimePopupWindow.OnTimeSelectListener() {
//
//            @Override
//            public void onTimeSelect(Date date) {
//                if (listener != null) {
//                    listener.onDateChoosed(date.getTime());
//                }
//            }
//        });
//        pwTime.showAtLocation(view, Gravity.BOTTOM, 0, 0, new Date(date.toMillisecond()));
//    }
//
//    /**
//     * 获取星座
//     *
//     * @param constellationIndex 星座索引
//     * @return 文本资源id
//     */
//    public int getConstellationCharsequeceResource(int constellationIndex) {
//        switch (constellationIndex) {
//            case BirthdayDate.INDEX_CAPRICORN:
//                return R.string.capricorn;
//            case BirthdayDate.INDEX_AQUARIUS:
//                return R.string.aquarius;
//            case BirthdayDate.INDEX_PISCES:
//                return R.string.pisces;
//            case BirthdayDate.INDEX_ARIES:
//                return R.string.aries;
//            case BirthdayDate.INDEX_TAURUS:
//                return R.string.taurus;
//            case BirthdayDate.INDEX_GEMINI:
//                return R.string.gemini;
//            case BirthdayDate.INDEX_CANCER:
//                return R.string.cancer;
//            case BirthdayDate.INDEX_LEO:
//                return R.string.leo;
//            case BirthdayDate.INDEX_VIRGO:
//                return R.string.virgo;
//            case BirthdayDate.INDEX_LIBRA:
//                return R.string.libra;
//            case BirthdayDate.INDEX_SCORPIO:
//                return R.string.scorpio;
//            case BirthdayDate.INDEX_SAGITTARIUS:
//                return R.string.sagittarius;
//            default:
//                return R.string.unknown;
//        }
//    }
//
//    public static boolean validBirthdayDate(BirthdayDate birthdayDate) {
//        return birthdayDate != null && birthdayDate.getYear() > DEFAULT_START_YEAR && birthdayDate.getYear() < DEFAULT_END_YEAR
//                && birthdayDate.getMonthOfYear() >= 0 && birthdayDate.getMonthOfYear() < MAX_MONTH
//                && birthdayDate.getDayOfMonth() > 0 && birthdayDate.getDayOfMonth() <= MAX_MONTH_DATA;
//    }
//
//    public static void onClickDateView(final TextView textView) {
//        onClickDateView(textView, null);
//    }
//
//    public static void onClickDateView(final TextView textView, final DateViewListener listener) {
//        BirthdayDate date = new BirthdayDate(textView.getText().toString());
//        if (!validBirthdayDate(date)) {
//            Calendar calendar = Calendar.getInstance();
//            // 注意看系统代码，阴历时，calendar.get(Calendar.MONTH) 会返回 12, 有13个月。
//            int month = calendar.get(Calendar.MONTH);
//            date = new BirthdayDate(calendar.get(Calendar.YEAR), ((month >= MAX_MONTH) ? (MAX_MONTH - 1) : month)
//                    , calendar.get(Calendar.DAY_OF_MONTH));
//        }
//        DatePickerDialog.OnDateSetListener mOnDateSetListener = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                BirthdayDate date = new BirthdayDate(year, monthOfYear, dayOfMonth);
//                textView.setText(date.toString());
//                if (listener != null) {
//                    listener.onDateChoosed(date.toMillisecond());
//                }
//            }
//        };
//        Dialog dialog = new DatePickerDialog(textView.getContext(), R.style.DatePickerStyle, mOnDateSetListener
//                , date.getYear(), date.getMonthOfYear(), date.getDayOfMonth());
//        dialog.show();
//    }
//
//    public static void onClickDateView(final Context context, long defaultDate, final DateViewListener listener) {
//        BirthdayDate date = new BirthdayDate(defaultDate != 0 ? defaultDate : System.currentTimeMillis());
//        if (!validBirthdayDate(date)) {
//            Calendar calendar = Calendar.getInstance();
//            // 注意看系统代码，阴历时，calendar.get(Calendar.MONTH) 会返回 12, 有13个月。
//            int month = calendar.get(Calendar.MONTH);
//            date = new BirthdayDate(calendar.get(Calendar.YEAR), ((month >= MAX_MONTH) ? (MAX_MONTH - 1) : month)
//                    , calendar.get(Calendar.DAY_OF_MONTH));
//        }
//        DatePickerDialog.OnDateSetListener mOnDateSetListener = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                BirthdayDate date = new BirthdayDate(year, monthOfYear, dayOfMonth);
//                if (listener != null) {
//                    listener.onDateChoosed(date.toMillisecond());
//                }
//            }
//        };
//        Dialog dialog = new DatePickerDialog(context, R.style.DatePickerStyle, mOnDateSetListener
//                , date.getYear(), date.getMonthOfYear(), date.getDayOfMonth());
//        dialog.show();
//    }
//
//    public static void onClickTimeView(final TextView textView) {
//        String timeStr = textView.getText().toString();
//        if (timeStr.length() > 0) {
//            timeStr += ":10";
//        }
//
//        long timeMs = 0;
//        try {
//            timeMs = DateUtils.READABLE_TIME_FORMAT.parse(timeStr).getTime();
//        } catch (Exception e) {
//        }
//        Calendar calendar = Calendar.getInstance();
//        if (timeMs != 0) {
//            calendar.setTimeInMillis(timeMs);
//        }
//        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
//            @Override
//            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
//                textView.setText(String.format("%02d:%02d", hourOfDay, minute));
//            }
//        };
//        Dialog dialog = new TimePickerDialog(textView.getContext(), R.style.DatePickerStyle, onTimeSetListener
//                , calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true);
//        dialog.show();
//    }
//
//    public interface DateViewListener {
//        void onDateChoosed(long dataMs);
//    }
}
