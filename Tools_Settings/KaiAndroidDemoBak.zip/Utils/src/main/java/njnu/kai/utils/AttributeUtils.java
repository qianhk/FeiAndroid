package njnu.kai.utils;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;

/**
 * author：luck
 * project：PictureSelector
 * package：njnu.kai.pic.selector.tools
 * email：893855882@qq.com
 * data：2017/5/27
 */

public class AttributeUtils {

    public static int getColor(Context context, int attr) {
        int[] attribute = new int[]{attr};
        TypedArray array = context.obtainStyledAttributes(attribute);
        int color = array.getColor(0, -1);
        array.recycle();
        return color;
    }

    public static boolean getBoolean(Context context, int attr) {
        int[] attribute = new int[]{attr};
        TypedArray array = context.obtainStyledAttributes(attribute);
        boolean statusFont = array.getBoolean(0, false);
        array.recycle();
        return statusFont;
    }

    public static int getDrawableResourceId(Context context, int attr) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(attr, typedValue, true);
        return typedValue.resourceId;
    }

    public static Drawable getDrawable(Context context, int attr) {
        int[] attribute = new int[]{attr};
        TypedArray array = context.obtainStyledAttributes(attribute);
        Drawable drawable = array.getDrawable(0);
        array.recycle();
        return drawable;
    }

    //http://solo.farbox.com/blog/how-to-get-value-of-attr-in-code
//    public static int getTypeValueColor(Context context, int attr) {
//        TypedValue typedValue = new TypedValue();
//        context.getTheme().resolveAttribute(android.R.attr.textAppearanceLarge, typedValue, true);
//        int[] attribute = new int[]{attr};
//        TypedArray array = context.obtainStyledAttributes(typedValue.resourceId, attribute);
//        int color = array.getColor(0, -1);
//        array.recycle();
//        return color;
//    }
}
