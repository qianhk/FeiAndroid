package njnu.kai.utils;

import android.content.SharedPreferences;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class SharedPreferencesUtils {
    private static final Method APPLY_METHOD = applyMethod();

    private static Method applyMethod() {
        try {
            Class<SharedPreferences.Editor> clazz = SharedPreferences.Editor.class;
            return clazz.getMethod("apply");
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * @param editor SharedPreferences.Editor
     * @see android.content.SharedPreferences.Editor#apply()
     */
    public static void apply(SharedPreferences.Editor editor) {
        if (APPLY_METHOD != null) {
            try {
                APPLY_METHOD.invoke(editor);
                return;
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
        editor.commit();
    }
}
