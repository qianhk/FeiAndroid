package njnu.kai.utils;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;

/**
 * 创建桌面图标
 *
 * 完善的适配多种系统的可参见https://github.com/xuyisheng/ShortcutHelper
 *
 * @version 4.1.0
 * @since: 13-11-1 下午2:18
 */
public class ShortcutUtils {
    /**
     * 创建桌面图标
     *
     * @param context      上下文
     * @param clazz        类
     * @param iconResId    程序图标
     * @param shortcutName 快捷方式名称
     */
    public static void createShortcut(Context context, Class clazz, int iconResId, String shortcutName) {
        Intent shortcutIntent = new Intent(Intent.ACTION_MAIN);
        shortcutIntent.setClassName(context, clazz.getName());

        Intent intent = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
        intent.putExtra("duplicate", true);
        intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, shortcutName);
        Parcelable icon = Intent.ShortcutIconResource.fromContext(context.getApplicationContext(),
                iconResId);
        intent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, icon);
        intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
        context.sendBroadcast(intent);
    }

    /**
     * 创建桌面图标
     *
     * @param context      上下文
     * @param urlScheme    url scheme
     * @param iconResId    程序图标
     * @param shortcutName 快捷方式名称
     */
    public static void createShortcut(Context context, Uri urlScheme, int iconResId, String shortcutName) {
        Intent actionIntent = new Intent(Intent.ACTION_VIEW);
        actionIntent.addCategory(Intent.CATEGORY_DEFAULT);
        actionIntent.setData(urlScheme);

        Intent intent = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
        intent.putExtra("duplicate", true);
        intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, shortcutName);
        Parcelable icon = Intent.ShortcutIconResource.fromContext(context.getApplicationContext(), iconResId);
        intent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, icon);
        intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, actionIntent);
        // 发送广播
        context.sendBroadcast(intent);
    }

    /**
     * 删除桌面图标
     *
     * @param context       上下文对象
     * @param appNameResId  app 的名称id
     * @param appClass      app包名字符串
     * @param isAddCategory 是否添加到 CATEGORY_LAUNCHER
     */
    public static void deleteShortcut(Context context, int appNameResId, String appClass, boolean isAddCategory) {
        Intent shortcut = new Intent("com.android.launcher.action.UNINSTALL_SHORTCUT");

        //快捷方式的名称
        shortcut.putExtra(Intent.EXTRA_SHORTCUT_NAME, context.getApplicationContext().getString(appNameResId));
        ComponentName componentName = new ComponentName(context.getPackageName(), appClass);
        Intent intent = new Intent(Intent.ACTION_MAIN);
        if (isAddCategory) {
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
        }
        intent.setComponent(componentName);
        shortcut.putExtra(Intent.EXTRA_SHORTCUT_INTENT, intent);
        context.sendBroadcast(shortcut);
    }

}
