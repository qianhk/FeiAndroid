package njnu.kai.utils;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

/**
 * @author kai
 * @version 1.0.0
 */
public class BirthdayDate {

    private static final int DAY_OF_MONTH_20 = 20;
    private static final int DAY_OF_MONTH_21 = 21;
    private static final int DAY_OF_MONTH_22 = 22;
    private static final int DAY_OF_MONTH_23 = 23;

    private static final String BIRTHDAY_DATE_FORMATION = "%d-%d-%d";

    public static final int INDEX_CAPRICORN = 0;
    public static final int INDEX_AQUARIUS = 1;
    public static final int INDEX_PISCES = 2;
    public static final int INDEX_ARIES = 3;
    public static final int INDEX_TAURUS = 4;
    public static final int INDEX_GEMINI = 5;
    public static final int INDEX_CANCER = 6;
    public static final int INDEX_LEO = 7;
    public static final int INDEX_VIRGO = 8;
    public static final int INDEX_LIBRA = 9;
    public static final int INDEX_SCORPIO = 10;
    public static final int INDEX_SAGITTARIUS = 11;

    private static int sNowYear;

    private int mYear;
    private int mMonthOfYear;
    private int mDayOfMonth;

    static {
        Calendar calendar = Calendar.getInstance();
        sNowYear = calendar.get(Calendar.YEAR);
    }

    /**
     * 构造方法
     *
     * @param year       年
     * @param month      月
     * @param dayOfMonth 日
     */
    public BirthdayDate(int year, int month, int dayOfMonth) {
        mYear = year;
        mMonthOfYear = month;
        mDayOfMonth = dayOfMonth;
    }

    /**
     * 构造方法
     *
     * @param timeMs 时间，定义同 {@link System#currentTimeMillis()}
     */
    public BirthdayDate(long timeMs) {
        initWithTimeMs(timeMs);
    }

    public BirthdayDate() {
        initWithTimeMs(System.currentTimeMillis());
    }

    private void initWithTimeMs(long timeMs) {
        Calendar calendar = Calendar.getInstance();
        sNowYear = calendar.get(Calendar.YEAR);
        calendar.setTimeInMillis(timeMs);
        mYear = calendar.get(Calendar.YEAR);
        mMonthOfYear = calendar.get(Calendar.MONTH);
        mDayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
    }

    public BirthdayDate(String dateStr) {
        long timeMs = parseStrToTimeMs(dateStr);
        initWithTimeMs(timeMs);
    }

    private static long parseStrToTimeMs(String dateStr) {
        long timeMs = System.currentTimeMillis();
        try {
            timeMs = DateUtils.READABLE_DATE_FORMAT.parse(dateStr).getTime();
        } catch (Exception e) {
        }
        return timeMs;
    }

    /**
     * 获取年
     *
     * @return year
     */
    public int getYear() {
        return mYear;
    }

    /**
     * 获取月
     *
     * @return month
     */
    public int getMonthOfYear() {
        return mMonthOfYear;
    }

    /**
     * 获取日
     *
     * @return day
     */
    public int getDayOfMonth() {
        return mDayOfMonth;
    }

    @Override
    public String toString() {
        // 注意，这里的month计数从0开始，因此需要+1
        return String.format(BIRTHDAY_DATE_FORMATION, mYear, mMonthOfYear + 1, mDayOfMonth);
    }

    /**
     * @return 年龄
     */
    public int getAge() {
        return sNowYear - mYear;
    }

    /**
     * 转换为秒
     *
     * @return 秒
     */
    public long toSecond() {
        return TimeUnit.MILLISECONDS.toSeconds(toMillisecond());
    }

    /**
     * 转换为毫秒
     *
     * @return 毫秒
     */
    public long toMillisecond() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(mYear, mMonthOfYear, mDayOfMonth);
        return calendar.getTimeInMillis();
    }

    @Override
    public boolean equals(Object o) {
        return (o instanceof BirthdayDate)
                && mYear == ((BirthdayDate) o).mYear
                && mMonthOfYear == ((BirthdayDate) o).mMonthOfYear
                && mDayOfMonth == ((BirthdayDate) o).mDayOfMonth;
    }

    @Override
    public int hashCode() {
        return (int) toSecond();
    }

    /**
     * 获取星座序号
     * <p>星座     日期(公历)    英文名</p>
     * <p>魔羯座 (12/22 - 1/19) Capricorn</p>
     * <p>水瓶座 (1/20 - 2/18) Aquarius</p>
     * <p>双鱼座 (2/19 - 3/20) Pisces</p>
     * <p>牡羊座 (3/21 - 4/20) Aries</p>
     * <p>金牛座 (4/21 - 5/20) Taurus</p>
     * <p>双子座 (5/21 - 6/21) Gemini</p>
     * <p>巨蟹座 (6/22 - 7/22) Cancer</p>
     * <p>狮子座 (7/23 - 8/22) Leo</p>
     * <p>处女座 (8/23 - 9/22) Virgo</p>
     * <p>天秤座 (9/23 - 10/22) Libra</p>
     * <p>天蝎座 (10/23 - 11/21) Scorpio</p>
     * <p>射手座 (11/22 - 12/21) Sagittarius</p>
     *
     * @return 序号，从0开始，顺序如上
     */
    public int getConstellationIndex() {
        switch (mMonthOfYear) {
            case Calendar.JANUARY:
                if (mDayOfMonth < DAY_OF_MONTH_20) {
                    return INDEX_CAPRICORN;
                }
                return INDEX_AQUARIUS;
            case Calendar.FEBRUARY:
                if (mDayOfMonth < DAY_OF_MONTH_20) {
                    return INDEX_AQUARIUS;
                }
                return INDEX_PISCES;
            case Calendar.MARCH:
                if (mDayOfMonth < DAY_OF_MONTH_21) {
                    return INDEX_PISCES;
                }
                return INDEX_ARIES;
            case Calendar.APRIL:
                if (mDayOfMonth < DAY_OF_MONTH_21) {
                    return INDEX_ARIES;
                }
                return INDEX_TAURUS;
            case Calendar.MAY:
                if (mDayOfMonth < DAY_OF_MONTH_21) {
                    return INDEX_TAURUS;
                }
                return INDEX_GEMINI;
            case Calendar.JUNE:
                if (mDayOfMonth < DAY_OF_MONTH_22) {
                    return INDEX_GEMINI;
                }
                return INDEX_CANCER;
            case Calendar.JULY:
                if (mDayOfMonth < DAY_OF_MONTH_23) {
                    return INDEX_CANCER;
                }
                return INDEX_LEO;
            case Calendar.AUGUST:
                if (mDayOfMonth < DAY_OF_MONTH_23) {
                    return INDEX_LEO;
                }
                return INDEX_VIRGO;
            case Calendar.SEPTEMBER:
                if (mDayOfMonth < DAY_OF_MONTH_23) {
                    return INDEX_VIRGO;
                }
                return INDEX_LIBRA;
            case Calendar.OCTOBER:
                if (mDayOfMonth < DAY_OF_MONTH_23) {
                    return INDEX_LIBRA;
                }
                return INDEX_SCORPIO;
            case Calendar.NOVEMBER:
                if (mDayOfMonth < DAY_OF_MONTH_22) {
                    return INDEX_SCORPIO;
                }
                return INDEX_SAGITTARIUS;
            case Calendar.DECEMBER:
                if (mDayOfMonth < DAY_OF_MONTH_22) {
                    return INDEX_SAGITTARIUS;
                }
                return INDEX_CAPRICORN;
            default:
                return 0;
        }
    }

    public static String addDate(String dateStr, int addDay) {
        long timeMs = parseStrToTimeMs(dateStr);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timeMs);
        calendar.add(Calendar.DAY_OF_YEAR, addDay);
        return DateUtils.getReadableDate(calendar.getTimeInMillis());
    }
}
