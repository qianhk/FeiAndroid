package njnu.kai.utils;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Typeface;
import androidx.annotation.DimenRes;
import android.util.DisplayMetrics;

import java.lang.reflect.Field;

/**
 * @author kai
 * @version 1.0.0
 * 显示相关总汇
 */
public class DisplayUtils {

    private static DisplayMetrics sDisplayMetrics;
    private static Configuration sConfiguration;
    private static Typeface sIconTypeFace;

    private static int sSystemStatusBarHeight;

    /**
     * ldpi
     */
    public static final String EX_DENSITY_LOW = "_ldpi";
    /**
     * mdpi
     */
    public static final String EX_DENSITY_MEDIUM = "_mdpi";
    /**
     * hdpi
     */
    public static final String EX_DENSITY_HIGH = "_hdpi";
    /**
     * xhdpi
     */
    public static final String EX_DENSITY_XHIGH = "_xhdpi";
    /**
     * xxhdpi
     */
    public static final String EX_DENSITY_XXHIGH = "_xxhdpi";

    private static final float ROUND_DIFFERENCE = 0.5f;
    private static final int DENSITY_400 = 400;

    private static Resources sResources;

    /**
     * 初始化操作
     * @param context context
     */
    public static void init(Context context) {
        sResources = context.getResources();
        sDisplayMetrics = sResources.getDisplayMetrics();
        sConfiguration = sResources.getConfiguration();
//        initStatusBarHeight(context);

        try {
            sIconTypeFace = Typeface.createFromAsset(context.getAssets(), "fonts/IconFont.ttf");
        } catch (Exception e) {
            DebugUtils.doNothing();
        }
    }

    public static boolean isInited() {
        return sDisplayMetrics != null;
    }

    /**
     * 配置发生变化
     * @param context context
     * @param newConfiguration newConfiguration
     */
    public static void onConfigurationChanged(Context context, Configuration newConfiguration) {
        sDisplayMetrics = context.getResources().getDisplayMetrics();
        sConfiguration = newConfiguration;
    }

    /**
     * 获取屏幕宽度 单位：像素 (不含系统栏的屏幕的高度和宽度，即不含状态栏和导航栏)
     * @return 屏幕宽度
     */
    public static int getWidthPixels() {
        return sDisplayMetrics.widthPixels;
    }

    /**
     * 获取屏幕高度 单位：像素 (不含系统栏的屏幕的高度和宽度，即不含状态栏和导航栏)
     * @return 屏幕高度
     */
    public static int getHeightPixels() {
        return sDisplayMetrics.heightPixels;
    }

    /**
     * 获取Density
     * @return Density
     */
    public static float getDensity() {
        return sDisplayMetrics.density;
    }

    /**
     * 获取DensityDpi
     * @return DensityDpi
     */
    public static int getDensityDpi() {
        return sDisplayMetrics.densityDpi;
    }

    /**
     * dp 转 px
     * 注意正负数的四舍五入规则
     * @param dp dp值
     * @return 转换后的像素值
     */
    public static int dp2px(int dp) {
        if (sDisplayMetrics == null) { //editMode
            return dp << 1;
        }
        return (int)(dp * sDisplayMetrics.density + (dp > 0 ? ROUND_DIFFERENCE : -ROUND_DIFFERENCE));
    }

    /**
     * @param resId res id
     * @return dimen文件相关id里指定的值，返回px
     */
    public static int dimenPx(@DimenRes int resId) {
        return sResources.getDimensionPixelSize(resId);
    }

    /**
     * px 转 dp
     * 注意正负数的四舍五入规则
     * @param px px值
     * @return 转换后的dp值
     */
    public static int px2dp(int px) {
        return (int)(px / sDisplayMetrics.density + (px > 0 ? ROUND_DIFFERENCE : -ROUND_DIFFERENCE));
    }

    public static int sp2px(float spValue) {
        final float fontScale = sDisplayMetrics.scaledDensity;
        return (int) (spValue * fontScale + 0.5f);
    }

    public static int px2sp(float pxValue) {
        final float fontScale = sDisplayMetrics.scaledDensity;
        return (int) (pxValue / fontScale + 0.5f);
    }

    /**
     * get bitmap density
     * @return String
     */
    public static String getBitmapDensityStr() {
        switch (getBitmapDensity()) {
            case DisplayMetrics.DENSITY_LOW:
                return EX_DENSITY_LOW;
            case DisplayMetrics.DENSITY_MEDIUM:
                return EX_DENSITY_MEDIUM;
            case DisplayMetrics.DENSITY_HIGH:
                return EX_DENSITY_HIGH;
            case DisplayMetrics.DENSITY_XHIGH:
                return EX_DENSITY_XHIGH;
            case DisplayMetrics.DENSITY_XXHIGH:
                return EX_DENSITY_XXHIGH;
            default:
                return "";
        }
    }

    /**
     * @return 图形字体
     */
    public static Typeface getIconTypeFace() {
        return sIconTypeFace;
    }

    /**
     * 获取bitmapDensity
     * @return bitmapDensity
     */
    public static int getBitmapDensity() {
        int densityDpi = sDisplayMetrics.densityDpi;
        if (densityDpi <= DisplayMetrics.DENSITY_LOW) {
            return DisplayMetrics.DENSITY_LOW;
        } else if (densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            return DisplayMetrics.DENSITY_MEDIUM;
        } else if (densityDpi <= DisplayMetrics.DENSITY_HIGH) {
            return DisplayMetrics.DENSITY_HIGH;
        } else if (densityDpi <= DisplayMetrics.DENSITY_XHIGH) {
            return DisplayMetrics.DENSITY_XHIGH;
        } else if (densityDpi <= /*DisplayMetrics.DENSITY_400*/DENSITY_400) {
            return DisplayMetrics.DENSITY_XHIGH;
        } else {
            return DisplayMetrics.DENSITY_XXHIGH;
        }
    }

    public static int colorFromRes(int resId) {
        return sResources.getColor(resId);
    }

    /**
     * 是否为竖屏
     * @return true/false
     */
    public static boolean isPortrait() {
        return sConfiguration.orientation == Configuration.ORIENTATION_PORTRAIT
                || (sConfiguration.orientation == Configuration.ORIENTATION_UNDEFINED && getHeightPixels() > getWidthPixels());
    }

    /**
     *
     * @return 获取屏幕状态栏高度
     */
//    public static int getStatusBarHeight() {
//        return sSystemStatusBarHeight;
//    }

//    /**
//     * 通过反射获取屏幕状态栏高度,默认为25dp
//     * @param context Context上下文资源
//     */
//    public static void initStatusBarHeight(Context context) {
//        sSystemStatusBarHeight = dp2px(25); //默认为25dp
//        try {
//            Class<?> c = Class.forName("com.android.internal.R$dimen");
//            Object obj = c.newInstance();
//            Field field = c.getField("status_bar_height");
//            int x = Integer.parseInt(field.get(obj).toString());
//            sSystemStatusBarHeight = dimenPx(x);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    {
//        //方法五
//        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.R) {
////            获取的是实际显示区域指定包含系统装饰的内容的显示部分
//            int width = getWindowManager().getCurrentWindowMetrics().getBounds().width();
//            int height = getWindowManager().getCurrentWindowMetrics().getBounds().height();
//            Log.e(TAG, "width: " + width + ",height:" + height); //720,1491
//            Insets insets = getWindowManager().getCurrentWindowMetrics().getWindowInsets()
//                    .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars());
//            Log.e(TAG, "去掉任何系统栏的宽度:" + (width - insets.right - insets.left) + ",去掉任何系统栏的高度:" + (height - insets.bottom - insets.top));
//        } else {
//            //获取减去系统栏的屏幕的高度和宽度
//            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
//            int width = displayMetrics.widthPixels;
//            int height = displayMetrics.heightPixels;
//            Log.e(TAG, "width: " + width + ",height:" + height); //720,1491
//        }
//
//    }
}
