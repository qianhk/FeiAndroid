package njnu.kai.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * @version 1.0.0
 */
public class TimeUtils {

    /**
     * 得到时间的文字描述
     *
     * @param differMs differMs
     * @return 文字时间
     */
    private static String getRoundDateDescription(long differMs) {

        // 在android2.3以下的版本，TimeUnit类不齐全，因此需要自己换算时间单位
        final int secondsOfMinute = 60;
        final int secondsOfHour = 3600;
        final int secondsOfDay = 86400;
        final int secondsOfMonth = 2592000; // 固定以30天为1个月计算
        final int secondsOfYear = 31536000;

        long differSecond = differMs / 1000;

        long year = differSecond / secondsOfYear;
        if (year != 0) {
            // 显示为n年前
            return year + "年前";
        }

        long month = differSecond / secondsOfMonth;
        if (month != 0) {
            // 显示为n个月前
            return month + "月前";
        }

        long day = differSecond / secondsOfDay;
        if (day != 0) {
            // 显示为n天前
            return day + "天前";
        }

        long hour = differSecond / secondsOfHour;
        if (hour != 0) {
            // 显示为n个小时前
            return hour + "小时前";
        }

        long minute = differSecond / secondsOfMinute;
        if (minute > 0) {
            // 显示为n分钟前
            return minute + "分钟前";
        }

        // 显示为刚刚
        return "刚刚";
    }

    private static SimpleDateFormat MONTH_DATE_HOURE_MINUTE_DATE_FORMAT = new SimpleDateFormat("MM-dd HH:mm");

    public static String millisecsToDateString(long timestamp) {
        long differMs = System.currentTimeMillis() - timestamp;
        if (differMs < 1000 * 60 * 60 * 24) {
            return getRoundDateDescription(differMs);
        } else {
            return MONTH_DATE_HOURE_MINUTE_DATE_FORMAT.format(new Date(timestamp));
        }
    }

    /**
     * 获取详细时间描述
     *
     * @param second 以秒为单位的时间
     * @return 格式化后的时间显示
     */
    public static String getExactDateDescription(long second) {
        try {
            // 在android2.3以下的版本，TimeUnit类不齐全，因此需要自己换算时间单位
            final int secondsOfDay = 86400;
            String result;
            Date date = new Date(TimeUnit.SECONDS.toMillis(second));
            Date dateNow = new Date();
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            String todayStr = format.format(new Date());
            Date today = format.parse(todayStr);
            long differSecond = TimeUnit.MILLISECONDS.toSeconds(today.getTime()) - second;

            if (differSecond <= secondsOfDay && differSecond + secondsOfDay >= 0) {
                SimpleDateFormat f = new SimpleDateFormat("E");
                result = f.format(date);
                if (differSecond <= 0) {
                    result = "今天 " + result;
                } else {
                    result = "昨天 " + result;
                }
            } else {
                format = new SimpleDateFormat("yyyy");
                if (format.format(dateNow).equals(format.format(date))) {
                    result = new SimpleDateFormat("MM-dd E").format(date);
                } else {
                    result = new SimpleDateFormat("yyyy-MM-dd E").format(date);
                }
            }
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取时间字符描述
     *
     * @param seconds 时间描述
     * @return String
     */
    public static String getExactTimeDescription(long seconds) {
        SimpleDateFormat f = new SimpleDateFormat("kk:mm");
        return f.format(TimeUnit.SECONDS.toMillis(seconds));
    }
}
