package njnu.kai.utils;

import android.graphics.Point;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import njnu.kai.AppRuntime;

/**
 * Date: 12-8-31
 * Time: 下午4:26
 *
 * @version 4.0.0
 */
public class ToastUtils {

    private final static int DEFAULT_DURATION = Toast.LENGTH_SHORT;

    private static Toast mToast;

    public static boolean sUseSystemToast = true;

    /**
     * 自定义Toast样式
     *
     * @param message  显示的信息内容
     * @param duration 显示时长，单位毫秒，如果输入0，则默认显示时长为 Toast.LENGTH_SHORT
     */
    private static void showToast(String message, int duration) {

        if (sUseSystemToast) {

            if (duration == 0) {
                duration = DEFAULT_DURATION;
            }

            if (mToast == null) {
                mToast = Toast.makeText(AppRuntime.getContext(), message, duration);
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    View view = mToast.getView();
                    mToast.cancel();
                    mToast = new Toast(AppRuntime.getContext());
                    mToast.setView(view);
                    mToast.setDuration(duration);
                }
                mToast.setText(message);
            }
            mToast.show();

//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
//                Toast.makeText(AppRuntime.getContext(), message, duration).show();
//            } else {
//                if (mToast == null) {
//                    mToast = Toast.makeText(AppRuntime.getContext(), message, duration);
//                }
//                mToast.setText(message);
//                mToast.setDuration(duration);
//                mToast.show();
//            }
        } else {
            InternalToastUtil.show(message);
        }
    }

    /**
     * 使用系统方式显示 toast， 显示时间长度为 Toast.LENGTH_SHORT
     *
     * @param messageResourceId 显示的信息内容
     */
    public static void showToast(int messageResourceId) {
        String message = AppRuntime.getContext().getResources().getString(messageResourceId);
        showToast(message, DEFAULT_DURATION);
    }

    /**
     * @param format format
     * @param params params
     */
    public static void showToast(String format, Object... params) {
        showToast(String.format(format, params));
    }

    /**
     * 使用系统方式显示 toast， 显示时间长度为 Toast.LENGTH_SHORT
     *
     * @param message 显示的信息内容
     */
    public static void showToast(String message) {
        showToast(message, DEFAULT_DURATION);
    }

//    public static void showToast(BaseResult result) {
//        if (result == null || !result.isSuccess()) {
//            showToast("操作失败:" + (result != null ? result.getMessage() : "-98"));
//        }
//    }

}
