package njnu.kai.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class ComponentLauncher {

    private final static String LOG_TAG = "ComponentLauncher";
    private final static int MAX_SLEEP_VALUE = 10000;
    private final static int SLEEP_MODE_INPUT_LENGTH = 4;

    private ComponentLauncher() {
    }

    /**
     * 获取本机蓝牙组件(Intent对象)
     *
     * @param context 上下文对象
     * @param files   传输的文件
     * @return Intent
     */
    public static Intent getBlueToothIntent(Context context, File[] files) {
        Intent shareIntent = new Intent();
        shareIntent.setType("*/*");

        if (files.length > 1) {
            ArrayList<Uri> uris = new ArrayList<Uri>(files.length);
            for (File file : files) {
                uris.add(Uri.fromFile(file));
            }
            shareIntent.putExtra(Intent.EXTRA_STREAM, uris);
            shareIntent.setAction(Intent.ACTION_SEND_MULTIPLE);
        } else {
            shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(files[0]));
            shareIntent.setAction(Intent.ACTION_SEND);
        }

        PackageManager packageManager = context.getPackageManager();
        List<ResolveInfo> shareInfo = packageManager.queryIntentActivities(shareIntent, PackageManager.COMPONENT_ENABLED_STATE_DEFAULT);
        String packageName = "";
        String activityName = "";
        for (ResolveInfo resolveInfo : shareInfo) {
            if (resolveInfo.activityInfo.packageName.contains("bluetooth")) {
                packageName = resolveInfo.activityInfo.packageName;
                activityName = resolveInfo.activityInfo.name;
                break;
            }
        }
        shareIntent.setClassName(packageName, activityName);

        return shareIntent;
    }


    /**
     * 不销毁程序返回到桌面
     *
     * @param activity activity
     */
    public static void backHome(Activity activity) {
        try {
            activity.startActivity(new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Throwable e) {
            LogUtils.e(LOG_TAG, "cannot start home launcher", e);
            activity.moveTaskToBack(true);
        }
    }

}
