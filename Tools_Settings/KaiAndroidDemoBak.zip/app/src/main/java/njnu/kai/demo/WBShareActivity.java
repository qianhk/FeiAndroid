package njnu.kai.demo;

import com.umeng.socialize.media.WBShareCallBackActivity;

/**
 * @author kai
 * @since 2017/8/3
 */
public class WBShareActivity extends WBShareCallBackActivity {
}
