package njnu.kai.demo.activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.google.zxing.client.android.Intents;

import njnu.kai.AppConfig;
import njnu.kai.demo.BuildConfig;
import njnu.kai.framework.Immersive.ImmersiveHelper;
import njnu.kai.framework.Immersive.ImmersiveObserver;
import njnu.kai.framework.Immersive.ImmersiveOnObserverInitedListener;
import njnu.kai.framework.UserConstant;
import njnu.kai.framework.WrapFragmentActivity;

import njnu.kai.demo.fragment.MainFragment;
import njnu.kai.demo.util.AppPreferences;
import njnu.kai.demo.util.Constant;
import njnu.kai.framework.WrapFragmentWithActionbarActivity;
import njnu.kai.framework.navigator.Navigator;
import njnu.kai.map.LocationManager;
import njnu.kai.utils.LogUtils;
import njnu.kai.utils.ToastUtils;

/**
 * @author kai
 * @version 1.0.0
 */
public class MainActivity extends WrapFragmentActivity implements BDLocationListener {

    private static final String TAG = "MainActivity";

    private static final int WHAT_DEAL_URL_SCHEME = 1;
    private static final int WHAT_CHECK_APP_VERSION = 2;

    private long mDownloadId;

    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case WHAT_DEAL_URL_SCHEME:
                    Navigator.openUrl((String) msg.obj);
                    break;

                case WHAT_CHECK_APP_VERSION:
//                    updateStarupPic();
//                    VersionManager.getInstance().checkVersion(MainActivity.this, true);
                    break;

                default:
                    break;
            }
        }
    };

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
//        LogUtils.d(TAG, "lookIntent onNewIntent %s extra=%s", intent.toString(), SettingUtils.bundleToString(intent.getExtras()));
        dealExternalIntent(intent);
    }


    @Override
    protected Class<MainFragment> wrapFragmentClass() {
        return MainFragment.class;
    }

    @Override
    public boolean needApplyStatusBarStyle() {
        return true;
    }

    @Override
    public boolean needApplyNavigationBarStyle() {
        return true;
    }

    @Override
    protected boolean needOverridePendingTransition() {
        return false;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//
        IntentFilter localIntentFilter = new IntentFilter(UserConstant.ACTION_LOGIN_SUCCESS);
        localIntentFilter.addAction(Constant.ACTION_DOWNLOAD_APK);
//        localIntentFilter.addAction(Action.ACTION_NEED_RELOGIN);
        localIntentFilter.addAction(Intents.Scan.ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(mLocalBroadcastReceiver, localIntentFilter);
//
//        IntentFilter globalIntentFilter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
//        registerReceiver(mGlobalBroadcastReceiver, globalIntentFilter);
//
//        PushService.setDefaultPushCallback(this, MainActivity.class);
//        doSavePush();
//        UrlSchemeInstaller.register();
//
//        LogUtils.d(TAG, "lookLean onCreate %s", getIntent().toString());
        onNewIntent(getIntent());
//
//        mHandler.sendEmptyMessageDelayed(WHAT_CHECK_APP_VERSION, 20 * 1000);
//        adjustStatusBar();
//        setTitle("abcdTitle");
    }

//    void adjustStatusBar() {
//        Window window = getWindow();
////        window.setStatusBarColor(Color.TRANSPARENT);
////        window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
////        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
////        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
////        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
////                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
////                | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
////        );
////        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
////        window.setStatusBarColor(Color.TRANSPARENT);
//
//    }

//    private void updateStarupPic() {
//        DataFetcher.fetch(this, GlobalApi.getAdvert(), result -> {
//            if (result != null && result.isSuccess()) {
//                Advert data = result.getData();
//                Advert oriData = AppPreferences.getStartupPic();
//                if (oriData != null) {
//                    data.setLastDisplayTimeMs(oriData.getLastDisplayTimeMs());
//                }
//                AppPreferences.setStartupPic(data);
//                if (data != null) {
//                    String cachedImagePath = ImageCacheUtils.getCachedImagePath(data.getImg());
//                    if (!FileUtils.fileExists(cachedImagePath)) {
//                        TaskScheduler.execute(MainActivity.this, () -> {
//                            return ImageLoadTask.download(data.getImg(), cachedImagePath);
//                        }, (success) -> {
//                        });
//                    }
//                }
//            } else if (result != null && result.getCode() == BaseResult.ERROR) {
//                AppPreferences.setStartupPic(null);
//            }
//        });
//    }

    @Override
    protected void onDestroy() {
        mHandler.removeCallbacksAndMessages(null);
//        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//        notificationManager.cancelAll();
//        LocationManager.getInstance().unregisterLocationListener(MainActivity.this);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mLocalBroadcastReceiver);
//        unregisterReceiver(mGlobalBroadcastReceiver);
        super.onDestroy();
    }

    private BroadcastReceiver mLocalBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isFinishing()) {
                return;
            }
            String action = intent != null ? intent.getAction() : null;
            LogUtils.i(TAG, "look_action local is : %s", action);
            if (Intents.Scan.ACTION.equals(action)) {
                final String result = intent.getStringExtra(Intents.Scan.RESULT);
                LogUtils.i(TAG, "look_action scan result is : %s", result);
                if (result != null && !Navigator.openUrl(result)) {
                    ToastUtils.showToast("scan result: %s", result);
                }
            }

//            if (UserConstant.ACTION_LOGIN_SUCCESS.equals(action)) {
//                doSavePush();
//                String installationId = AVInstallation.getCurrentInstallation().getInstallationId();
//                CommandCenter.instance().exeCommand(new Command(CommandID.INSTALL, installationId, GlobalType.ANDROID));
//                exitAllFragment();
//                setPrimaryFragment(new MainFragment());
//                ChatManager.getInstance().openClientWithSelfIdIfNeed(AppPreferences.simpleUser().getClientId(), null);
//                LocationManager.getInstance().registerLocationListener(MainActivity.this);
//                dealWantWhenTo();
//
//                if (intent.hasExtra(Constant.KEY_OPERATE_AFTER_LOGIN)) {
//                    getWindow().getDecorView().postDelayed(() -> dealAfterLogin(intent), 500);
//                }
//
//                DataFetcher.fetch(MainActivity.this, () -> UserApi.userInfo(AppPreferences.simpleUser().getUserId()).execute(), result -> {
//                    if (result != null && result.isSuccess() && result.getData() != null) {
//                        AppPreferences.setUserInfo(result.getData());
//                    }
//                });
//
//                tryLoginIm();
//
//            } else if (Constant.ACTION_DOWNLOAD_APK.equals(action)) {
//                downloadApk(intent);
//            } else if (Action.ACTION_NEED_RELOGIN.equals(action)) {
//                loginOut();
//            }
        }
    };

    private BroadcastReceiver mGlobalBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
//            if (isFinishing()) {
//                return;
//            }
//            String action = intent != null ? intent.getAction() : null;
//            LogUtils.i(TAG, "look_action global is : %s", action);
//            if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
//                long completeDownloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
//                if (completeDownloadId == mDownloadId) {
//                    downloadComplete(completeDownloadId);
//                }
//            }
        }
    };

    private void dealAfterLogin(Intent intent) {
        String operateAfterLogin = intent.getStringExtra(Constant.KEY_OPERATE_AFTER_LOGIN);
        long operateId = intent.getLongExtra(Constant.KEY_OPERATE_ID, 0L);
//        if (Constant.OPERATE_OPEN_GROUP.equals(operateAfterLogin)) {
//            launchFragment(GroupHomeV3Fragment.instantiate(operateId));
//        }
//        updateStarupPic();
    }


    private void dealWantWhenTo() {
//        if (AppPreferences.simpleUser() != null && AppPreferences.isNeedWantWhenTo()) {
//            AppPreferences.setNoNeedWantWhenTo();
//            getWindow().getDecorView().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    launchFragment(new MostWantToFragment());
//                }
//            }, 100);
//        }
    }

//    public void onShowFilterPage(HomeNearbyFragment fragment) {
//        FilterUserFragment filterUserFragment = new FilterUserFragment();
//        filterUserFragment.setFilter(fragment);
//        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//        transaction.add(R.id.main_content, filterUserFragment).addToBackStack(null).commitAllowingStateLoss();
//    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

//        if (AppPreferences.isNeedShowGuidePage()) {
//            AppPreferences.setGuidePageVersion(AppRuntime.Config.getAppVersion());
//            getWindow().getDecorView().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    Intent intent = new Intent(MainActivity.this, GuideActivity.class);
//                    startActivity(intent);
//                }
//            }, 200);
//        }
//        dealWantWhenTo();
//        String installationId = AVInstallation.getCurrentInstallation().getInstallationId();
//        LogUtils.d(TAG, "onPostCreate devId=%s", installationId);
//        CommandCenter.instance().exeCommand(new Command(CommandID.INSTALL, installationId, GlobalType.ANDROID));
//        LocationManager.getInstance().registerLocationListener(MainActivity.this);
//
        if (BuildConfig.DEBUG) {
            getWindow().getDecorView().postDelayed(new Runnable() {
                @Override
                public void run() {
                    doDeveloperFunction();
                }
            }, 3000);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        BaseFragment primaryFragment = getPrimaryFragment();
//        BaseFragment currentFragment = getCurrentFragment();
//        BaseFragment topFragment = getTopFragment();
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        pressAgainExitApp();
//        if (isFragmentBackStackEmpty()) {
//            moveTaskToBack(true);
//        } else {
//            super.onBackPressed();
//        }
    }

    public void loginOut() {
        AppPreferences.setSimpleUser(null);
//        AppPreferences.setImUser(null);
//        AppPreferences.setUserInfo(null);
//        DemoCache.setAccount(null);
//        try {
//            DBHelper.getCurrentUserInstance().closeHelper();
//            ChatManager.getInstance().closeWithCallback(null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        EntryUtils.openAccountActivity(this);
//        exitAllFragment();
//        NIMClient.getService(AuthService.class).logout();
//        setPrimaryFragment(new MainFragment());
    }

    @Override
    public void onReceiveLocation(BDLocation bdLocation) {
        LocationManager.getInstance().unregisterLocationListener(MainActivity.this);
    }


    public static void launch(Activity activity, Uri data) {
        Intent intent = new Intent(activity, MainActivity.class);
        intent.setData(data);
        activity.startActivity(intent);
    }


    private void dealExternalIntent(Intent intent) {
        Uri data = intent.getData();
        if (data != null) {
            if (AppConfig.sAppSchema.equals(data.getScheme())) {
                LogUtils.i(TAG, "lookUrlSchema url=" + data.toString());
                Message message = mHandler.obtainMessage(WHAT_DEAL_URL_SCHEME, data.toString());
                mHandler.sendMessageDelayed(message, 300);
            }
        }
    }

    private void downloadApk(Intent intent) {
//        String apkUrl = intent.getStringExtra(Constant.KEY_APK_URL);
//        String apkFilename = intent.getStringExtra(Constant.KEY_APK_FILENAME);
//        String notificationTitle = intent.getStringExtra(Constant.KEY_NOTIFICATION_TITLE);
//        String notificationDescription = intent.getStringExtra(Constant.KEY_NOTIFICATION_DESCRIPTION);
//
//        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(apkUrl));
//        request.setDestinationInExternalPublicDir(Constant.APK_DOWNLOAD_DIR, apkFilename);
//        request.setTitle(notificationTitle);
//        request.setDescription(notificationDescription);
////        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
////        request.setVisibleInDownloadsUi(false);
//        // request.allowScanningByMediaScanner();
//        // request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
//        // request.setShowRunningNotification(false);
//        // request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_HIDDEN);
//
//        request.setMimeType(ApkUtils.APK_MIME_TYPE);
//        DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
//        mDownloadId = downloadManager.enqueue(request);
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void downloadComplete(long downloadId) {
//        DownloadManager.Query query = new DownloadManager.Query().setFilterById(downloadId);
//        Cursor c = null;
//        String localFilename = null;
//        try {
//            DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
//            c = downloadManager.query(query);
//            if (c != null && c.moveToFirst()) {
//                if (SDKVersionUtils.hasHoneycomb()) {
//                    localFilename = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_FILENAME));
//                } else {
//                    String localUri = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
//                    final String fileUriPrefix = "file://";
//                    if (localUri != null && localUri.startsWith(fileUriPrefix)) {
//                        localFilename = localUri.substring(fileUriPrefix.length());
//                    }
//                }
//            }
//        } finally {
//            if (c != null) {
//                try {
//                    c.close();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//        ApkUtils.install(MainActivity.this, localFilename);
    }

    private void doDeveloperFunction() {
        //TODO 为开发方便直接打开某个页面或者启动某个功能

//        Random random = new Random(System.currentTimeMillis());
//        int abc = random.nextInt(100);
//        int b = random.nextBoolean() ? 1 : 0;
//        String string = null;
//        if (b > 0) {
//            string = "string";
//        }
//        b = string.equals("abc") ? 1 : 0;
//        abc /= b;
//        abc += 10;
//        LogUtils.i("TAG", " " + abc);
    }
}
