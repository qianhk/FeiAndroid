package njnu.kai.demo.util;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import njnu.kai.framework.UserConstant;
import njnu.kai.utils.BirthdayDate;
import njnu.kai.utils.DateUtils;
import njnu.kai.demo.R;

import java.util.Calendar;

/**
 * @author kai
 * @version 1.0.0
 */
public class DateTimeViewUtils {

    /**
     * 获取星座
     *
     * @param constellationIndex    星座索引
     * @return 文本资源id
     */
    public static int getConstellationCharsequeceResource(int constellationIndex) {
        switch (constellationIndex) {
            case BirthdayDate.INDEX_CAPRICORN:
                return R.string.capricorn;
            case BirthdayDate.INDEX_AQUARIUS:
                return R.string.aquarius;
            case BirthdayDate.INDEX_PISCES:
                return R.string.pisces;
            case BirthdayDate.INDEX_ARIES:
                return R.string.aries;
            case BirthdayDate.INDEX_TAURUS:
                return R.string.taurus;
            case BirthdayDate.INDEX_GEMINI:
                return R.string.gemini;
            case BirthdayDate.INDEX_CANCER:
                return R.string.cancer;
            case BirthdayDate.INDEX_LEO:
                return R.string.leo;
            case BirthdayDate.INDEX_VIRGO:
                return R.string.virgo;
            case BirthdayDate.INDEX_LIBRA:
                return R.string.libra;
            case BirthdayDate.INDEX_SCORPIO:
                return R.string.scorpio;
            case BirthdayDate.INDEX_SAGITTARIUS:
                return R.string.sagittarius;
            default:
                return R.string.unknown;
        }
    }

    private static boolean validBirthdayDate(BirthdayDate birthdayDate) {
        return birthdayDate != null && birthdayDate.getYear() > UserConstant.DEFAULT_START_YEAR && birthdayDate.getYear() < UserConstant.DEFAULT_END_YEAR
                && birthdayDate.getMonthOfYear() >= 0 && birthdayDate.getMonthOfYear() < UserConstant.MAX_MONTH
                && birthdayDate.getDayOfMonth() > 0 && birthdayDate.getDayOfMonth() <= UserConstant.MAX_MONTH_DATA;
    }

    public static void onClickDateView(final TextView textView) {
        onClickDateView(textView, null);
    }

    public static void onClickDateView(final TextView textView, final DateViewListener listener) {
        BirthdayDate date = new BirthdayDate(textView.getText().toString());
        if (!validBirthdayDate(date)) {
            Calendar calendar = Calendar.getInstance();
            // 注意看系统代码，阴历时，calendar.get(Calendar.MONTH) 会返回 12, 有13个月。
            int month = calendar.get(Calendar.MONTH);
            date = new BirthdayDate(calendar.get(Calendar.YEAR), ((month >= UserConstant.MAX_MONTH) ? (UserConstant.MAX_MONTH - 1) : month)
                    , calendar.get(Calendar.DAY_OF_MONTH));
        }
        DatePickerDialog.OnDateSetListener mOnDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                BirthdayDate date = new BirthdayDate(year, monthOfYear, dayOfMonth);
                textView.setText(date.toString());
                if (listener != null) {
                    listener.onDateChoosed(date.toMillisecond());
                }
            }
        };
        Dialog dialog = new DatePickerDialog(textView.getContext(), R.style.DatePickerStyle, mOnDateSetListener
                , date.getYear(), date.getMonthOfYear(), date.getDayOfMonth());
        dialog.show();
    }

    public static void onClickDateView(final Context context, String defaultDateStr, final DateViewListener listener) {
        BirthdayDate date = new BirthdayDate(defaultDateStr);
        onClickDateView(context, listener, date);
    }

    public static void onClickDateView(final Context context, long defaultDate, final DateViewListener listener) {
        BirthdayDate date = new BirthdayDate(defaultDate != 0 ? defaultDate : System.currentTimeMillis());
        onClickDateView(context, listener, date);
    }

    private static void onClickDateView(Context context, final DateViewListener listener, BirthdayDate date) {
        if (!validBirthdayDate(date)) {
            Calendar calendar = Calendar.getInstance();
            // 注意看系统代码，阴历时，calendar.get(Calendar.MONTH) 会返回 12, 有13个月。
            int month = calendar.get(Calendar.MONTH);
            date = new BirthdayDate(calendar.get(Calendar.YEAR), ((month >= UserConstant.MAX_MONTH) ? (UserConstant.MAX_MONTH - 1) : month)
                    , calendar.get(Calendar.DAY_OF_MONTH));
        }
        DatePickerDialog.OnDateSetListener mOnDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                BirthdayDate date = new BirthdayDate(year, monthOfYear, dayOfMonth);
                if (listener != null) {
                    listener.onDateChoosed(date.toMillisecond());
                }
            }
        };
        Dialog dialog = new DatePickerDialog(context, R.style.DatePickerStyle, mOnDateSetListener
                , date.getYear(), date.getMonthOfYear(), date.getDayOfMonth());
        dialog.show();
    }

    public static void onClickTimeView(final TextView textView) {
        String timeStr = textView.getText().toString();
        if (timeStr.length() > 0) {
            timeStr += ":10";
        }

        long timeMs = 0;
        try {
            timeMs = DateUtils.READABLE_TIME_FORMAT.parse(timeStr).getTime();
        } catch (Exception e) {
        }
        Calendar calendar = Calendar.getInstance();
        if (timeMs != 0) {
            calendar.setTimeInMillis(timeMs);
        }
        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                textView.setText(String.format("%02d:%02d", hourOfDay, minute));
            }
        };
        Dialog dialog = new TimePickerDialog(textView.getContext(), R.style.DatePickerStyle, onTimeSetListener
                , calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true);
        dialog.show();
    }

    public interface DateViewListener {
        void onDateChoosed(long dataMs);
    }
}
