package njnu.kai.demo.list;

import android.os.Bundle;
import android.view.View;

import me.drakeet.multitype.IPagingListAdapter;
import njnu.kai.framework.paging.PagingListPresenter;
import njnu.kai.framework.paging.PagingRecyclerViewFragment;

/**
 * @author kai
 *
 */
public class MultiTypeListFragment extends PagingRecyclerViewFragment {


    @Override
    protected PagingListPresenter onCreatePresenter() {
        return new TestPagingListPresenter(this);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setLastPageText("到最后一页啦");
    }

    @Override
    protected IPagingListAdapter onCreateAdapter() {
        return makeGlobalMultiTypeAdapter();
    }

}
