package njnu.kai.demo.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import androidx.annotation.Nullable;

import com.alibaba.fastjson.JSON;

import java.util.ArrayList;

import njnu.kai.SimpleUser;
import njnu.kai.framework.BaseApplication;
import njnu.kai.multitype.IUser;
import njnu.kai.utils.SharedPreferencesUtils;
import njnu.kai.utils.StringUtils;

/**
 * @author kai
 * @version 1.0.0
 */
public final class AppPreferences {

    private static final String KEY_SIMPLE_USER = "key_simple_user";
    private static final String KEY_GUIDE_PAGE_VERSION = "key_guide_page_version";
    private static final String KEY_GUIDE_RECORD = "key_guide_record";
    private static final String KEY_WANT_WHEN_TO = "key_want_when_to";
    private static final String KEY_USER_REAL_NAME = "key_user_real_name";
    private static final String KEY_USER_PHONE_NUMBER = "key_user_phone_number";
    private static final String KEY_USER_ID_CARD_NUMBER = "key_user_id_card_number";
    private static final String KEY_USER_EMAIL = "key_user_email";

    private static final String KEY_STARTUP_GUIDE_VERSION = "key_startup_guide_version";

    private static final String KEY_LAST_CHECK_UPDATE_TIME = "key_last_check_update_time";
    private static final String KEY_LAST_CHECK_UPDATE_VERSION = "key_last_check_update_version";

    private static final String KEY_LAST_LOGIN_PHONE = "key_last_login_phone";

    private static SimpleUser sSimpleUser;

//    private static IMUser sImUser;

//    public static User userInfo() {
//        String userJson = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).getString(KEY_LOGIN_USER, "");
//        User user = null;
//        if (!StringUtils.isEmpty(userJson)) {
//            user = GsonUtils.fromJsonString(userJson, User.class);
//        }
//        return user;
//    }

//    public static void setUserInfo(User user) {
//        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).edit();
//        String userJson = user != null ? GsonUtils.toJsonString(user) : "";
//        SharedPreferencesUtils.apply(edit.putString(KEY_LOGIN_USER, userJson));
//    }

    public static SimpleUser simpleUser() {
        if (sSimpleUser == null) {
            String userJson = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).getString(KEY_SIMPLE_USER, "");
            if (!StringUtils.isEmpty(userJson)) {
                sSimpleUser = JSON.parseObject(userJson, SimpleUser.class);
            }
        }
//        AppRuntime.sSimpleUser = sSimpleUser;
        return sSimpleUser;
    }

    public static void setSimpleUser(@Nullable SimpleUser user) {
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).edit();
        String userJson = user != null ? JSON.toJSONString(user) : "";
        SharedPreferencesUtils.apply(edit.putString(KEY_SIMPLE_USER, userJson));
//        AppRuntime.sSimpleUser = user;
        sSimpleUser = user;
    }

    public static boolean isSelf(long userId) {
        SimpleUser simpleUser = simpleUser();
        return simpleUser != null && simpleUser.getUserId() == userId;
    }

    public static boolean isSelf(IUser user) {
        return isSelf(user != null ? user.getUserId() : 0L);
    }

//    public static void setGoGoGuest(User user) {
//        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).edit();
//        String userJson = user != null ? GsonUtils.toJsonString(user) : "";
//        SharedPreferencesUtils.apply(edit.putString(KEY_GOGO_GUEST, userJson));
//    }

    public static void setCheckUpdateTime(long time) {
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).edit();
        edit.putLong(KEY_LAST_CHECK_UPDATE_TIME, time);
        SharedPreferencesUtils.apply(edit);
    }

    public static long lastCheckUpdateTime() {
        return PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).getLong(KEY_LAST_CHECK_UPDATE_TIME, 0);
    }

    public static void setCheckUpdateVersion(String version) {
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).edit();
        edit.putString(KEY_LAST_CHECK_UPDATE_VERSION, version);
        SharedPreferencesUtils.apply(edit);
    }

    public static String lastUpdateVersion() {
        return PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).getString(KEY_LAST_CHECK_UPDATE_VERSION, null);
    }

    public static void setStartupGuideVersion(String appVersion) {
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).edit();
        edit.putString(KEY_STARTUP_GUIDE_VERSION, appVersion);
        SharedPreferencesUtils.apply(edit);
    }

    public static String getStartupGuideVersion() {
        return PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).getString(KEY_STARTUP_GUIDE_VERSION, null);
    }

//    public static void setStartupPic(Advert advert) {
//        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).edit();
//        if (advert != null) {
//            edit.putString(KEY_START_UP_PIC, GsonUtils.toJsonString(advert));
//        } else {
//            edit.putString(KEY_START_UP_PIC, null);
//        }
//        SharedPreferencesUtils.apply(edit);
//    }
//
//    public static Advert getStartupPic() {
//        String string = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).getString(KEY_START_UP_PIC, null);
//        Advert advert = null;
//        if (StringUtils.isNotEmpty(string)) {
//            advert = GsonUtils.fromJsonString(string, Advert.class);
//        }
//        return advert;
//    }

    public static String lastLoginPhone() {
        return PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).getString(KEY_LAST_LOGIN_PHONE, null);
    }

    public static void setLastLoginPhone(String phone) {
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(BaseApplication.getApp()).edit();
        edit.putString(KEY_LAST_LOGIN_PHONE, phone);
        edit.apply();
    }

    /**
     * ************************** 以下用户相关设置 *************************
     */

    private static SharedPreferences getUserRelatedPreferences() {
        BaseApplication context = BaseApplication.getApp();
        SimpleUser simpleUser = simpleUser();
        if (simpleUser != null) {
            String preferencesFileName = context.getPackageName() + "_preferences_" + simpleUser.getUserId();
            return context.getSharedPreferences(preferencesFileName, Context.MODE_PRIVATE);
        } else {
            return PreferenceManager.getDefaultSharedPreferences(context);
        }
    }

    public static void setGuidePageVersion(String version) {
        SharedPreferences.Editor edit = getUserRelatedPreferences().edit();
        SharedPreferencesUtils.apply(edit.putString(KEY_GUIDE_PAGE_VERSION, version));
    }

    public static boolean isNeedShowGuidePage() {
        return false;
//        String lastVersion = getUserRelatedPreferences().getString(KEY_GUIDE_PAGE_VERSION, "");
//        String appVersion = EnvironmentUtils.Config.getAppVersion();
//        return !StringUtils.equal(lastVersion, appVersion);
    }

    private static GuideRecord sGuideRecord;

    public static GuideRecord guideRecord() {
        if (sGuideRecord == null) {
            String str = getUserRelatedPreferences().getString(KEY_GUIDE_RECORD, "");
            if (!StringUtils.isEmpty(str)) {
                sGuideRecord = JSON.parseObject(str, GuideRecord.class);
            }
            if (sGuideRecord == null) {
                sGuideRecord = new GuideRecord();
            }
        }
        return sGuideRecord;
    }

    public static void saveGuideRecord(GuideRecord guideRecord) {
        SharedPreferences.Editor edit = getUserRelatedPreferences().edit();
        String str = guideRecord != null ? JSON.toJSONString(guideRecord) : "";
        SharedPreferencesUtils.apply(edit.putString(KEY_GUIDE_RECORD, str));
    }

    public static boolean isNeedWantWhenTo() {
        return getUserRelatedPreferences().getBoolean(KEY_WANT_WHEN_TO, true);
    }

    public static void setNoNeedWantWhenTo() {
        SharedPreferences.Editor editor = getUserRelatedPreferences().edit();
        SharedPreferencesUtils.apply(editor.putBoolean(KEY_WANT_WHEN_TO, false));
    }

    public static void setUserRealName(String userRealName) {
        SharedPreferences.Editor edit = getUserRelatedPreferences().edit();
        edit.putString(KEY_USER_REAL_NAME, userRealName);
        SharedPreferencesUtils.apply(edit);
    }

    public static void setUserPhoneNumber(String userPhoneNumber) {
        SharedPreferences.Editor edit = getUserRelatedPreferences().edit();
        edit.putString(KEY_USER_PHONE_NUMBER, userPhoneNumber);
        SharedPreferencesUtils.apply(edit);
    }

    public static void setUserIdCardNumber(String userIdCardNumber) {
        SharedPreferences.Editor edit = getUserRelatedPreferences().edit();
        edit.putString(KEY_USER_ID_CARD_NUMBER, userIdCardNumber);
        SharedPreferencesUtils.apply(edit);
    }

    public static void setUserEmail(String userEmail) {
        SharedPreferences.Editor edit = getUserRelatedPreferences().edit();
        edit.putString(KEY_USER_EMAIL, userEmail);
        SharedPreferencesUtils.apply(edit);
    }

    public static String userRealName() {
        return getUserRelatedPreferences().getString(KEY_USER_REAL_NAME, null);
    }

    public static String userPhoneNumber() {
        return getUserRelatedPreferences().getString(KEY_USER_PHONE_NUMBER, null);
    }

    public static String userIdCardNumber() {
        return getUserRelatedPreferences().getString(KEY_USER_ID_CARD_NUMBER, null);
    }

    public static String userEmail() {
        return getUserRelatedPreferences().getString(KEY_USER_EMAIL, null);
    }

    private static ArrayList<Long> sNewCreateGroup;

    private static final String TREND_PIC_DELIMITER = "-KV^_^VK-";

}
