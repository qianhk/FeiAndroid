package njnu.kai.demo.list;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;

import com.alibaba.fastjson.JSON;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import njnu.kai.demo.R;
import njnu.kai.demo.list.bean.ProvinceBean;
import njnu.kai.demo.test.BaseTestRecyclerViewFragment;
import njnu.kai.demo.test.TestFunction;
import njnu.kai.dialog.ActionItem;
import njnu.kai.dialog.OnButtonClickListener;
import njnu.kai.dialog.base.WaitingDialog;
import njnu.kai.dialog.base.WeekTimePickerDialog;
import njnu.kai.dialog.list.ListDialog;
import njnu.kai.dialog.list.OnItemClickListener;
import njnu.kai.dialog.message.EditTextDialog;
import njnu.kai.dialog.message.MessageDialog;
import njnu.kai.dialog.pickerview.OptionsPickerView;
import njnu.kai.dialog.pickerview.TimePickerView;
import njnu.kai.dialog.popup.list.BottomListPopupWindow;
import njnu.kai.share.ShareType;
import njnu.kai.utils.DateUtils;
import njnu.kai.utils.FileUtils;
import njnu.kai.utils.ToastUtils;

/**
 * @author kai
 */
public class DialogTestListViewFragment extends BaseTestRecyclerViewFragment {

    private ArrayList<ProvinceBean> mOptions1List = new ArrayList<>();
    private ArrayList<ArrayList<String>> mOptions2List = new ArrayList<>();

    @Override
    protected String onGetUIPageName() {
        return "DialogTest";
    }

    @TestFunction("测试Dialog title message two button")
    public void onTest200() {
        MessageDialog.Builder builder = new MessageDialog.Builder(getBaseActivity());
        builder.setTitle("此乃标题啊").setMessage("某个有标题的消息在这里啊，哈哈\n此乃第二行").setPositiveTitle("好哇");
        builder.setPositiveListener(new OnButtonClickListener<MessageDialog>() {
            @Override
            public void onClick(MessageDialog result) {
                ToastUtils.showToast("点击了ok");
            }
        });
        builder.setNegativeListener(new OnButtonClickListener<MessageDialog>() {
            @Override
            public void onClick(MessageDialog result) {
                ToastUtils.showToast("点击了cancel");
            }
        });
        builder.build().show();
    }

    @TestFunction("测试Dialog message two button, can't cancel")
    public void onTest201() {
        MessageDialog.Builder builder = new MessageDialog.Builder(getBaseActivity());
        builder.setMessage("消息未设置标题，哈哈\n不能cancelable");
        builder.setPositiveListener(new OnButtonClickListener<MessageDialog>() {
            @Override
            public void onClick(MessageDialog result) {
                ToastUtils.showToast("点击了ok");
            }
        });
        builder.setNegativeListener(new OnButtonClickListener<MessageDialog>() {
            @Override
            public void onClick(MessageDialog result) {
                ToastUtils.showToast("点击了cancel");
            }
        });
        builder.setCancelable(false);
        builder.build().show();
    }

    @TestFunction("测试Dialog message ok and default_do_nothing")
    public void onTest202() {
        MessageDialog.Builder builder = new MessageDialog.Builder(getBaseActivity());
        builder.setMessage("消息未设置标题，哈哈\n此乃第二行");
        builder.setPositiveListener(new OnButtonClickListener<MessageDialog>() {
            @Override
            public void onClick(MessageDialog result) {
                ToastUtils.showToast("点击了ok");
            }
        });
        builder.setNegativeListenerWithNull();
        builder.build().show();
    }

    @TestFunction("测试Dialog title desc ok button")
    public void onTest203() {
        MessageDialog.Builder builder = new MessageDialog.Builder(getBaseActivity());
        builder.setTitle("一个按钮").setMessage("只有一个按钮的消息，一般来说应该是ok按钮，哈哈\n此乃第二行").setPositiveTitle("好哇");
        builder.setPositiveListener(new OnButtonClickListener<MessageDialog>() {
            @Override
            public void onClick(MessageDialog result) {
                ToastUtils.showToast("点击了ok");
            }
        });
        builder.build().show();
    }

    @TestFunction("测试Dialog desc cancel button")
    public void onTest204() {
        MessageDialog.Builder builder = new MessageDialog.Builder(getBaseActivity());
        builder.setMessage("没有标题且只有一个按钮的消息，也支持cancel按钮，哈哈\n此乃第二行").setNegativeTitle("Bad!");
        builder.setNegativeListener(new OnButtonClickListener<MessageDialog>() {
            @Override
            public void onClick(MessageDialog result) {
                ToastUtils.showToast("点击了cancel");
            }
        });
        builder.build().show();
    }

    @TestFunction("测试Dialog: one input")
    public void onTest210() {
        EditTextDialog.Builder builder = new EditTextDialog.Builder(getBaseActivity());
        builder.setTitle("Title");
        builder.setEditText("Haha");
        builder.setEditHint("Hint");
        builder.setCancelable(false);
        builder.setPositiveListener(new OnButtonClickListener<EditTextDialog>() {
            @Override
            public void onClick(EditTextDialog result) {
                ToastUtils.showToast("text=" + result.getFirstEditTextCharsequence());
            }
        });
        builder.build().show();
    }

    @TestFunction("测试Dialog: two input")
    public void onTest211() {
        EditTextDialog.Builder builder = new EditTextDialog.Builder(getBaseActivity());
        builder.setTitle("内测验证");
        builder.setCancelable(false);
        builder.appendEditItem(EditTextDialog.EditTextItemData.withId(0).setLabel("设备串号").setInputText("haha_imei_1234_abcd").setInputGravity(Gravity.CENTER).setCopyable());
        builder.appendEditItem(EditTextDialog.EditTextItemData.withId(1).setLabel("注册码:").setInputHint("请输入注册码").setInputGravity(Gravity.CENTER));
        builder.setPositiveListener(new OnButtonClickListener<EditTextDialog>() {
            @Override
            public void onClick(EditTextDialog dialog) {
                CharSequence snStr = dialog.getEditTextItemData(1).mInputText;
                ToastUtils.showToast("text=" + snStr);
            }
        });
        builder.setNegativeListener(new OnButtonClickListener<EditTextDialog>() {
            @Override
            public void onClick(EditTextDialog dialog) {
                ToastUtils.showToast("click cancel");
            }
        });
        builder.build().show();
    }

    @TestFunction("测试 ListDialog: cancelable(false), has footerView")
    public void onTest301() {
        ListDialog.Builder builder = new ListDialog.Builder(getBaseActivity(), ListDialog.MODE_NORMAL);
        builder.setTitle("Title");
        builder.setCancelable(false);
        builder.appendActionItem(ActionItem.withId(ShareType.WECHAT_FRIEND.ordinal()).setTitle(R.string.share_wechat).setIcon(R.drawable.share_icon_sns_weixin));
        builder.appendActionItem(ActionItem.withId(ShareType.WECHAT_CIRCLE.ordinal()).setTitle(R.string.share_wechat_friend).setIcon(R.drawable.share_icon_sns_weixinfriend));
        builder.appendActionItem(ActionItem.withId(ShareType.QQ.ordinal()).setTitle(R.string.share_qq).setIcon(R.drawable.share_icon_sns_qq));
        builder.appendActionItem(ActionItem.withId(ShareType.QZONE.ordinal()).setTitle(R.string.share_qq_zone).setIcon(R.drawable.share_icon_sns_qzone));
        builder.appendActionItem(ActionItem.withId(ShareType.SINA_WEIBO.ordinal()).setTitle(R.string.share_sina_weibo).setIcon(R.drawable.share_icon_sns_sina));
        builder.appendActionItem(ActionItem.withId(ShareType.OTHER.ordinal()).setTitle(R.string.share_other).setIcon(R.drawable.share_icon_sns_other));
        builder.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(ListDialog dialog, ActionItem item, int position) {
                ToastUtils.showToast("click pos=%d title=%s ", position, item.mTitle);
                dialog.dismiss();
            }
        });
        builder.build().show();
    }

    @TestFunction("测试 ListDialog: cancelable(true), no footerView")
    public void onTest302() {
        ListDialog.Builder builder = new ListDialog.Builder(getBaseActivity(), ListDialog.MODE_NORMAL);
        builder.setTitle("Title");
        for (int idx = 0; idx < 22; ++idx) {
            builder.appendActionItem(ActionItem.withId(idx).setTitle("Title" + idx).setSubtitle("subtitle" + idx));
        }
        builder.setFooterViewVisible(false);
        builder.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(ListDialog dialog, ActionItem item, int position) {
                ToastUtils.showToast("click pos=%d title=%s ", position, item.mTitle);
                dialog.dismiss();
            }
        });
        builder.build().show();
    }

//    @TestFunction("测试 ActionListDialog")
//    public void onTest303() {
//        ListDialog.Builder builder = new ListDialog.Builder(getBaseActivity(), ListDialog.MODE_ACTION);
//        builder.setTitle("Title");
//        for (int idx = 0; idx < 22; ++idx) {
//            builder.appendActionItem(ActionItem.withId(idx).setTitle("Title" + idx));
//        }
//        builder.setFooterViewVisible(false);
//        builder.setOnItemClickListener(new OnItemClickListener() {
//            @Override
//            public void onItemClick(ListDialog dialog, ActionItem item, int position) {
//                ToastUtils.showToast("click pos=%d title=%s ", position, item.mTitle);
//                dialog.dismiss();
//            }
//        });
//        builder.build().show();
//    }

    @TestFunction("测试 MultiChoiceListDialog")
    public void onTest304() {
        ListDialog.Builder builder = new ListDialog.Builder(getBaseActivity(), ListDialog.MODE_MULTI_CHOICE);
        builder.setTitle("Title");
        for (int idx = 0; idx < 22; ++idx) {
            builder.appendActionItem(ActionItem.withId(idx).setTitle("Title" + idx));
        }
        builder.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(ListDialog dialog, ActionItem item, int position) {
                ToastUtils.showToast("click pos=%d title=%s ", position, item.mTitle);
            }
        });
        builder.setPositiveListener(new OnButtonClickListener<ListDialog>() {
            @Override
            public void onClick(ListDialog dialog) {
                List<ActionItem> checkedItemList = dialog.getCheckedItemList();
                StringBuilder strBuilder = new StringBuilder();
                for (ActionItem actionItem : checkedItemList) {
                    if (strBuilder.length() > 0) {
                        strBuilder.append(' ');
                    }
                    strBuilder.append(actionItem.mId + ":" + actionItem.mTitle);
                }
                ToastUtils.showToast("select: " + strBuilder.toString());
            }
        });
        builder.build().show();
    }

    @TestFunction("测试 SingleChoiceListDialog")
    public void onTest305() {
        ListDialog.Builder builder = new ListDialog.Builder(getBaseActivity(), ListDialog.MODE_SINGLE_CHOICE);
        builder.setTitle("Title");
        for (int idx = 0; idx < 22; ++idx) {
            builder.appendActionItem(ActionItem.withId(idx).setTitle("Title" + idx).setSubtitle("Subtitle" + idx));
        }
        builder.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(ListDialog dialog, ActionItem item, int position) {
                ToastUtils.showToast("click pos=%d title=%s ", position, item.mTitle);
                dialog.dismiss();
            }
        });
        builder.build().show();
    }

    @TestFunction("显示WaittingDialog 3秒")
    public void onTest500() {
        WaitingDialog.showWaitingDialog(getBaseActivity(), "说明正在干啥干啥呢....");
        getView().postDelayed(new Runnable() {
            @Override
            public void run() {
                WaitingDialog.dismissWaitingDialog();
            }
        }, 3_000);
    }

    @TestFunction("显示WaittingDialog，中途更新显示内容")
    public void onTest501() {
        WaitingDialog.showWaitingDialog(getBaseActivity(), "第一个文本提示....");
        getView().postDelayed(new Runnable() {
            @Override
            public void run() {
                WaitingDialog.showWaitingDialog(getBaseActivity(), "哈哈，哇塞，新文字哎....");
                getView().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        WaitingDialog.dismissWaitingDialog();
                    }
                }, 1_500);
            }
        }, 1_500);
    }

    @TestFunction("从底部弹出来List选择项")
    public void onTest600() {
        final ArrayList<ActionItem> list = new ArrayList<>();
        for (int idx = 0; idx < 4; ++idx) {
            list.add(ActionItem.withId(idx).setTitle("试试底部弹框" + idx));
        }
        BottomListPopupWindow.with(getActivity()).setTitle("测试底部list").setDataList(list).setOnItemClickListener(new njnu.kai.dialog.popup.list.OnItemClickListener() {
            @Override
            public void onItemClick(BottomListPopupWindow popupWindow, ActionItem actionItem, int position) {
                if (position % 2 == 0) {
                    popupWindow.dismiss();
                } else {
                    popupWindow.dismissWithAnimation();
                }
                ToastUtils.showToast("you click pos=%d %s", position, actionItem.mTitle);
            }
        }).show(this);
    }

    @TestFunction("Week Time Picker Dialog")
    public void onTest700() {
        final WeekTimePickerDialog dialog = new WeekTimePickerDialog(getActivity(), new OnButtonClickListener<WeekTimePickerDialog>() {
            @Override
            public void onClick(WeekTimePickerDialog dialog) {
                final long weekFlag = dialog.getWeekFlag();
                final long time = dialog.getTime();
                final Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(time);
                ToastUtils.showToast("picker weekFlag=0x%08X time=%s week=%d"
                        , weekFlag, DateUtils.getReadableDateTime(time), calendar.get(Calendar.DAY_OF_WEEK) - 1);
            }
        });
        dialog.setTitle("测试week picker");
        dialog.show();
    }

    @TestFunction("TimePickerView(date)")
    public void onTest701() {
//        BirthdayDate date = new BirthdayDate("2017-09-08");
//        DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                BirthdayDate date = new BirthdayDate(year, monthOfYear, dayOfMonth);
////                textView.setText(date.toString());
////                if (listener != null) {
////                    listener.onDateChoosed(date.toMillisecond());
////                }
//                ToastUtils.showToast(date.toString());
//            }
//        };
//        Dialog dialog = new DatePickerDialog(getActivity(), R.style.DatePickerStyle, onDateSetListener
//                , date.getYear(), date.getMonthOfYear(), date.getDayOfMonth());
//        dialog.show();

        Calendar selectedDate = Calendar.getInstance();
        selectedDate.set(Calendar.YEAR, 2017);
        selectedDate.set(Calendar.MONTH, Calendar.SEPTEMBER);
        selectedDate.set(Calendar.DATE, 8);
        Calendar startDate = Calendar.getInstance();
        startDate.set(2013, 0, 23);
        Calendar endDate = Calendar.getInstance();
        endDate.set(2019, 11, 28);
        //时间选择器
        TimePickerView pvTime = new TimePickerView.Builder(getActivity(), new TimePickerView.OnTimeSelectListener() {
            @Override
            public void onTimeSelect(Date date, View v) {//选中事件回调
                // 这里回调过来的v,就是show()方法里面所添加的 View 参数，如果show的时候没有添加参数，v则为null
                /*btn_Time.setText(getTime(date));*/
                ToastUtils.showToast(DateUtils.getReadableDateTime(date.getTime()));
            }
        })
                //年月日时分秒 的显示与否，不设置则默认全部显示
                .setType(new boolean[]{true, true, true, false, false, false})
                .setLabel("年", "月", "日", "", "", "")
                .isCenterLabel(true)
                .setDate(selectedDate)
                .setRangDate(startDate, endDate)
                .build();
        pvTime.show(this);
    }

    @TestFunction("TimePickerView(time)")
    public void onTest702() {
//        String timeStr = "19:21";
//        if (timeStr.length() > 0) {
//            timeStr += ":10";
//        }
//
//        long timeMs = 0;
//        try {
//            timeMs = DateUtils.READABLE_TIME_FORMAT.parse(timeStr).getTime();
//        } catch (Exception e) {
//        }
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 19);
        calendar.set(Calendar.MINUTE, 21);
        Calendar startDate = Calendar.getInstance();
        startDate.set(2013, 0, 23);
        Calendar endDate = Calendar.getInstance();
        endDate.set(2019, 11, 28);
        //时间选择器
        TimePickerView pvTime = new TimePickerView.Builder(getActivity(), new TimePickerView.OnTimeSelectListener() {
            @Override
            public void onTimeSelect(Date date, View v) {//选中事件回调
                // 这里回调过来的v,就是show()方法里面所添加的 View 参数，如果show的时候没有添加参数，v则为null
                /*btn_Time.setText(getTime(date));*/
                ToastUtils.showToast(DateUtils.getReadableDateTime(date.getTime()));
            }
        })
                //年月日时分秒 的显示与否，不设置则默认全部显示
                .setType(new boolean[]{false, false, false, true, true, false})
                .setLabel("", "", "", "时", "分", "")
                .isCenterLabel(false)
                .setDate(calendar)
//                .setDividerType(WheelView.DividerType.WRAP)
                .setRangDate(startDate, endDate)
                .build();
        pvTime.show(this);
    }

    @TestFunction("OptionsPickerView(两联)")
    public void onTest703() {
        OptionsPickerView pvOptions = new OptionsPickerView.Builder(getActivity(), new OptionsPickerView.OnOptionsSelectListener() {
            @Override
            public void onOptionsSelect(int options1, int options2, int options3, View v) {
                //返回的分别是三个级别的选中位置
                String tx = mOptions1List.get(options1).getPickerViewText()
                        + mOptions2List.get(options1).get(options2)
                       /* + options3Items.get(options1).get(options2).get(options3).getPickerViewText()*/;
                ToastUtils.showToast(tx);
            }
        })
                .setTitleText("城市选择")
//                .setContentTextSize(20)//设置滚轮文字大小
                .setSelectOptions(0, 1)//默认选中项
//                .setBgColor(Color.BLACK)
//                .setTitleBgColor(Color.DKGRAY)
//                .setTitleColor(Color.LTGRAY)
//                .setCancelColor(Color.YELLOW)
//                .setSubmitColor(Color.YELLOW)
                .isCenterLabel(false) //是否只显示中间选中项的label文字，false则每项item全部都带有label。
//                .setLabels("省", "市", "区")
                .build();

        //pvOptions.setSelectOptions(1,1);
        /*pvOptions.setPicker(mOptions1List);//一级选择器*/
        pvOptions.setPicker(mOptions1List, mOptions2List);//二级选择器
        /*pvOptions.setPicker(mOptions1List, mOptions2List,options3Items);//三级选择器*/
        pvOptions.show(this);
    }

    @TestFunction("OptionsPickerView(省市区)")
    public void onTest704() {
        initProvinceCityAreaJsonData();
        OptionsPickerView pvOptions = new OptionsPickerView.Builder(getActivity(), new OptionsPickerView.OnOptionsSelectListener() {
            @Override
            public void onOptionsSelect(int options1, int options2, int options3, View v) {
                //返回的分别是三个级别的选中位置
                String tx = options1Items.get(options1).getPickerViewText()
                        + options2Items.get(options1).get(options2)
                       + options3Items.get(options1).get(options2).get(options3);
                ToastUtils.showToast(tx);
            }
        })
                .setTitleText("省市区选择")
                .setSelectOptions(9, 6)//默认选中项
                .build();

        pvOptions.setPicker(options1Items, options2Items, options3Items); //三级选择器
        pvOptions.show(this);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initOptionData();
    }

    private void initOptionData() {

        //选项1
        mOptions1List.add(new ProvinceBean("广东"));
        mOptions1List.add(new ProvinceBean("湖南"));
        mOptions1List.add(new ProvinceBean("广西"));

        //选项2
        ArrayList<String> options2Items_01 = new ArrayList<>();
        options2Items_01.add("广州");
        options2Items_01.add("佛山");
        options2Items_01.add("东莞");
        options2Items_01.add("珠海");
        ArrayList<String> options2Items_02 = new ArrayList<>();
        options2Items_02.add("长沙");
        options2Items_02.add("岳阳");
        options2Items_02.add("株洲");
        options2Items_02.add("衡阳");
        ArrayList<String> options2Items_03 = new ArrayList<>();
        options2Items_03.add("桂林");
        options2Items_03.add("玉林");
        mOptions2List.add(options2Items_01);
        mOptions2List.add(options2Items_02);
        mOptions2List.add(options2Items_03);

    }

    private List<ProvinceBean> options1Items;
    private ArrayList<ArrayList<String>> options2Items = new ArrayList<>();
    private ArrayList<ArrayList<ArrayList<String>>> options3Items = new ArrayList<>();


    private void initProvinceCityAreaJsonData() {//解析数据

        if (options1Items != null) {
            return;
        }

        String jsonData = FileUtils.loadFromAsset(getActivity(), "province.json");

        List<ProvinceBean> provinceBean = JSON.parseArray(jsonData, ProvinceBean.class);

        /**
         * 添加省份数据
         *
         * 注意：如果是添加的JavaBean实体，则实体类需要实现 IPickerViewData 接口，
         * PickerView会通过getPickerViewText方法获取字符串显示出来。
         */
        options1Items = provinceBean;

        final int provinceSize = provinceBean.size();
        for (int provincePos = 0; provincePos < provinceSize; provincePos++) {//遍历省份
            ArrayList<String> cityList = new ArrayList<>();//该省的城市列表（第二级）
            ArrayList<ArrayList<String>> provinceAreaList = new ArrayList<>();//该省的所有地区列表（第三极）

            final List<ProvinceBean.CityBean> cityBeanList = provinceBean.get(provincePos).cityList;
            final int citySize = cityBeanList.size();
            for (int cityPos = 0; cityPos < citySize; cityPos++) {//遍历该省份的所有城市

                final ProvinceBean.CityBean cityBean = cityBeanList.get(cityPos);
                cityList.add(cityBean.name);//添加城市

                ArrayList<String> areaList = new ArrayList<>();//该城市的所有地区列表
                //如果无地区数据，建议添加空字符串，防止数据为null 导致三个选项长度不匹配造成崩溃
                if (cityBean.areaList == null || cityBean.areaList.size() == 0) {
                    areaList.add("");
                } else {
                    final List<String> areaBeanList = cityBean.areaList;
                    final int areaSize = areaBeanList.size();
                    for (int areaPos = 0; areaPos < areaSize; areaPos++) {//该城市对应地区所有数据
                        areaList.add(areaBeanList.get(areaPos));//添加该城市所有地区数据
                    }
                }

                provinceAreaList.add(areaList);//添加该省所有地区数据
            }

            options2Items.add(cityList);
            options3Items.add(provinceAreaList);
        }
    }
}
