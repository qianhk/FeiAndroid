package njnu.kai.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import njnu.kai.AppRuntime;
import njnu.kai.utils.LogUtils;
import njnu.kai.utils.StringUtils;
import njnu.kai.demo.activity.MainActivity;
import njnu.kai.demo.util.AppPreferences;

/**
 * @author kai
 * @version 1.0.0
 */
public class EntryActivity extends Activity {

    private static final String TAG = "EntryActivity";

    private static boolean sInited = false;
    private static boolean sInitCompleted = false;

    private static final int DEFAULT_SPLASH_TIME = 600;

    private int mSplashTime = DEFAULT_SPLASH_TIME;

    private ViewGroup mLayoutWholeSplash;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        hideStatusBar();
        setContentView(R.layout.demo_entry_splash);
        mLayoutWholeSplash = (ViewGroup) findViewById(R.id.layout_whole_splash);
        LogUtils.d(TAG, "lookEntry onCreate");
    }

    @Override
    protected void onResume() {
        super.onResume();
        LogUtils.d(TAG, "lookEntry onResume %b %b", sInited, sInitCompleted);

        if (sInitCompleted) {
            startMainActivity();
        } else if (!sInited) {
            sInited = true;
//            Advert startupPic = AppPreferences.getStartupPic();
//            if (startupPic != null) {
//                String cachedImagePath = ImageCacheUtils.getCachedImagePath(startupPic.getImg());
//                if (FileUtils.fileExists(cachedImagePath)) {
////                    startupPic.setLastDisplayTimeMs(0); //供测试每次都看到启动画面
//                    if (System.currentTimeMillis() - startupPic.getLastDisplayTimeMs() > startupPic.getFreq() * ConstantUtils.MILLS_PER_HOUR) {
//                        Bitmap bitmap = ImageCacheUtils.requestImage(cachedImagePath, DisplayUtils.getWidthPixels(), DisplayUtils.getHeightPixels(), false);
//                        if (bitmap != null) {
//                            startupPic.setLastDisplayTimeMs(System.currentTimeMillis());
//                            AppPreferences.setStartupPic(startupPic);
//                            mSplashTime = startupPic.getDuration() * ConstantUtils.MILLIS_PER_SECOND;
//                            for (int idx = mLayoutWholeSplash.getChildCount() - 1; idx >= 0; --idx) {
//                                mLayoutWholeSplash.getChildAt(idx).setVisibility(View.INVISIBLE);
//                            }
//                            mLayoutWholeSplash.setBackgroundDrawable(new BitmapDrawable(bitmap));
//                            mLayoutWholeSplash.setOnClickListener(new View.OnClickListener() {
//                                @Override
//                                public void onClick(View v) {
//                                    startMainActivity();
//                                    mLayoutWholeSplash.setEnabled(false);
//                                    mLayoutWholeSplash.postDelayed(new Runnable() {
//                                        @Override
//                                        public void run() {
//                                            NavigatorJump.toFullPath(startupPic.getGo());
//                                        }
//                                    }, 300);
//                                }
//                            });
//                        }
//                    }
//                }
//            }
            getWindow().getDecorView().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startMainActivity();
                }
            }, mSplashTime);
        }
    }

    @Override
    protected void onDestroy() {
        if (mLayoutWholeSplash != null) {
            mLayoutWholeSplash.setOnClickListener(null);
            mLayoutWholeSplash.setBackgroundDrawable(null);
        }
        super.onDestroy();
    }

    private boolean dealExternalIntent(Intent intent) {
        final String dataString = intent.getDataString();
        if (!StringUtils.isEmpty(dataString)) {
            MainActivity.launch(this, intent.getData());
            return true;
        }
        return false;
    }

    private void startMainActivity() {
        sInitCompleted = true;
        if (!dealExternalIntent(getIntent())) {
            startActivity(new Intent(this, MainActivity.class));
        }
        String startupGuideVersion = AppPreferences.getStartupGuideVersion();
        if (!StringUtils.equal(startupGuideVersion, AppRuntime.Config.getAppVersion())) {
            AppPreferences.setStartupGuideVersion(AppRuntime.Config.getAppVersion());
//            startActivity(new Intent(this, StartupGuideActivity.class));
        }
        finish();
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }

//    protected void hideStatusBar() {
//        try {
//            final View decorView = getWindow().getDecorView();
//            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN
//                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
////            decorView.setSystemUiVisibility(uiOptions);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
}
