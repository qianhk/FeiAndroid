package njnu.kai.demo.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import njnu.kai.demo.R;

import njnu.kai.framework.StateViewWithActionBarFragment;
import njnu.kai.uikit.ActionBarLayout;
import njnu.kai.uikit.StateView;
import njnu.kai.utils.ToastUtils;
import njnu.kai.utils.ViewUtils;

public class StateViewWithActionbarTestFragment extends StateViewWithActionBarFragment {

    @Override
    protected void onInitActionBar() {
        super.onInitActionBar();
        setTitle("测试StateView");
        addTextAction(0, "切换");
    }

    @Override
    protected void onActionClick(int actionId, ActionBarLayout.Action action) {
        super.onActionClick(actionId, action);
        switchStateView();
    }

    @Override
    protected View onCreateContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.demo_fragment_state_view_test, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onConfigStateView(View view, StateView.State state) {
        super.onConfigStateView(view, state);
        if (state == StateView.State.NO_DATA) {
            ViewUtils.findTextViewById(view, R.id.tv_text).setText("空白文字测试");
        }
    }

    @Override
    protected void onStateViewRetryRequested() {
        ToastUtils.showToast("you clicked retry.");
    }

    public void switchStateView() {
        switch (getStateView().getCurrentState()) {
            case LOADING:
                setState(StateView.State.FAILED);
                break;

            case FAILED:
                setState(StateView.State.SUCCESS);
                break;

            case SUCCESS:
                setState(StateView.State.NO_DATA);
                break;

            case NO_DATA:
                setState(StateView.State.ONLY_WIFI);
                break;

            case ONLY_WIFI:
                setState(StateView.State.NO_COPYRIGHT);
                break;

            case NO_COPYRIGHT:
                setState(StateView.State.NO_NETWORK);
                break;

            case NO_NETWORK:
                setState(StateView.State.LOADING);
                break;

        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

}
