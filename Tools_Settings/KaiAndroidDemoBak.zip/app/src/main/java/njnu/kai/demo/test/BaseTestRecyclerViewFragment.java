package njnu.kai.demo.test;

import android.os.Bundle;
import android.text.method.KeyListener;
import android.view.View;
import android.widget.EditText;

import njnu.kai.demo.R;
import njnu.kai.demo.multitype.MethodAnnotationProvider;

import java.lang.reflect.Method;
import java.util.ArrayList;

import me.drakeet.multitype.BaseVO;
import me.drakeet.multitype.MultiTypeAdapter;
import njnu.kai.framework.paging.PagingListPresenter;
import njnu.kai.framework.paging.PagingRecyclerViewFragment;
import me.drakeet.multitype.IPagingListAdapter;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public abstract class BaseTestRecyclerViewFragment extends PagingRecyclerViewFragment {

    private EditText mEdtResult;

    public BaseTestRecyclerViewFragment() {
    }

    @Override
    protected IPagingListAdapter onCreateAdapter() {
        MultiTypeAdapter adapter = makeGlobalMultiTypeAdapter();
        adapter.register(MethodAnnotation.class, new MethodAnnotationProvider());
        return adapter;
    }

    @Override
    protected int listViewLayoutId() {
        return R.layout.demo_base_test_recyclerview;
    }

    @Override
    protected boolean needPtrAndLoadNextFeature() {
        return false;
    }

    protected View onContentViewInflated(View contentView) {
        this.mEdtResult = (EditText) contentView.findViewById(R.id.edt_result);
        this.mEdtResult.setKeyListener((KeyListener) null);
        setResultViewVisibility(View.GONE);
        return super.onContentViewInflated(contentView);
    }

    @Override
    protected PagingListPresenter onCreatePresenter() {
        return null;
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
//        PageBackground.setPageBackground(view.getContext(), view);
        Bundle arguments = this.getArguments();
        if (arguments != null) {
//            this.setTitle(arguments.getString("key_page_title"));
        }

        ArrayList annotationList = new ArrayList();
        Method[] declaredMethods = this.getClass().getDeclaredMethods();
        if (declaredMethods != null) {

            for (int idx = 0; idx < declaredMethods.length; ++idx) {
                Method method = declaredMethods[idx];
                if (method.isAnnotationPresent(TestFunction.class)) {
                    TestFunction annotation = method.getAnnotation(TestFunction.class);
                    annotationList.add(new MethodAnnotation(method, annotation.value()));
                }
            }
        }

        flushData(annotationList);
    }

    protected boolean enterAutoLoading() {
        return false;
    }

    public void setResultViewVisibility(int visibility) {
        this.mEdtResult.setVisibility(visibility);
    }

    private String transformToStr(Object object) {
        return object != null ? object.toString() : "<object=null>";
    }

    public void setResult(Object object) {
        this.mEdtResult.setText(this.transformToStr(object));
    }

    public void appendResult(Object object) {
        String oriStr = this.mEdtResult.getText().toString();
        this.mEdtResult.setText(oriStr + "\n" + this.transformToStr(object));
    }


    protected void beforeTest() {
    }

    @Override
    public void onMultiTypeViewClicked(BaseVO data, String action) {
        if (data instanceof MethodAnnotation) {
            MethodAnnotation methodAnnotation = (MethodAnnotation) data;
            beforeTest();
            methodAnnotation.invokeMethod(BaseTestRecyclerViewFragment.this);
        }
    }

}
