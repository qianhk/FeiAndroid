package njnu.kai.demo.util;

/**
 * @author kai
 * @version 1.0.0
 * @since 13/2/27
 */
public interface Constant {

    String KEY_OPERATE_AFTER_LOGIN = "key_operate_after_login";

    String KEY_OPERATE_ID = "key_id";

    String KEY_PIC_LIST = "key_pic_list";

    String KEY_TAG = "key_tag";

    String KEY_GROUP_INFO = "key_group_info";

    String KEY_PAID_INFO = "key_paid_info";

    String KEY_FAVOURABLE_ORDER_INFO = "key_favourablePayInfo";

    String KEY_JOURNEY = "key_journey";

    String KEY_PLAN = "key_plan";

    String KEY_GROUP_ID = "gid";

    String KEY_GROUP_BUY_ID = "key_group_buy_id";

    String KEY_JOINED = "key_joined";

    String KEY_PLAN_ID = "key_plan_id";

    String KEY_DAY = "key_day";

    String KEY_COUNTRY_ID = "key_country_id";

    String KEY_COUNTRY_NAME = "key_country_name";

    String KEY_CITY_ID = "key_city_id";

    String KEY_ORDER_ID = "key_order_id";

    String KEY_TRADE_NO = "key_trade_no";

    String KEY_CARRIER = "key_carrier";

    String KEY_GEEK_TRADE_NO = "key_geek_trade_no";

    String KEY_DIRECT_ADD = "key_direct_add";

    String KEY_TYPE_ID = "key_type_id";

    String KEY_OWNER_ID = "key_owner_id";

    String KEY_SEND_UI = "key_send_ui";

    String KEY_CAN_SEND = "key_can_send";

    String KEY_TITLE = "key_title";

    String KEY_KEYWORD = "key_keyword";

    String KEY_CITY = "key_city";

    String KEY_PLAN_INFO = "key_plan_info";

    String KEY_POI_INFO = "key_poi_info";

    String KEY_ADDRESS = "key_address";

    String KEY_CHOICE_MODE = "key_choice_mode";

    String KEY_INVITE_FRIEND = "key_invite_friend";

    String KEY_MANAGER = "key_manager";

    String KEY_SINGLE_CHOICE = "key_single_choice";

    String KEY_NEED_HEADER = "key_need_header";

    String KEY_AVOS_CHANNEL = "com.avos.avoscloud.Channel";

    String KEY_AVOS_DATA = "com.avos.avoscloud.Data";

    String KEY_IS_COUNTRY_ID = "key_is_country_id";

    String KEY_POSITION = "key_position";

    String KEY_DATE = "key_date";

    String KEY_EDITABLE = "key_editable";

    String KEY_START_DATE = "key_start_date";

    String KEY_START_CITY = "key_start_city";

    String KEY_PAY_INFO = "key_pay_info";

    String KEY_PAY_AMOUNT = "key_pay_amount";

    String KEY_PAY_CARRIER = "key_pay_carrier";

    String KEY_ORDER_INFO = "key_order_info";

    String KEY_ENABLE_STATUS = "key_enable_status";

    String KEY_DAY_ID = "key_day_id";

    String KEY_ADD_TO_PLAN_ID = "key_add_to_plan_id";

    String KEY_ADD_TO_DAY_ID = "key_add_to_day_id";

    String KEY_RECOMMEND_TITLE = "key_recommend_title";

    String KEY_SHOW_TYPE = "key_show_type";

    String KEY_COST_TYPE = "key_cost_type";

    String KEY_FLIGHT = "key_flight";

    String KEY_HOTEL = "key_hotel";

    String KEY_ROOM_INFO = "key_room_info";

    String KEY_TIME_SECTION_INFO = "key_time_section_info";

    String KEY_TOPIC_ID = "key_topic_id";

    String KEY_BASE_PRICE = "key_base_price";

    String KEY_GEEK_JOURNEY = "key_geek_journey";

    String KEY_ERROR_CODE = "key_error_code";

    String KEY_PERMISSION = "key_permission";

    int GALLERY_PIC_SIZE = 800;

    int REMIND_MUTE = 0x0;
    int REMIND_SOUND = 0x1;
    int REMIND_VIBRA = 0x2;
    int REMIND_SOUND_VIBRA = 0x3;

    int REMIND_SOUND_MAK = 0x1;
    int REMIND_VIBRA_MAK = 0x2;

    String CAMERA_FRONT = "front";
    String CAMERA_BACK = "back";


    int GROUP_COVER_RATIO = 2;

    int DEFAULT_HIGH_LIGHT_SPAN_COLOR = 0xff5293B9;
    int ORANGE_HIGH_LIGHT_SPAN_COLOR = 0xffFF8000;


    String OPERATE_OPEN_GROUP = "operate_open_group";

    String HTML_MIME_TYPE = "text/html; charset=UTF-8";

    String ACTION_DOWNLOAD_APK = "com.xxx.android.xxx.download_apk";
    String KEY_APK_URL = "key_apk_url";
    String KEY_APK_FILENAME = "key_apk_filename";
    String KEY_NOTIFICATION_TITLE = "key_notification_title";
    String KEY_NOTIFICATION_DESCRIPTION = "key_notification_description";
}
