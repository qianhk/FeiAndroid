package njnu.kai.demo.util;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.Shape;

/**
 * @author kai
 *
 */
public final class DrawableUtils {

    public static Drawable makeCircleDrawable(int color) {
        Shape shape = new OvalShape();
        ShapeDrawable shapeDrawable = new ShapeDrawable(shape);
        shapeDrawable.getPaint().setColor(color);
        return shapeDrawable;
    }
}
