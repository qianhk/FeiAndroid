package njnu.kai.demo.fragment;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import njnu.kai.AppConfig;
import njnu.kai.AppRuntime;
import njnu.kai.demo.R;
import njnu.kai.framework.BaseFragment;
import njnu.kai.framework.navigator.Navigator;
import njnu.kai.utils.ClipboardUtils;
import njnu.kai.utils.PackageUtils;
import njnu.kai.utils.ToastUtils;

/**
 * @author kai
 * @since 2022/2/9
 */
public class AboutFragment extends BaseFragment implements View.OnClickListener {

    private View mSupportEmailView;
    private View mForumView;
    private View mLayoutWeibo;
    private View mLayoutWechat;

    private TextView mTvVersion;
    private View mViewNewVersion;
    private TextView mTvMoreInfo;

    private static final String WEBSITE = "http://www.baidu.com/s?wd=KaiAbout";
    private static final String SUPPORT_EMAIL = "kai@kaikai.cn";
    private static final String SINA_WEIBO = "http://www.sina.com";
    private static final String WECHAT = "weTestChat:kaikai001";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.demo_fragment_about, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
//        setTitle(R.string.about);
        init(view);
        View layoutCheckUpdate = view.findViewById(R.id.layout_check_update);
        if (!AppRuntime.Config.isAppCheckUpdateEnable()) {
            layoutCheckUpdate.setVisibility(View.GONE);
        }
        layoutCheckUpdate.setOnClickListener(this);
        mViewNewVersion = view.findViewById(R.id.imageview_new_version);
        mViewNewVersion.setVisibility(View.GONE);
    }

    private void init(View view) {
        mForumView = view.findViewById(R.id.layout_forum);
        mForumView.setOnClickListener(this);
        setWebInteractiveView(mForumView, R.string.demo_website, WEBSITE);

//        mSupportEmailView = findViewById(R.id.layout_supported_email);
//        mSupportEmailView.setOnClickListener(this);
//        setWebInteractiveView(mSupportEmailView, R.string.service_email, SUPPORT_EMAIL);

        mLayoutWeibo = view.findViewById(R.id.layout_weibo);
        mLayoutWeibo.setOnClickListener(this);
        setWebInteractiveView(mLayoutWeibo, R.string.demo_weibo, SINA_WEIBO);

        mLayoutWechat = view.findViewById(R.id.layout_wechat);
        mLayoutWechat.setOnClickListener(this);
        setWebInteractiveView(mLayoutWechat, R.string.demo_wechat, WECHAT);
        mLayoutWechat.findViewById(R.id.imageview_entry).setVisibility(View.INVISIBLE);

        mTvVersion = view.findViewById(R.id.tv_version);
        initVersionView();

        mTvMoreInfo = view.findViewById(R.id.tv_more_info);
        mTvMoreInfo.setText(getEmailMessage(false));
    }

    private void initVersionView() {
        String version = PackageUtils.versionName(AppRuntime.getContext());
        mTvVersion.setText(version);
    }

    private void setWebInteractiveView(View view, int nameResId, String subNameText) {
        TextView name = (TextView) view.findViewById(R.id.textview_name);
        name.setText(nameResId);
        TextView subName = (TextView) view.findViewById(R.id.textview_subname);
        subName.setVisibility(View.VISIBLE);
        subName.setText(subNameText);
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        if (v == mForumView) {
            Navigator.openUrl(WEBSITE);
        } else if (v == mSupportEmailView) {
            supportEmailEvent();
        } else if (v == mLayoutWeibo) {
            Navigator.openUrl(SINA_WEIBO);
        } else if (v == mLayoutWechat) {
            ClipboardUtils.setText(AppRuntime.getContext(), WECHAT);
            ToastUtils.showToast("微信号已复制到系统剪贴板");
//            try {
//                Intent intent = new Intent(Intent.ACTION_VIEW);
//                intent.setData(Uri.parse("http://weixin.qq.com/r/ABCE8iu12BbwSjnDEF"));
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                startActivity(intent);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
        } else if (viewId == R.id.layout_check_update) {
//            VersionManager.getInstance().checkVersion(this, false);
            ToastUtils.showToast("暂无升级功能");
        }
    }

    private void ratingApp() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("market://details?id=" + getActivity().getPackageName()));

        try {
            startActivity(Intent.createChooser(intent, "应用市场"));
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void supportEmailEvent() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{SUPPORT_EMAIL});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Question about " + AppConfig.getDirName() +  "for Android");
        intent.putExtra(Intent.EXTRA_TEXT, getEmailMessage(true));
        intent.setType("plain/text");

        try {
            startActivity(Intent.createChooser(intent, getString(R.string.demo_mail_app_list_title)));
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    private String getEmailMessage(boolean hasSubfix) {
        final String wrapStr = "\n";
        StringBuilder infoBuilder = new StringBuilder();
        infoBuilder.append(getString(R.string.demo_version_info));
        infoBuilder.append(wrapStr);
        infoBuilder.append("Version: ");
        infoBuilder.append(AppRuntime.Config.getAppVersion());
        infoBuilder.append(wrapStr);
        infoBuilder.append("VersionName: ");
        infoBuilder.append(PackageUtils.versionName(AppRuntime.getContext()));
        infoBuilder.append(wrapStr);
        infoBuilder.append("VersionCode: ");
        infoBuilder.append(PackageUtils.versionCode(AppRuntime.getContext()));
        infoBuilder.append(wrapStr);
        infoBuilder.append("Market: ");
        infoBuilder.append(AppRuntime.Config.getChannel());
        infoBuilder.append(wrapStr);
        infoBuilder.append(wrapStr);
        infoBuilder.append(getString(R.string.demo_device_info));
        infoBuilder.append(wrapStr);
        infoBuilder.append("Device: ");
        infoBuilder.append(deviceInfo());
        infoBuilder.append(wrapStr);
        infoBuilder.append("Product: ");
        infoBuilder.append(Build.PRODUCT);
        infoBuilder.append(wrapStr);
        infoBuilder.append("Android: ");
        infoBuilder.append(Build.VERSION.RELEASE);
        infoBuilder.append("(");
        infoBuilder.append(Build.VERSION.SDK_INT);
        infoBuilder.append(")");
        infoBuilder.append(wrapStr);
        infoBuilder.append("FingerPrint: ");
        infoBuilder.append(Build.FINGERPRINT);
        if (hasSubfix) {
            infoBuilder.append(wrapStr);
            infoBuilder.append(wrapStr);
            infoBuilder.append(getString(R.string.demo_support_description));
            infoBuilder.append(':');
            infoBuilder.append(wrapStr);
            infoBuilder.append(wrapStr);
        }
        return infoBuilder.toString();
    }

    private String deviceInfo() {
        return Build.MANUFACTURER + " " + Build.MODEL + "(" + Build.DEVICE + ")";
    }
}
