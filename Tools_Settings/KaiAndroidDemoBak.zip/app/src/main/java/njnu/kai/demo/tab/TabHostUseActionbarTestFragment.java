package njnu.kai.demo.tab;

import njnu.kai.demo.fragment.TweetTestFragment;

import java.util.List;

import njnu.kai.framework.tab.BaseTabHostUseActionBarFragment;
import njnu.kai.uikit.tab.LocalTabViewProperties;

public class TabHostUseActionbarTestFragment extends BaseTabHostUseActionBarFragment {

    @Override
    protected void onInitActionBar() {
        super.onInitActionBar();
    }

    @Override
    protected void onBuildTabFragmentProperties(List<LocalTabViewProperties> tabViewPropertyList) {
        tabViewPropertyList.add(new LocalTabViewProperties(0, "First", TweetTestFragment.instantiate("first page")));
        tabViewPropertyList.add(new LocalTabViewProperties(1, "Second", TweetTestFragment.instantiate("second page")));
        tabViewPropertyList.add(new LocalTabViewProperties(2, "Third", TweetTestFragment.instantiate("third page")));
    }

}
