package njnu.kai.demo.list;

import android.os.Handler;
import android.os.Message;

import java.util.ArrayList;
import java.util.Random;

import njnu.kai.framework.paging.PagingListPresenter;
import njnu.kai.framework.paging.PagingRecyclerViewFragment;
import njnu.kai.multitype.vo.TextVO;

/**
 * @author kai
 *
 */
public class TestPagingListPresenter extends PagingListPresenter<PagingRecyclerViewFragment> {

    private Random mRandom = new Random(System.currentTimeMillis());

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    makeDataAndUpdate(msg.arg1);
                    break;
            }
        }
    };

    protected TestPagingListPresenter(PagingRecyclerViewFragment pageDataLoadingView) {
        super(pageDataLoadingView);
    }

    @Override
    protected void load(int page, boolean force) {
        Message msg = mHandler.obtainMessage(1, page, 0);
        mHandler.sendMessageDelayed(msg, 800);
    }

    private void makeDataAndUpdate(int page) {
        ArrayList<TextVO> textVOS = DataMaker.mockTextVoDataWithRandomLength(page, 24);
        if (true) {
            handleLoadSuccess(textVOS, 4, page);
        } else {
            handleLoadFailure(null);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacksAndMessages(null);
    }
}
