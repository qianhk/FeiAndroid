package njnu.kai.demo.fragment;

import android.graphics.Color;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import njnu.kai.framework.BaseFragment;
import njnu.kai.framework.search.ISearch;
import njnu.kai.utils.StringUtils;

public class TweetTestFragment extends BaseFragment implements ISearch {

    private TextView mTextView;

    private String mKeyword;

    public static TweetTestFragment instantiate(String tweet) {
        final Bundle bundle = new Bundle();
        bundle.putString("tweet", tweet);
        final TweetTestFragment fragment = new TweetTestFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mTextView = new TextView(inflater.getContext());
        mTextView.setText(getArguments() != null ? getArguments().getString("tweet", "has arg, but no tweet") : "no param");
        mTextView.setGravity(Gravity.CENTER);
        mTextView.setTextColor(Color.BLACK);
        return mTextView;
    }

    @Override
    protected void onLoadFinished() {
        super.onLoadFinished();
        if (StringUtils.isNotEmpty(mKeyword)) {
            mTextView.setText(mKeyword);
        }
    }

    @Override
    public void search(String word, String userInput) {
        mKeyword = word;
        if (isLoadFinished()) {
            mTextView.setText(word);
        }
    }
}
