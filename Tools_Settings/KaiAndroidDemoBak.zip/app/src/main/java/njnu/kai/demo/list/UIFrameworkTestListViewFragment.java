package njnu.kai.demo.list;

import android.content.Intent;
import android.net.Uri;

import njnu.kai.AppConfig;
import njnu.kai.demo.R;
import njnu.kai.demo.map.TestMapRequestLocationFragment;
import njnu.kai.demo.multitype.TestProviderPagingFragment;
import njnu.kai.demo.setting.SettingTestFragment;
import njnu.kai.demo.tab.TabHostTestFragment;
import njnu.kai.demo.tab.TabHostUseActionbarTestFragment;
import njnu.kai.demo.test.BaseTestRecyclerViewFragment;
import njnu.kai.demo.test.MethodAnnotation;
import njnu.kai.demo.test.TestFunction;
import njnu.kai.demo.ui.StateViewWithActionbarTestFragment;
import njnu.kai.demo.ui.TestActionbarFragment;
import njnu.kai.framework.WrapFragmentActivity;
import njnu.kai.framework.WrapFragmentWithActionbarActivity;
import njnu.kai.framework.navigator.Navigator;
import njnu.kai.utils.ShortcutUtils;
import njnu.kai.web.TTWebViewActivity;

/**
 * @author kai
 */
public class UIFrameworkTestListViewFragment extends BaseTestRecyclerViewFragment {

    @Override
    protected String onGetUIPageName() {
        return "UIFrameworkTest";
    }

    @TestFunction("MultiType no flush")
    public void onTest100() {
        WrapFragmentWithActionbarActivity.launch(getBaseActivity(), MultiTypeListNoFlushFragment.class, "无刷新MultiType");
    }

    @TestFunction("MultiType分页加载")
    public void onTest101() {
        WrapFragmentWithActionbarActivity.launch(getBaseActivity(), MultiTypeListFragment.class, "分页MultiType");
    }

    @TestFunction("StateView测试")
    public void onTest120() {
        WrapFragmentActivity.launch(getBaseActivity(), StateViewWithActionbarTestFragment.class);
    }

    @TestFunction("测试TabHostWithActionbar")
    public void onTest150() {
        WrapFragmentWithActionbarActivity.launch(getBaseActivity(), TabHostTestFragment.class, "TabHost Test");
    }

    @TestFunction("测试TabHostUseActionbar")
    public void onTest151() {
        WrapFragmentActivity.launch(getBaseActivity(), TabHostUseActionbarTestFragment.class);
    }

    @TestFunction("测试SearchBar (using navigator)")
    public void onTest160() {
//        launchActivity(TestSearchbarActivity.class);
        Navigator.openUrl("kai://page/test_searchbar?keyword=normalKeyword");
    }

    @TestFunction("测试Actionbar各模式")
    public void onTest161() {
        WrapFragmentWithActionbarActivity.launch(getBaseActivity(), TestActionbarFragment.class, "Actionbar Test");
    }

    @TestFunction("测试MultiType")
    public void onTest162() {
        WrapFragmentWithActionbarActivity.launch(getBaseActivity(), TestProviderPagingFragment.class, "测试MultiType");
    }

    @TestFunction("浏览器sina")
    public void onTest300() {
        TTWebViewActivity.launch(getBaseActivity(), "http://www.sina.com", "新浪啊啊");
    }

    @TestFunction("浏览器3g.cn (using nav builder)")
    public void onTest301() {
        Navigator.withPage("web").addParameter("url", "http://3g.cn").addParameter("title", "凯3g网").open();
    }

    @TestFunction("浏览器baidu (using navigator)")
    public void onTest302() {
//        TTWebViewActivity.launch(getBaseActivity(), "http://baidu.com", "试百度");
        Navigator.openUrl("kai://page/web?url=https://www.baidu.com/s?wd=%E8%AF%95%E8%AF%95%E7%99%BE%E5%BA%A6");
    }

    @TestFunction("浏览器baidu (using http)")
    public void onTest303() {
//        TTWebViewActivity.launch(getBaseActivity(), "http://baidu.com", "试百度");
        Navigator.openUrl("http://www.baidu.com/s?wd=%E8%AF%95%E8%AF%95%E7%99%BE%E5%BA%A6");
    }

    @TestFunction("浏览器 /sdcard/h5test.html")
    public void onTest304() {
//        TTWebViewActivity.launch(getBaseActivity(), "http://baidu.com", "试百度");
        Navigator.withPage("web").addParameter("url", "file:///sdcard/h5test.html").open();
    }

    @TestFunction("地图功能测试")
    public void onTest400() {
        WrapFragmentWithActionbarActivity.launch(getBaseActivity(), TestMapRequestLocationFragment.class, "Map功能测试");
    }

    @TestFunction("创建快捷方式page")
    public void onTest500() {
        ShortcutUtils.createShortcut(getBaseContext(), Uri.parse("kai://page/test_searchbar?keyword=abc"), R.drawable.demo_ic_launcher, "DemoPage");
    }

    @TestFunction("切换全局主题:Default")
    public void onTest000(MethodAnnotation vo) {
        final int themeId = AppConfig.ACTIVITY_THEME_ID;
        if (themeId == 0 || themeId == R.style.SkyBlueAppNoActionBarTheme) {
            vo.setAnnotation("切换全局主题:Orange");
            AppConfig.ACTIVITY_THEME_ID = R.style.OrangeAppNoActionBarTheme;
        } else if (themeId == R.style.OrangeAppNoActionBarTheme) {
            vo.setAnnotation("切换全局主题:Pink");
            AppConfig.ACTIVITY_THEME_ID = R.style.PinkAppNoActionBarTheme;
        } else if (themeId == R.style.PinkAppNoActionBarTheme) {
            AppConfig.ACTIVITY_THEME_ID = R.style.SkyBlueAppNoActionBarTheme;
            vo.setAnnotation("切换全局主题:skyBlue");
        }
        handleVoUpdated(vo);
    }

//    @TestFunction("创建快捷方式inner.page, 不能通过intent传递参数，还保留在了data里，且跳过了entryActivity的Main的流程")
//    public void onTest601() {
//        ShortcutUtils.createShortcut(getBaseContext(), Uri.parse("kai://inner.page/test_searchbar?keyword=xyz"), R.drawable.demo_ic_launcher, "DemoInnerPage");
//    }

    @TestFunction("设置页面")
    public void onTest700() {
        WrapFragmentWithActionbarActivity.launch(getBaseActivity(), SettingTestFragment.class, "设置UI测试");
    }

    protected void launchActivity(Class clazz) {
        Intent intent = new Intent(getContext(), clazz);
        getActivity().startActivity(intent);
    }

}
