package njnu.kai.demo.util;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * @author kai
 * @version 1.0.0
 * @since 15/4/29
 */
public final class GuideRecord {

    @JSONField(name = "search_group")
    private boolean mSearchGroup;

    @JSONField(name = "lookJourney")
    private boolean mLookJourney;

    @JSONField(name = "invite_make_journey")
    private boolean mInviteMakeJourney;

    @JSONField(name = "application_group")
    private boolean mApplicationGroup;

    public boolean isSearchGroup() {
        return mSearchGroup;
    }

    public boolean isLookJourney() {
        return mLookJourney;
    }

    public boolean isInviteMakeJourney() {
        return mInviteMakeJourney;
    }

    public boolean isApplicationGroup() {
        return mApplicationGroup;
    }

    public void setSearchGroup() {
        mSearchGroup = true;
    }

    public void setLookJourney() {
        mLookJourney = true;
    }

    public void setInviteMakeJourney() {
        mInviteMakeJourney = true;
    }

    public void setApplicationGroup() {
        mApplicationGroup = true;
    }
}
