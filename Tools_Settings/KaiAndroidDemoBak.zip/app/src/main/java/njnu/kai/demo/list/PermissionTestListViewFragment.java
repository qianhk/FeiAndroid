package njnu.kai.demo.list;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.Settings;

import com.tbruyelle.rxpermissions3.RxPermissions;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import njnu.kai.AppConfig;
import njnu.kai.AppRuntime;
import njnu.kai.demo.R;
import njnu.kai.demo.test.BaseTestRecyclerViewFragment;
import njnu.kai.demo.test.TestFunction;
import njnu.kai.utils.FileUtils;
import njnu.kai.utils.LogUtils;
import njnu.kai.utils.StringUtils;
import njnu.kai.utils.ToastUtils;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;


//    https://github.com/tbruyelle/RxPermissions
//    https://blog.csdn.net/yuguqinglei/article/details/80375702 Android 动态权限适配方案总结
//    https://www.jianshu.com/p/e94cea26e213  Android 11 外部存储权限适配指南及方案

public class PermissionTestListViewFragment extends BaseTestRecyclerViewFragment {

    private RxPermissions rxPermissions;
    private static final String TAG = "PermissionTest";

    @Override
    protected String onGetUIPageName() {
        return "PermissionTest";
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        rxPermissions = new RxPermissions(this);
    }

    @TestFunction("测试目录、存储api返回路径")
    public void onTest080() {
        final Context context = getContext();
        final StringBuilder strBuilder = new StringBuilder();
        strBuilder.append("以下内部存储\n");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            final File dataDir = context.getDataDir(); // /data/user/0/njnu.kai.demo
            strBuilder.append("getDataDir=" + dataDir.toString() + '\n');

        }
        final File filesDir = context.getFilesDir(); // /data/user/0/njnu.kai.demo/files
        strBuilder.append("getFilesDir=" + filesDir.toString() + '\n');
        final File cacheDir = context.getCacheDir(); // /data/user/0/njnu.kai.demo/cache
        strBuilder.append("getCacheDir=" + cacheDir.toString() + '\n');
        final File testName = context.getDir("testName", Context.MODE_PRIVATE); // /data/user/0/njnu.kai.demo/app_testName
        strBuilder.append("getdir(\"testName\")=" + testName.toString() + '\n');

        strBuilder.append("以下内置外部存储\n");
        final File externalCacheDir = context.getExternalCacheDir(); // /storage/emulated/0/Android/data/njnu.kai.demo/cache
        strBuilder.append("getExternalCacheDir=" + externalCacheDir.toString() + '\n');
        final File externalDCIMDir = context.getExternalFilesDir(Environment.DIRECTORY_DCIM); // /storage/emulated/0/Android/data/njnu.kai.demo/files/DCIM
        strBuilder.append("getExternalFilesDir(Environment.DIRECTORY_DCIM)=" + externalDCIMDir.toString() + '\n');
        final File externalPicDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES); // /storage/emulated/0/Android/data/njnu.kai.demo/files/Pictures
        strBuilder.append("getExternalFilesDir(Environment.DIRECTORY_PICTURES)=" + externalPicDir.toString() + '\n');

        strBuilder.append("以下外部存储\n");
        final String externalStorageState = Environment.getExternalStorageState(); // mounted
        strBuilder.append("getExternalStorageState=" + externalStorageState.toString() + '\n');
        final File externalStorageDirectory = Environment.getExternalStorageDirectory(); // /storage/emulated/0
        strBuilder.append("getExternalStorageDirectory=" + externalStorageDirectory.toString() + '\n');
        final File externalStorageDCIMDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM); // /storage/emulated/0/DCIM
        strBuilder.append("getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)=" + externalStorageDCIMDirectory.toString() + '\n');
        final File externalStoragePicDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES); // /storage/emulated/0/Pictures
        strBuilder.append("getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)=" + externalStoragePicDirectory.toString() + '\n');
        final File externalStorageDocumentDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS); // /storage/emulated/0/Documents
        strBuilder.append("getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)=" + externalStorageDocumentDirectory.toString() + '\n');
        final File externalStorageDownloadDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); // /storage/emulated/0/Download
        strBuilder.append("getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)=" + externalStorageDownloadDirectory.toString() + '\n');
        ToastUtils.showToast(strBuilder.toString());
        LogUtils.d(getClass().getSimpleName(), strBuilder.toString());
    }

    @TestFunction("申请写文件权限")
    public void onTest100() {
        rxPermissions
                .request(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .subscribe(granted -> {
                    if (granted) {
                        ToastUtils.showToast("request Permission granted.");
                    } else {
                        ToastUtils.showToast("request Permission not granted.");
                    }
                });
    }

    @TestFunction("api30申请管理文件权限")
    public void onTest101() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                ToastUtils.showToast("已经有ExternalStorageManager权限");
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getContext().getPackageName()));
                startActivityForResult(intent, 101);
            } else {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getContext().getPackageName()));
                startActivityForResult(intent, 101);
            }
        } else {
            ToastUtils.showToast("api版本 %d < 30", Build.VERSION.SDK_INT);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 101 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                ToastUtils.showToast("被授予ExternalStorageManager权限");
            } else {
                ToastUtils.showToast("还是没有ExternalStorageManager权限");
            }
        } else if (requestCode == 130) {
            if (resultCode == RESULT_OK) {
                final Uri dataUri = data.getData();
                final String txt = PermissionTestListViewFragment.readUriToString(dataUri);
                boolean result = false;
                try {
                    result = FileUtils.store("test for SAF:" + System.currentTimeMillis(), dataUri);
                    ToastUtils.showToast("result=%b 选择了：%s\n%s", result, data.getDataString(), txt);
                } catch (IllegalArgumentException e1) {
                    LogUtils.w(TAG, "step1: uri=%s e=%s", dataUri, e1.toString());
                    ToastUtils.showToast("step1 : %s", e1.toString());
                    final ArrayList<Uri> uris = new ArrayList<>();
//                    final List<String> pathSegments = dataUri.getPathSegments();
                    final String lastPathSegment = dataUri.getLastPathSegment();
//                    final String fragment = dataUri.getFragment();
//                    final String query = dataUri.getQuery();
                    final String[] split = lastPathSegment.split(":");
                    Uri external = MediaStore.Files.getContentUri("external");
                    final Uri newDataUri = ContentUris.withAppendedId(external, Long.parseLong(split[1]));
                    uris.add(newDataUri);
                    try {
                        final PendingIntent writeRequest = MediaStore.createWriteRequest(AppRuntime.getContext().getContentResolver(), uris);
                        startIntentSenderForResult(writeRequest.getIntentSender(), 1300, null, 0, 0, 0, null);
                    } catch (Exception e2) {
                        LogUtils.w(TAG, "step2: uri=%s e=%s", dataUri, e2.toString());
                        ToastUtils.showToast("step2 : %s", e2.toString());
                    }
                }
            }
        } else if (requestCode == 1300) {
            if (resultCode == RESULT_CANCELED) {
                ToastUtils.showToast("取消了修改文件申请");
            } else {
                ToastUtils.showToast("通过了修改文件申请: %s", data.toString());
            }
        }
    }

    @TestFunction("写文件到/sdcard/appdemo/")
    public void onTest110() {
        final String outCachePath = Environment.getExternalStorageDirectory().getPath() + File.separator + AppConfig.getDirName();
//        final String outCachePath = AppConfig.getCacheFolderPath();
        final boolean result = FileUtils.store("test凯_file\n行test2\n" + System.currentTimeMillis(), outCachePath + "/test_file.txt");
        ToastUtils.showToast("store result: " + result);
    }

    @TestFunction("读/sdcard/appdemo/文件")
    public void onTest111() {
//        final String outCachePath = AppConfig.getCacheFolderPath();
        final String outCachePath = Environment.getExternalStorageDirectory().getPath() + File.separator + AppConfig.getDirName();
        final String str = FileUtils.load(outCachePath + "/test_file.txt");
        ToastUtils.showToast("read str: " + str);
    }

    @TestFunction("读/DCIM/Camera/图片文件(Path法)")
    public void onTest112() {
        final File dcimDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
        String one_photo_path = dcimDir.getPath() + "/Camera/IMG_20210805_154530.jpg";
        File one_photo = new File(one_photo_path);
        String photo_str = FileUtils.load(one_photo_path);
        ToastUtils.showToast("one_photo.exists()=%b size=%s photo_str_len=%d"
                , one_photo.exists(), StringUtils.readableByte(one_photo.length()), photo_str.length());
    }

    @TestFunction("写文件到/sdcard/Documents/(Path法)")
    public void onTest120() {
        File documentDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        final String outCachePath = documentDirectory.getPath() + '/' + AppConfig.getDirName();
        final boolean result = FileUtils.store("test凯_file\n行test2\n" + System.currentTimeMillis(), outCachePath + "/test_file.txt");
        ToastUtils.showToast("store result2: " + result);
    }

    @TestFunction("读/sdcard/Documents/文件(Path法)")
    public void onTest121() {
        File documentDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        final String outCachePath = documentDirectory.getPath() + '/' + AppConfig.getDirName();
        final String str = FileUtils.load(outCachePath + "/test_file.txt");
        ToastUtils.showToast("read str2: " + str);
    }

    @TestFunction("写图片到/sdcard/Documents/(Path法)")
    public void onTest122() {
        try {
            File documentDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            final String jpg_path = documentDirectory.getPath() + '/' + AppConfig.getDirName() + "/i_am_mt.jpg";
            InputStream is = getResources().getAssets().open("i_am_mt.jpg");
            boolean result = FileUtils.store(is, jpg_path);
            ToastUtils.showToast("store jpg: " + result);
        } catch (Exception e) {
            ToastUtils.showToast(e.toString());
        }
    }

    @TestFunction("读/sdcard/Documents/图片(Path法)")
    public void onTest123() {
        try {
            File documentDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            final String jpg_path = documentDirectory.getPath() + '/' + AppConfig.getDirName() + "/i_am_mt.jpg";
            File one_photo = new File(jpg_path);
            String photo_str = FileUtils.load(jpg_path);
            ToastUtils.showToast("jpg.exists()=%b size=%s jpg_path_str_len=%d"
                    , one_photo.exists(), StringUtils.readableByte(one_photo.length()), photo_str.length());
        } catch (Exception e) {
            ToastUtils.showToast(e.toString());
        }
    }


    @TestFunction("写图片到/sdcard/Download/(MediaStore法) API29")
    public void onTest124() throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            final Uri uri = PermissionTestListViewFragment.insertFileIntoDownloads("i_am_mt.jpg", "Download/" + AppConfig.getDirName());
            InputStream is = getResources().getAssets().open("i_am_mt.jpg");
            boolean result = FileUtils.store(is, uri);
            ToastUtils.showToast("store jpg to download: " + result);
        } else {
            ToastUtils.showToast("api版本 %d < 29", Build.VERSION.SDK_INT);
        }
    }

    @TestFunction("读/sdcard/Download/图片(MediaStore法) API29")
    public void onTest125() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            final List<Uri> uris = PermissionTestListViewFragment.getDownloadFile("i_am_mt.jpg", "Download/" + AppConfig.getDirName());
            if (uris.size() > 0) {
                String photo_str = PermissionTestListViewFragment.readUriToString(uris.get(0));
                ToastUtils.showToast("str_len=%d", photo_str.length());
            } else {
                ToastUtils.showToast("未找到合适的uri");
            }
        } else {
            ToastUtils.showToast("api版本 %d < 29", Build.VERSION.SDK_INT);
        }
    }

    @TestFunction("写文件到/sdcard/Document/(MediaStore法) API29")
    public void onTest126() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            final Uri uri = PermissionTestListViewFragment.insertFileIntoDocument("test_text.txt", "Documents/" + AppConfig.getDirName());
            boolean result = FileUtils.store("test time:" + System.currentTimeMillis(), uri);
            ToastUtils.showToast("store text to document: " + result);
        } else {
            ToastUtils.showToast("api版本 %d < 29", Build.VERSION.SDK_INT);
        }
    }

    @TestFunction("读/sdcard/Document/文件(MediaStore法) API29")
    public void onTest128() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            final List<Uri> uris = PermissionTestListViewFragment.getDocumentFile("test_text.txt", "Documents/" + AppConfig.getDirName());
            if (uris.size() > 0) {
                String text_str = PermissionTestListViewFragment.readUriToString(uris.get(0));
                ToastUtils.showToast("str_len=%d : %s", text_str.length(), text_str);
            } else {
                ToastUtils.showToast("未找到合适的uri");
            }
        } else {
            ToastUtils.showToast("api版本 %d < 29", Build.VERSION.SDK_INT);
        }

    }

    @TestFunction("MediaStore get Images")
    public void onTest129() {
        final List<Uri> uris = PermissionTestListViewFragment.getImageIns("test");
        if (uris.size() > 0) {
            String text_str = PermissionTestListViewFragment.readUriToString(uris.get(uris.size() - 1));
            ToastUtils.showToast("image_str_len=%d", text_str.length());
        } else {
            ToastUtils.showToast("未找到合适的uri");
        }

    }

    @TestFunction("存储访问框架--Storage Access Framework (txt)")
    public void onTest130() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            intent.setType("text/plain");
            startActivityForResult(intent, 130);
        } catch (Exception e) {
            ToastUtils.showToast(e.toString());
        }
    }

    @TestFunction("申请相机权限")
    public void onTest230() {
        rxPermissions
                .request(Manifest.permission.CAMERA)
                .subscribe(granted -> {
                    if (granted) {
                        ToastUtils.showToast("request Permission granted.");
                    } else {
                        ToastUtils.showToast("request Permission not granted.");
                    }
                });
    }

    @TestFunction("调用相机Intent")
    public void onTest231() {
        try {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (takePictureIntent.resolveActivity(getContext().getPackageManager()) != null) {
                startActivityForResult(takePictureIntent, 131);
            }
        } catch (Exception e) {
            ToastUtils.showToast(e.toString());
        }
    }

    private Location getLocation() {
        String provider = LocationManager.GPS_PROVIDER;
        LocationManager locationManager = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
        List<String> list = locationManager.getProviders(true);
        if (list.contains(LocationManager.GPS_PROVIDER)) {
            provider = LocationManager.GPS_PROVIDER;//GPS定位
        } else if (list.contains(LocationManager.NETWORK_PROVIDER)) {
            provider = LocationManager.NETWORK_PROVIDER;//网络定位
        }

        if (provider != null) {
            if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                ToastUtils.showToast("精确定位或粗略定位权限均没有");
            } else {
                Location lastKnownLocation = locationManager.getLastKnownLocation(provider);
                if (lastKnownLocation == null) {
                    lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }
                if (lastKnownLocation == null) {
                    lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                }
                ToastUtils.showToast("Location: " + lastKnownLocation);
                return lastKnownLocation;
            }
        } else {
            ToastUtils.showToast("请检查网络或GPS是否打开");
        }
        return null;
    }

    @TestFunction("申请GPS权限")
    public void onTest240() {
        rxPermissions
                .request(Manifest.permission.ACCESS_FINE_LOCATION)
                .subscribe(granted -> {
                    if (granted) {
                        ToastUtils.showToast("request Permission granted.");
                    } else {
                        ToastUtils.showToast("request Permission not granted.");
                    }
                });
    }

    @TestFunction("获取定位信息")
    public void onTest245() {
        getLocation();
    }

    @TestFunction("READ_PHONE_STATE")
    public void onTest250() {
        rxPermissions
                .request(Manifest.permission.READ_PHONE_STATE)
                .subscribe(granted -> {
                    if (granted) {
                        ToastUtils.showToast("request Permission granted.");
                    } else {
                        ToastUtils.showToast("request Permission not granted.");
                    }
                });
    }

    @TestFunction("make a crash")
    public void onTest999() {
        int a = 100;
        int b = 0;
        int c = a / b;
    }


    //这里的fileName指文件名，不包含路径
    //relativePath 包含某个媒体下的子路径
    private static Uri insertFileIntoDownloads(String fileName, String relativePath) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return null;
        }
        ContentResolver resolver = AppRuntime.getContext().getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, "image/*");
        values.put(MediaStore.Downloads.RELATIVE_PATH, relativePath);
        Uri external = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        return resolver.insert(external, values);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private static Uri insertFileIntoDocument(String fileName, String relativePath) {
//        final Set<String> externalVolumeNames = MediaStore.getExternalVolumeNames(AppRuntime.getContext());
        ContentResolver resolver = AppRuntime.getContext().getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Files.FileColumns.DISPLAY_NAME, fileName);
//        values.put(MediaStore.Files.FileColumns.MIME_TYPE, "image/*");
        values.put(MediaStore.Files.FileColumns.RELATIVE_PATH, relativePath);
        Uri external = MediaStore.Files.getContentUri("external");
        return resolver.insert(external, values);
    }

    public static int deleteFile(Uri fileUri) {
        return AppRuntime.getContext().getContentResolver().delete(fileUri, null, null);
    }

    private static String readUriToString(Uri uri) {
        ParcelFileDescriptor parcelFileDescriptor = null;
        FileDescriptor fileDescriptor = null;
        String string = "";
        try {
//            parcelFileDescriptor = AppRuntime.getContext().getContentResolver().openFileDescriptor(uri, "r");
//            if (parcelFileDescriptor != null && parcelFileDescriptor.getFileDescriptor() != null) {
//                fileDescriptor = parcelFileDescriptor.getFileDescriptor();
//                FileInputStream fis = new FileInputStream(fileDescriptor);
//                string = StringUtils.stringFromInputStream(fis);
//            }
            final InputStream fis = AppRuntime.getContext().getContentResolver().openInputStream(uri);
            string = StringUtils.stringFromInputStream(fis);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (parcelFileDescriptor != null) {
                    parcelFileDescriptor.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return string;
    }

    //name是文件名称，是MediaStore查找文件的条件之一
    @SuppressLint("Range")
    @RequiresApi(api = Build.VERSION_CODES.Q)
    public static List<Uri> getDownloadFile(String filename, String relativePath) {

        List<Uri> insList = new ArrayList<>();
        List<String> strList = new ArrayList<>();

        ContentResolver resolver = AppRuntime.getContext().getContentResolver();


        String selection = MediaStore.Downloads.DISPLAY_NAME + " like '" + filename + "%'";
        String selection2 = " and " + MediaStore.Downloads.RELATIVE_PATH + "='" + relativePath + "'";
        selection = null;

        Cursor cursor = resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, null, selection, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            //媒体数据库中查询到的文件id
            int columnId = cursor.getColumnIndex(MediaStore.Downloads._ID);
            do {
                //通过mediaId获取它的uri
                int mediaId = cursor.getInt(columnId);
                Uri itemUri = Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, "" + mediaId);
                insList.add(itemUri);
                strList.add(cursor.getString(cursor.getColumnIndex(MediaStore.Downloads.DISPLAY_NAME)));

            } while (cursor.moveToNext());
        }
        if (cursor != null) {
            cursor.close();
        }
        return insList;

    }

    //name是文件名称，是MediaStore查找文件的条件之一
    @RequiresApi(api = Build.VERSION_CODES.Q)
    @SuppressLint("Range")
    public static List<Uri> getDocumentFile(String filename, String relativePath) {

        List<Uri> insList = new ArrayList<>();
        List<String> strList = new ArrayList<>();
        ContentResolver resolver = AppRuntime.getContext().getContentResolver();

//        String selection = MediaStore.Files.FileColumns.DISPLAY_NAME + " like '" + filename + "%'";
        String selection = MediaStore.Files.FileColumns.DISPLAY_NAME + "='" + filename + "'";
        String selection2 = " and " + MediaStore.Files.FileColumns.RELATIVE_PATH + "='" + relativePath + "'";
        selection = null;

        final Uri external = MediaStore.Files.getContentUri("external");
        Cursor cursor = resolver.query(external, null, selection, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            //媒体数据库中查询到的文件id
            int columnId = cursor.getColumnIndex(MediaStore.Files.FileColumns._ID);
            do {
                //通过mediaId获取它的uri
                int mediaId = cursor.getInt(columnId);
                Uri itemUri = Uri.withAppendedPath(external, "" + mediaId);
                insList.add(itemUri);
                final String displayName = cursor.getString(cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME));
                final String tmpPath = cursor.getString(cursor.getColumnIndex(MediaStore.Files.FileColumns.RELATIVE_PATH));
                strList.add(displayName + "  _  " + tmpPath);
            } while (cursor.moveToNext());
        }
        if (cursor != null) {
            cursor.close();
        }
        return insList;

    }

    //name是文件名称，是MediaStore查找文件的条件之一
    public static List<Uri> getImageIns(String name) {

        List<Uri> insList = new ArrayList<>();
        ContentResolver resolver = AppRuntime.getContext().getContentResolver();
        String sortOrder = MediaStore.Images.Media.DATE_MODIFIED + " DESC";//根据日期降序查询
//        String selection = MediaStore.Images.Media.BUCKET_DISPLAY_NAME + "='" + name + "'";   //查询条件 “显示名称为？”
        String selection = null;

        Cursor cursor = resolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, selection, null, sortOrder);

        if (cursor != null && cursor.moveToFirst()) {
            //媒体数据库中查询到的文件id
            int columnId = cursor.getColumnIndex(MediaStore.Images.Media._ID);

            do {
                int mediaId = cursor.getInt(columnId);
                Uri itemUri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "" + mediaId);
                insList.add(itemUri);

            } while (cursor.moveToNext());
        }
        if (cursor != null) {
            cursor.close();
        }
        return insList;

    }

}
