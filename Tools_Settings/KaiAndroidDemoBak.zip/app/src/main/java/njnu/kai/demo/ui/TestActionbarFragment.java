package njnu.kai.demo.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import njnu.kai.demo.R;
import njnu.kai.demo.test.BaseTestRecyclerViewFragment;
import njnu.kai.demo.test.TestFunction;
import njnu.kai.framework.ActionBarLayoutActivity;
import njnu.kai.uikit.ActionBarLayout;

/**
 * @author kai
 *
 */
public class TestActionbarFragment extends BaseTestRecyclerViewFragment {

    private ActionBarLayout mActionbarLayout;

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mActionbarLayout = getActionbarLayout();
    }

    @TestFunction("切换到文本模式")
    public void onTest01() {
        mActionbarLayout.setMode(ActionBarLayout.MODE_TEXT);
        mActionbarLayout.setTitle("文本模式");
    }

    @TestFunction("切换到图文模式")
    public void onTest02() {
        mActionbarLayout.setMode(ActionBarLayout.MODE_IMAGE_TEXT);
        mActionbarLayout.setTitle("图文模式");
        ImageView leftImageView = (ImageView) mActionbarLayout.findViewById(R.id.iv_left_icon);
        leftImageView.setImageResource(R.drawable.demo_img_login_wechat);
        ImageView rightImageView = (ImageView) mActionbarLayout.findViewById(R.id.iv_right_icon);
        rightImageView.setImageResource(R.drawable.demo_img_login_weibo);
    }

    @TestFunction("切换到搜索模式")
    public void onTest03() {
        mActionbarLayout.setMode(ActionBarLayout.MODE_SEARCH);
        EditText editText = (EditText) mActionbarLayout.getSearchInputLayout().findViewById(R.id.edittext_search_input);
        editText.setText("搜索模式");
    }

    @TestFunction("切换到tab模式")
    public void onTest04() {
        mActionbarLayout.setMode(ActionBarLayout.MODE_TAB);
    }

    private ActionBarLayout getActionbarLayout() {
        return ((ActionBarLayoutActivity) getActivity()).getActionBarLayout();
    }
}
