package njnu.kai.demo.list;

/**
 */
public abstract class StringRecyclerViewAdapter {

//    @Override
//    public StringViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        TextView textView = getTextView(parent.getContext());
//        return new StringViewHolder(textView);
//    }
//
//    @NonNull
//    public static TextView getTextView(Context context) {
//        TextView textView = new TextView(context);
//        textView.setSingleLine();
//        textView.setTextSize(16.f);
//        textView.setTextColor(Color.BLACK);
//        textView.setPadding(DisplayUtils.dp2px(8), DisplayUtils.dp2px(6), DisplayUtils.dp2px(8), DisplayUtils.dp2px(6));
//        return textView;
//    }
//
//    @Override
//    public void onBindViewHolder(StringViewHolder holder, int position) {
//        holder.flushView(getItem(position));
//    }

}
