package njnu.kai.demo.list.bean;


import com.alibaba.fastjson.annotation.JSONField;

import java.util.List;

import njnu.kai.dialog.pickerview.model.IPickerViewData;

/**
 * TODO<json数据源>
 *
 * @author: 小嵩
 * @date: 2017/3/16 15:36
 */

public class ProvinceBean implements IPickerViewData {


    /**
     * name : 省份
     * city : [{"name":"北京市","area":["东城区","西城区","崇文区","宣武区","朝阳区"]}]
     */

    @JSONField(name="name")
    public String name;

    @JSONField(name="city")
    public List<CityBean> cityList;

    public ProvinceBean() {
    }

    public ProvinceBean(String name) {
        this.name = name;
    }

    // 实现 IPickerViewData 接口，
    // 这个用来显示在PickerView上面的字符串，
    // PickerView会通过IPickerViewData获取getPickerViewText方法显示出来。
    @Override
    public String getPickerViewText() {
        return this.name;
    }



    public static class CityBean {
        /**
         * name : 城市
         * area : ["东城区","西城区","崇文区","昌平区"]
         */
        @JSONField(name="name")
        public String name;

        @JSONField(name="area")
        public List<String> areaList;
    }
}
