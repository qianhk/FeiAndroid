package njnu.kai.demo.activity;

import android.content.Intent;
import android.widget.EditText;

import njnu.kai.demo.fragment.TweetTestFragment;
import njnu.kai.framework.search.ISearch;
import njnu.kai.framework.search.WrapFragmentWithSearchbarActivity;

/**
 * @author kai
 *
 */
public class TestSearchbarActivity extends WrapFragmentWithSearchbarActivity {

    @Override
    protected Class wrapFragmentClass() {
        return TweetTestFragment.class;
    }

    @Override
    protected void doSearch(String keyword, String source) {
        ((ISearch)getWrapFragment()).search(String.format("%s - %s", keyword, source), null);
    }

    @Override
    protected void doInitEditText(EditText editText) {
        editText.setHint("占位文字");
        Intent intent = getIntent();
        String keyword = intent.getStringExtra("keyword");
        editText.setText(keyword);
    }
}
