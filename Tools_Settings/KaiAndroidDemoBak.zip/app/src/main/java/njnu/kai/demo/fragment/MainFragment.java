package njnu.kai.demo.fragment;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import njnu.kai.demo.R;
import njnu.kai.demo.list.ComponentTestListViewFragment;
import njnu.kai.demo.list.DialogTestListViewFragment;
import njnu.kai.demo.list.PermissionTestListViewFragment;
import njnu.kai.demo.list.UIFrameworkTestListViewFragment;

import java.util.ArrayList;
import java.util.List;

import njnu.kai.framework.BaseFragment;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public class MainFragment extends BaseFragment {

    private static final String TAG = "MainFragment";

    public static final int INDEX_TREND_TAB = 0;
    public static final int INDEX_HOMEPAGE_TAB = 1;
    private static final int INDEX_MESSAGE_TAB = 2;
    private static final int INDEX_ME_TAB = 3;

    private BaseFragment mFirstFragment;
    private BaseFragment mSecondFragment;
    private BaseFragment mMainTestListViewFragment;
    private BaseFragment mDialogTestFragment;

    private BaseFragment mSelectedFragment;

    private int mNeedSelectItem;

    private View.OnClickListener mOnTabClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int viewId = v.getId();
//            SimpleUser simpleUser = AppPreferences.simpleUser();
//            if (simpleUser == null && (viewId == R.id.layout_message || viewId == R.id.layout_me)) {
//                EntryUtils.openAccountActivity(getActivity());
//                return;
//            }
            FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
            hideFragment(transaction, mFirstFragment);
            hideFragment(transaction, mSecondFragment);
            hideFragment(transaction, mMainTestListViewFragment);
            hideFragment(transaction, mDialogTestFragment);
            showFragment(transaction, getFragmentById(viewId));
            transaction.commitAllowingStateLoss();
            ViewGroup parent = (ViewGroup) v.getParent();
            for (int idx = parent.getChildCount() - 1; idx >= 0; --idx) {
                parent.getChildAt(idx).setSelected(false);
            }
            v.setSelected(true);
        }
    };

    private BaseFragment getFragmentById(int viewId) {
        BaseFragment fragment;
        if (viewId == R.id.layout_test1) {
            fragment = mFirstFragment;
        } else if (viewId == R.id.layout_test2) {
            fragment = mSecondFragment;
        } else if (viewId == R.id.layout_dialog) {
            fragment = mDialogTestFragment;
        } else {
            fragment = mMainTestListViewFragment;
        }
        return fragment;
    }

    private void showFragment(FragmentTransaction transaction, BaseFragment fragment) {
        if (mSelectedFragment != null) {
//            mSelectedFragment.onNewPause();
        }
        transaction.show(fragment);
        mSelectedFragment = fragment;
        if (fragment.getView() != null) {
            fragment.getView().setVisibility(View.VISIBLE);
        }
//        mSelectedFragment.onNewResume();
    }

    private void hideFragment(FragmentTransaction transaction, BaseFragment fragment) {
        if (fragment != null) {
            transaction.hide(fragment);
            if (fragment.getView() != null) {
                fragment.getView().setVisibility(View.GONE);
            }
        }
    }

    private void addAllFragment() {
//        mFirstFragment = TweetTestFragment.instantiate("First");
        mFirstFragment = new PermissionTestListViewFragment();
        mSecondFragment = new ComponentTestListViewFragment();
        mMainTestListViewFragment = new UIFrameworkTestListViewFragment();
        mDialogTestFragment = new DialogTestListViewFragment();
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        transaction.add(R.id.layout_content, mMainTestListViewFragment);
        transaction.add(R.id.layout_content, mDialogTestFragment);
        transaction.add(R.id.layout_content, mFirstFragment);
        transaction.add(R.id.layout_content, mSecondFragment);
        transaction.commitAllowingStateLoss();
    }

    private List<ImageTextViewHolder> mHolderList = new ArrayList<ImageTextViewHolder>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.demo_fragment_main, container, false);
        View groupView = rootView.findViewById(R.id.layout_test1);
        ImageTextViewHolder viewHolder = new ImageTextViewHolder(groupView, mOnTabClickListener);
        viewHolder.flushView("权限", R.drawable.demo_xml_tab_me);
        mHolderList.add(viewHolder);

        groupView = rootView.findViewById(R.id.layout_test2);
        viewHolder = new ImageTextViewHolder(groupView, mOnTabClickListener);
        viewHolder.flushView("组件", R.drawable.demo_xml_tab_me);
        mHolderList.add(viewHolder);

        groupView = rootView.findViewById(R.id.layout_dialog);
        viewHolder = new ImageTextViewHolder(groupView, mOnTabClickListener);
        viewHolder.flushView("对话框", R.drawable.demo_xml_tab_me);
        mHolderList.add(viewHolder);

        groupView = rootView.findViewById(R.id.layout_me);
        viewHolder = new ImageTextViewHolder(groupView, mOnTabClickListener);
        viewHolder.flushView("UI框架", R.drawable.demo_xml_tab_me);
        mHolderList.add(viewHolder);

        addAllFragment();

        mHolderList.get(mNeedSelectItem).performClick();
        mNeedSelectItem = 0;

//        final GuideRecord guideRecord = AppPreferences.guideRecord();
//        if (!guideRecord.isSearchGroup()) {
//            ViewStub viewStub = (ViewStub) rootView.findViewById(R.id.vs_inflate_main);
//            final View inflateView = viewStub.inflate();
//            inflateView.findViewById(R.id.iv_find_more).setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    inflateView.setVisibility(View.GONE);
//                    guideRecord.setSearchGroup();
//                    AppPreferences.saveGuideRecord(guideRecord);
//                }
//            });
//        }
//        EventBus.getDefault().register(this);
        return rootView;
    }

//    private void fetchUserInfoIfNulll(User user) {
////        if (user == null) {
////            DataFetcher.fetch(this, () -> UserApi.userInfo(AppPreferences.simpleUser().getUserId()).execute(), result -> {
////                if (result != null && result.isSuccess() && result.getData() != null) {
////                    AppPreferences.setUserInfo(result.getData());
////                }
////            });
////        }
//    }

//    public void toMessageFragment() {
//        mNeedSelectItem = INDEX_MESSAGE_TAB;
//        if (isViewAccessAble()) {
//            mHolderList.get(mNeedSelectItem).performClick();
//            mNeedSelectItem = 0;
//        }
//    }
//
//    public void toHomepage() {
//        if (isViewAccessAble()) {
//            mHolderList.get(INDEX_HOMEPAGE_TAB).performClick();
//        }
//    }
//
//    public void toTrendPage() {
//        if (isViewAccessAble()) {
//            mHolderList.get(INDEX_TREND_TAB).performClick();
//        }
//    }
//
//    public void toPage(int position) {
//        if (isViewAccessAble()) {
//            mHolderList.get(position).performClick();
//        }
//    }

    @Override
    public void onResume() {
        super.onResume();

//        if (AppPreferences.simpleUser() != null) {
//            TaskScheduler.execute(this, () -> {
//                int unReadCount = chatNewMsgCountInBkg();
//                if (unReadCount <= 0) {
//                    unReadCount = remindNewMsgInBkg();
//                }
//                return unReadCount;
//            }, unreadCount -> {
////                mHolderList.get(INDEX_MESSAGE_TAB).showIndicate(unreadCount > 0);
//            });
//        }
    }

//    private int chatNewMsgCountInBkg() {
//        int unreadCount = 0;
//        try {
//            List<Room> roomList = ConversationManager.getInstance().findAndCacheRooms();
//            for (Room room : roomList) {
//                unreadCount += room.getUnreadCount();
//            }
//        } catch (AVException | InterruptedException | NullPointerException e) {
//            e.printStackTrace();
//        }
//        return unreadCount;
//    }

//    private int remindNewMsgInBkg() {
//        MsgStatusListResult result = MessageApi.status().execute();
//        int unreadCount = 0;
//        if (result != null && result.isSuccess() && result.getInnerDataList() != null) {
//            for (MsgStatus msgStatus : result.getInnerDataList()) {
//                unreadCount += msgStatus.getNotReadCount();
//            }
//            FragmentActivity activity = getActivity();
//            if (activity != null) {
//                final int finalUnreadCount = unreadCount;
//                activity.runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        if (mDialogTestFragment != null) {
//                            mDialogTestFragment.notifyMessageStatusResult(result.getInnerDataList(), finalUnreadCount, true);
//                        }
//                    }
//                });
//            }
//        }
//        return unreadCount;
//    }


    @Override
    protected void onLoadFinished() {
        super.onLoadFinished();
//        ArrayList<GuideData> guideDataList = new ArrayList<>();
//        guideDataList.add(new GuideData(new Rect(100, 100, 200, 200), R.drawable.img_avatar_default, new Point(0, 0)));
//        guideDataList.add(new GuideData(new Rect(200, 300, 260, 360), R.drawable.qq_icon, new Point(20, 20)));
//        new BaseGuideFragment().setData(guideDataList).show(getFragmentManager(), "tag");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
//        EventBus.getDefault().unregister(this);
        mHolderList.clear();
    }

//    @Subscribe
    public void onEvent(Object event) {
//        if (event.mType == EventBusEvent.TYPE_NEW_MESSAGE) {
//            if (event.mBooleanTag) {
//                mHolderList.get(INDEX_MESSAGE_TAB).showIndicate(event.mBooleanTag);
//            } else {
//                TaskScheduler.execute(this, this::remindNewMsgInBkg, unreadCount -> {
//                    mHolderList.get(INDEX_MESSAGE_TAB).showIndicate(unreadCount > 0);
//                });
//            }
//        } else if (event.mType == EventBusEvent.TYPE_NEW_REMIND) {
//            if (event.mBooleanTag) {
//                mHolderList.get(INDEX_MESSAGE_TAB).showIndicate(event.mBooleanTag);
//            } else {
//                TaskScheduler.execute(this, this::chatNewMsgCountInBkg, unreadCount -> {
//                    mHolderList.get(INDEX_MESSAGE_TAB).showIndicate(unreadCount > 0);
//                });
//            }
//        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (mSelectedFragment != null) {
            mSelectedFragment.onActivityResult(requestCode, resultCode, data);
        }
    }

}
