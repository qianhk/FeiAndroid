package njnu.kai.demo.fragment;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import njnu.kai.demo.R;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public final class ImageTextViewHolder {
    private View mRootView;
    private ImageView mIvIcon;
    private ImageView mIvIndicate;
    private TextView mTvTitle;

    public ImageTextViewHolder(View rootView, View.OnClickListener onTabClickListener) {
        mRootView = rootView;
        rootView.setOnClickListener(onTabClickListener);
        rootView.setTag(this);
        mIvIcon = (ImageView) rootView.findViewById(R.id.iv_icon);
        mTvTitle = (TextView) rootView.findViewById(R.id.tv_title);
        mIvIndicate = (ImageView) rootView.findViewById(R.id.view_indicate);
        if (mIvIndicate != null) {
            mIvIndicate.setVisibility(View.GONE);
        }
    }

    public void flushView(int titleResId, int iconResId) {
        flushView(mTvTitle.getResources().getString(titleResId), iconResId);
    }

    public void flushView(String title, int iconResId) {
        mTvTitle.setText(title);
        if (iconResId != 0) {
            mIvIcon.setVisibility(View.VISIBLE);
            mIvIcon.setImageResource(iconResId);
        } else {
            mIvIcon.setVisibility(View.GONE);
        }
    }

    public void flushView(String title) {
        mTvTitle.setText(title);
        mIvIcon.setImageResource(R.drawable.demo_ic_launcher);
    }

    public void showIndicate(boolean show) {
        mIvIndicate.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    public void performClick() {
        mRootView.performClick();
    }
}
