package njnu.kai.demo.list;

import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.google.zxing.client.android.Intents;
import com.google.zxing.integration.android.IntentIntegrator;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import androidx.activity.result.ActivityResultLauncher;
import njnu.kai.demo.emoji.EmojiTestFragment;
import njnu.kai.demo.network.GithubDataFragment;
import njnu.kai.demo.pic.MultiNetImageViewTestFragment;
import njnu.kai.demo.pic.SingleNetImageViewTestFragment;
import njnu.kai.demo.pic.selector.PhotoTestActivity;
import njnu.kai.demo.test.BaseTestRecyclerViewFragment;
import njnu.kai.demo.test.TestFunction;
import njnu.kai.framework.WrapFragmentActivity;
import njnu.kai.framework.WrapFragmentWithActionbarActivity;
import njnu.kai.framework.navigator.Navigator;
import njnu.kai.pic.PictureConstant;
import njnu.kai.share.ShareConstant;
import njnu.kai.share.ShareInfo;
import njnu.kai.share.ShareMainActivity;
import njnu.kai.share.ShareType;
import njnu.kai.utils.StringUtils;
import njnu.kai.utils.ToastUtils;

/**
 * http://dev.umeng.com/social/android/quick-integration
 *
 * @author kai
 */
public class ComponentTestListViewFragment extends BaseTestRecyclerViewFragment {

    @Override
    protected String onGetUIPageName() {
        return "ComponentTest";
    }


    private ShareInfo makeTextShareInfo() {
        ShareInfo shareInfo = new ShareInfo("此乃标题", "此乃正文啊，哈哈", null);
        return shareInfo;
    }

    private ShareInfo makeImageShareInfo() {
        ShareInfo shareInfo = new ShareInfo("此乃标题", "此乃正文啊，哈哈", null);
        shareInfo.setImageUrl("http://am.zdmimg.com/201609/16/57dbf6740e49d.jpg_e600.jpg");
        return shareInfo;
    }

    private ShareInfo makeLinkShareInfo() {
        ShareInfo shareInfo = new ShareInfo("此乃标题", "此乃正文啊，哈哈", "http://3g.cn");
        shareInfo.setImageUrl("http://pic2.nipic.com/20090413/406638_125424003_2.jpg");
        return shareInfo;
    }

    @TestFunction("Share Text: V1 dialog")
    public void onTest100() {
        ShareInfo shareInfo = makeTextShareInfo();
        shareInfo.mUseV1Dialog = true;
        ShareMainActivity.openShareActivity(getBaseActivity(), shareInfo);
    }

    @TestFunction("Share Image")
    public void onTest101() {
        final ShareInfo shareInfo = makeImageShareInfo();
        shareInfo.mUseBottomPopupWindow = true;
        ShareMainActivity.openShareActivity(getBaseActivity(), shareInfo);
    }

    @TestFunction("Share Link")
    public void onTest102() {
        ShareMainActivity.openShareActivity(getBaseActivity(), makeLinkShareInfo());
    }

    @TestFunction("Share Image To Wechat Circle")
    public void onTest106() {
        ShareMainActivity.openShareActivity(getBaseActivity(), makeImageShareInfo(), ShareType.WECHAT_CIRCLE);
    }

    @TestFunction("Share using navigator")
    public void onTest110() {
        Navigator.withPage("share")
                .addParameter(ShareConstant.KEY_TITLE, "此乃标题啊")
                .addParameter(ShareConstant.KEY_MESSAGE, "此乃正文，通过navigator分享")
                .addParameter(ShareConstant.KEY_LINK, "http://baidu.com")
                .addParameter(ShareConstant.KEY_IMAGE, "http://pic2.nipic.com/20090413/406638_125424003_2.jpg")
                .open();
    }

    @TestFunction("Share Image To Wechat Circle using navigator")
    public void onTest111() {
        Navigator.withPage("share")
                .addParameter(ShareConstant.KEY_TITLE, "此乃标题啊")
                .addParameter(ShareConstant.KEY_MESSAGE, "此乃正文，通过navigator分享")
                .addParameter(ShareConstant.KEY_IMAGE, "http://pic2.nipic.com/20090413/406638_125424003_2.jpg")
                .addParameter(ShareConstant.KEY_PLATFORM, ShareConstant.PLATFORM_WECHAT_CIRCLE)
                .open();
    }

    @TestFunction("Emoji Test")
    public void onTest200() {
        WrapFragmentWithActionbarActivity.launch(getBaseActivity(), EmojiTestFragment.class, "测试Emoji");
    }


    @TestFunction("Github Data")
    public void onTest300() {
        WrapFragmentWithActionbarActivity.launch(getBaseActivity(), GithubDataFragment.class, "Github Data");
    }

    @TestFunction("NetImageView multi")
    public void onTest400() {
        WrapFragmentActivity.launch(getBaseActivity(), MultiNetImageViewTestFragment.class);
    }

    @TestFunction("NetImageView single")
    public void onTest401() {
        WrapFragmentActivity.launch(getBaseActivity(), SingleNetImageViewTestFragment.class);
    }

    @TestFunction("picture preview: multi (navigator)")
    public void onTest403() {
        String picUrls[] = new String[]{"https://qny.smzdm.com/202102/25/60379a4b38edd8749.jpg_d200.jpg"
                , "https://qny.smzdm.com/202008/14/5f360a2ea678d8972.jpg_d200.jpg"
                , "https://qny.smzdm.com/202111/08/6188b9eb3410e8378.jpg_d200.jpg"};
        String jsonPicUrls = JSON.toJSONString(picUrls);
        Navigator.withPage("pic_preview")
                .addParameter(PictureConstant.IMG_LIST, jsonPicUrls)
//                .addParameter(PictureConstant.POSITION, 1)
                .addParameter(PictureConstant.SAVE, 0)
                .open();
    }

    @TestFunction("picture preview: single (navigator)")
    public void onTest404() {
        String jsonPicUrls = "[" + StringUtils.join(","
                , "https://y.zdmimg.com/201610/21/5809723dac93f.jpeg_d200.jpg") + "]";
        Navigator.withPage("pic_preview")
                .addParameter(PictureConstant.IMG_LIST, jsonPicUrls)
                .addParameter(PictureConstant.POSITION, 10)
                .open();
    }

    @TestFunction("picture preview: single (navigator) (not array)")
    public void onTest405() {
        Navigator.withPage("pic_preview")
                .addParameter(PictureConstant.IMG_LIST, "http://am.zdmimg.com/201610/02/57efe07a5af2f.jpg_f710.jpg")
                .open();
    }

    @TestFunction("图片、视频、音频选择测试")
    public void onTest500() {
        launchActivity(PhotoTestActivity.class);
    }

    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result -> {
                if (result.getContents() == null) {
                    Intent originalIntent = result.getOriginalIntent();
                    if (originalIntent == null) {
                        Log.d("MainActivity", "Cancelled scan");
                        ToastUtils.showToast("Cancelled");
                    } else if (originalIntent.hasExtra(Intents.Scan.MISSING_CAMERA_PERMISSION)) {
                        ToastUtils.showToast("Cancelled due to missing camera permission");
                    }
                } else {
                    Log.d("MainActivity", "Scanned");
                    ToastUtils.showToast("Scanned: " + result.getContents());
                }
            });

    @TestFunction("二维码扫描(navigator)")
    public void onTest501() {
        Navigator.withPage("scan").open();
    }

    @TestFunction("二维码扫描(navigator_setResult)")
    public void onTest502() {
        Navigator.withPage("scan").addParameter("setResult", true).open();
    }

    @TestFunction("二维码扫描(barcodeLauncher)")
    public void onTest503() {
        final ScanOptions options = new ScanOptions();
        options.setDesiredBarcodeFormats(ScanOptions.QR_CODE);
        barcodeLauncher.launch(options);
    }

    protected void launchActivity(Class clazz) {
        Intent intent = new Intent(getActivity(), clazz);
        getActivity().startActivity(intent);
    }

}
