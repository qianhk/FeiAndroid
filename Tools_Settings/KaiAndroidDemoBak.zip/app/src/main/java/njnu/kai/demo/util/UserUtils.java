package njnu.kai.demo.util;

import android.view.View;

import njnu.kai.utils.DisplayUtils;
import njnu.kai.utils.StringUtils;
import njnu.kai.demo.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created on 2015/1/16.
 */
public class UserUtils {
    /**
     * 号码连接符(连接国家码和号码)
     */
    public static final String REGION_NUMBER_CONNECTOR = "-";
    /**
     * 手机区域码前缀
     */
    public static final String PLUS = "+";
    /**
     * 中国大陆手机号码长度
     */
    public static final int CHINA_MAINLAND_PHONE_NUMBER_LENGTH = 11;

    /**
     * 中国大陆手机号码区域码(不带+)
     */
    public static final String CHINA_MAINLAND_PHONE_REGION_CODE = "86";
    /**
     * 中国大陆手机号码区域码(带+)
     */
    public static final String CHINA_MAINLAND_PHONE_REGION_CODE_WITH_PLUS = PLUS + CHINA_MAINLAND_PHONE_REGION_CODE;

    public static final int CIRCLE_AVATAR_SIZE = DisplayUtils.dp2px(50);


    /**
     * 格式化号码，将"86-13817284186"转换为"+86 13817284186"
     *
     * @param phoneNumber 手机号码
     * @return 格式化后的号码
     */
    public static String formatToPlusPrefix(String phoneNumber) {
        int connectorIdx = phoneNumber.indexOf(REGION_NUMBER_CONNECTOR);
        if (connectorIdx < 0) {
            return phoneNumber;
        }
        String regionCode = phoneNumber.substring(0, connectorIdx);
        String phone = phoneNumber.substring(connectorIdx + 1);
        return PLUS + regionCode + " " + phone;
    }

    /**
     * 将区域码、手机号码合并为格式："86-13817284186"
     *
     * @param regionCode  区域码(如：+86)
     * @param phoneNumber 手机号码(如：13817284186)
     * @return 格式化后的号码
     */
    public static String formatToRegionCodePrefix(String regionCode, String phoneNumber) {
        return regionCode.substring(regionCode.indexOf(PLUS) + 1)
                + UserUtils.REGION_NUMBER_CONNECTOR
                + phoneNumber;
    }

    /**
     * 从含区域码的电话号码中抽取号码部分，如从"86-13817284186"抽取"13817284186"
     *
     * @param regionCodePhoneNumber 含区域码的电话号码
     * @return 电话号码
     */
    public static String extractPhoneNumber(String regionCodePhoneNumber) {
        return regionCodePhoneNumber.substring(regionCodePhoneNumber.indexOf(REGION_NUMBER_CONNECTOR) + 1);
    }

    /**
     * 校验手机号码是否无效
     *
     * @param regionCode      手机号码区域码（如："+86"）
     * @param phoneNumber     手机号码
     * @param phoneNumberView 手机号码显示组件
     * @return true:号码有效，false:号码无效
     */
    public static boolean validatePhoneNumber(String regionCode, String phoneNumber, View phoneNumberView) {
        ValidateUtil.Validator phoneNumberValidator = ValidateUtil.CHINA_MAINLAND_PHONE_NUMBER_VALIDATOR;
        if (!StringUtils.equal(regionCode, CHINA_MAINLAND_PHONE_REGION_CODE_WITH_PLUS)) {
            phoneNumberValidator = ValidateUtil.GLOBAL_PHONE_NUMBER_VALIDATOR;
        }

        return ValidateUtil.validate(phoneNumber, R.string.phone_number_hint_text, R.string.invalid_phone_number,
                phoneNumberView, R.anim.demo_shake, phoneNumberValidator);
    }

    /**
     * 判断字串是否为"86-123"格式号码
     *
     * @param str 字串
     * @return 是否为号码
     */
    public static boolean isGlobalPhoneNumber(String str) {
        Pattern pattern = Pattern.compile("^\\d+-\\d+$");
        Matcher matcher = pattern.matcher(str);
        return matcher.matches();
    }

//    public static void flushSexAgeView(@Nullable User user, @NonNull TextView sexAgeView) {
//        boolean female = user == null || user.getSex() == User.FEMALE;
//        int age = user != null ? user.getAge() : 0;
//        int sexResId = female ? R.drawable.img_icon_sex_female_white : R.drawable.img_icon_sex_male_white;
//        int sexBkgResId = female ? R.drawable.pink_tag_background : R.drawable.blue_tag_background;
//        sexAgeView.setCompoundDrawablesWithIntrinsicBounds(sexResId, 0, 0, 0);
//        sexAgeView.setBackgroundResource(sexBkgResId);
//        sexAgeView.setText(String.valueOf(age));
//        sexAgeView.setTag(R.id.tag_bind_data, user);
//    }
//
//    public static void flushColorSexWithRightDrawable(@Nullable User user, @NonNull TextView sexView) {
//        boolean female = user == null || user.getSex() == User.FEMALE;
//        int sexResId = female ? R.drawable.ic_sex_female : R.drawable.ic_sex_male;
//        sexView.setCompoundDrawablesWithIntrinsicBounds(0, 0, sexResId, 0);
//    }
//
//    public static void flushSexAgeView(@Nullable User user, @NonNull TextView sexView, @NonNull TextView ageView) {
//        boolean female = user == null || user.getSex() == User.FEMALE;
//        int age = user != null ? user.getAge() : 0;
//        int sexResId = female ? R.drawable.img_user_info_female : R.drawable.img_user_info_male;
//        sexView.setCompoundDrawablesWithIntrinsicBounds(0, sexResId, 0, 0);
//        sexView.setText(female ? R.string.female : R.string.male);
//        ageView.setText(String.valueOf(age));
//    }
//
//
//    public static void flushSexAddrView(@Nullable User user, @NonNull TextView sexAddrView) {
//        boolean female = user == null || user.getSex() == User.FEMALE;
//        int sexResId = female ? R.drawable.img_icon_sex_female_white : R.drawable.img_icon_sex_male_white;
//        int sexBkgResId = female ? R.drawable.pink_tag_background : R.drawable.blue_tag_background;
//        sexAddrView.setCompoundDrawablesWithIntrinsicBounds(sexResId, 0, 0, 0);
//        sexAddrView.setBackgroundResource(sexBkgResId);
//        sexAddrView.setText(user != null ? user.getUserCity() : "未知");
//    }
//
//    /**
//     * 设置用户头像、昵称, 绑定user数据到avatarView, 同时如果avatarView是UserAvatarView就设置是否达人的标记
//     *
//     * @param user         user into  nullable
//     * @param avatarView   avatar view non null
//     * @param nicknameView nick name text view  nullable
//     */
//    public static void flushAvatarNickView(@Nullable IUser user, @NonNull ImageView avatarView, @Nullable TextView nicknameView) {
//        if (user != null && !StringUtils.isEmpty(user.getAvatarUrl())) {
//            ImageCacheUtils.requestImage(avatarView, user.getAvatarUrl(), CIRCLE_AVATAR_SIZE, CIRCLE_AVATAR_SIZE, R.drawable.img_avatar_default);
//        } else {
//            avatarView.setImageResource(R.drawable.img_avatar_default);
//        }
//        if (avatarView instanceof UserAvatarView) {
//            UserAvatarView userAvatarView = (UserAvatarView) avatarView;
//            userAvatarView.setVFlagVisible(user != null && user.isGeekUser());
//        }
//        avatarView.setTag(R.id.tag_bind_data, user);
//        if (nicknameView != null) {
//            nicknameView.setText(user != null ? user.getNickname() : null);
//            nicknameView.setTag(R.id.tag_bind_data, user);
//        }
//    }
//
//    public static void flushAttentionView(TextView tvAttention, User user) {
//        Resources resources = tvAttention.getResources();
//        if (user.isFollowed() && user.isFanced()) {
//            tvAttention.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.img_user_info_attention_bothway_gray, 0, 0);
//            tvAttention.setText(R.string.attention_bothway);
//            tvAttention.setTextColor(resources.getColor(R.color.gray_text));
//        } else if (user.isFollowed()) {
//            tvAttention.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.img_user_info_attention_gray, 0, 0);
//            tvAttention.setText(R.string.attentioned);
//            tvAttention.setTextColor(resources.getColor(R.color.gray_text));
//        } else {
//            tvAttention.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.img_user_info_attention_orange, 0, 0);
//            tvAttention.setTextColor(resources.getColor(R.color.orange));
//            tvAttention.setText(R.string.attention);
//        }
//    }
//
//    public static void flushAttentionTextView3(TextView tvAttention, User user) {
//        if (AppPreferences.isSelf(user.getUserId())) {
//            tvAttention.setVisibility(View.INVISIBLE);
//        } else {
//            tvAttention.setVisibility(View.VISIBLE);
//            if (user.isFollowed() && user.isFanced()) {
//                tvAttention.setText(R.string.attention_bothway);
//                tvAttention.setBackgroundResource(R.drawable.xml_bkg_round_lightest_gray);
//            } else if (user.isFollowed()) {
//                tvAttention.setText(R.string.attentioned);
//                tvAttention.setBackgroundResource(R.drawable.xml_bkg_round_lightest_gray);
//            } else {
//                tvAttention.setBackgroundResource(R.drawable.xml_bkg_round_orange);
//                tvAttention.setText(R.string.attention);
//            }
//        }
//    }
//
//    public static void flushAttentionTextViewOnlyShowAttention(TextView tvAttention, User user) {
//        if (AppPreferences.isSelf(user.getUserId())) {
//            tvAttention.setVisibility(View.INVISIBLE);
//        } else {
//            if (user.isFollowed()) {
//                tvAttention.setVisibility(View.INVISIBLE);
//            } else {
//                tvAttention.setBackgroundResource(R.drawable.xml_bkg_round_orange);
//                tvAttention.setVisibility(View.VISIBLE);
//                tvAttention.setText(R.string.attention);
//            }
//        }
//    }
//
//    public static void flushAttentionTextViewWithHuXiangIcon(TextView tvAttention, User user, int huxinagIcon) {
//        if (AppPreferences.isSelf(user.getUserId())) {
//            tvAttention.setVisibility(View.INVISIBLE);
//        } else {
//            tvAttention.setVisibility(View.VISIBLE);
//            if (user.isFollowed() && user.isFanced()) {
//                tvAttention.setText(R.string.attention_bothway);
//                tvAttention.setBackgroundResource(R.drawable.xml_bkg_round_lightest_gray);
//                tvAttention.setCompoundDrawablesWithIntrinsicBounds(huxinagIcon, 0, 0, 0);
//            } else if (user.isFollowed()) {
//                tvAttention.setText(R.string.attentioned);
//                tvAttention.setBackgroundResource(R.drawable.xml_bkg_round_lightest_gray);
//                tvAttention.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
//            } else {
//                tvAttention.setBackgroundResource(R.drawable.xml_bkg_round_orange);
//                tvAttention.setText(R.string.attention);
//                tvAttention.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
//            }
//        }
//    }
//
//    public static void flushAttentionTextView2(TextView tvAttention, User user) {
//        if (AppPreferences.isSelf(user.getUserId())) {
//            tvAttention.setVisibility(View.INVISIBLE);
//        } else {
//            tvAttention.setVisibility(View.VISIBLE);
//            if (user.isFollowed()) {
//                tvAttention.setText(R.string.attentioned);
//                tvAttention.setBackgroundResource(R.drawable.xml_bkg_round_lightest_gray);
//            } else {
//                tvAttention.setBackgroundResource(R.drawable.xml_bkg_round_orange);
//                tvAttention.setText(R.string.attention);
//            }
//        }
//    }
//
//    public static void flushTeamUser(List<UserAvatarView> avatarList, List<User> joinedUser, long leaderId) {
//        flushTeamUser(avatarList, joinedUser, leaderId, 0, true, true);
//    }
//
//    public static void flushSmallTeamUser(List<UserAvatarView> avatarList, List<User> joinedUser) {
//        flushTeamUser(avatarList, joinedUser, 0, 0, true, true);
//    }
//
//    public static void flushTeamUser(List<UserAvatarView> avatarList, List<User> joinedUser, long leaderId, int defaultAvatarResId
//            , boolean goneWhenNoEnoughData, boolean needVFlag) {
//        int size = joinedUser != null ? joinedUser.size() : 0;
//        UserAvatarView userAvatarView;
//        for (int idx = 0; idx < avatarList.size(); ++idx) {
//            userAvatarView = avatarList.get(idx);
//            userAvatarView.setVisibility(View.VISIBLE);
//            if (idx < size) {
//                User user = joinedUser.get(idx);
//                GroupIntroAdapter.flushAvatarView(userAvatarView, user, leaderId);
//                if (!needVFlag) {
//                    userAvatarView.setVFlagVisible(false);
//                }
//            } else {
//                userAvatarView.setTag(R.id.tag_bind_data, null);
//                if (defaultAvatarResId == 0) {
//                    userAvatarView.setImageDrawable(null);
//                    userAvatarView.setVisibility(goneWhenNoEnoughData ? View.GONE : View.INVISIBLE);
//                } else {
//                    userAvatarView.setImageResource(defaultAvatarResId);
//                }
//            }
//        }
//    }
}
