package njnu.kai.demo.util;

/**
 * @author kai
 * @version 1.0.0
 * @since 15/2/21
 */
public class DistanceUtils {

    public static String readableDistance(int distance) {
        float distanceF = distance / 1000.0f;
        return String.format("%.2fKM", distanceF);
    }

    public static double funRad(double d) {
        return d * Math.PI / 180.0;
    }

    public static double funGetDistance(double lng1, double lat1, double lng2, double lat2) {
        double d_EarthRadius = 6378.137;
        double radLat1 = funRad(lat1);
        double radLat2 = funRad(lat2);
        double radLat = radLat1 - radLat2;
        double radLng = funRad(lng1) - funRad(lng2);
        double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(radLat / 2), 2) +
                Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(radLng / 2), 2)));
        s = s * d_EarthRadius;
        s = Math.round(s * 10000) / 10;
        return s;
    }

    public static String readableDistance(double lng1, double lat1, double lng2, double lat2) {
        double distance = funGetDistance(lng1, lat1, lng2, lat2);
        return readableDistance((int) distance);
    }
}
