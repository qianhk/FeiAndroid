package njnu.kai.demo.list;

import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

import me.drakeet.multitype.IPagingListAdapter;
import njnu.kai.framework.paging.PagingListPresenter;
import njnu.kai.framework.paging.PagingRecyclerViewFragment;
import njnu.kai.multitype.vo.TextVO;

/**
 * @author kai
 *
 */
public class MultiTypeListNoFlushFragment extends PagingRecyclerViewFragment {
    @Override
    protected PagingListPresenter onCreatePresenter() {
        return null;
    }

    @Override
    protected IPagingListAdapter onCreateAdapter() {
        return makeGlobalMultiTypeAdapter();
    }

    @Override
    protected boolean needPtrAndLoadNextFeature() {
        return false;
    }

    @Override
    protected boolean enterAutoLoading() {
        return false;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ArrayList<TextVO> textVOList = DataMaker.mockTextVoDataWithRandomLength(1, 4);
        flushData(textVOList);
    }
}
