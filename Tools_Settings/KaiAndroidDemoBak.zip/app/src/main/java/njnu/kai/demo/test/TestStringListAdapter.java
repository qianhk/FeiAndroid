package njnu.kai.demo.test;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import njnu.kai.demo.list.StringRecyclerViewHolder;

import njnu.kai.framework.R;
import njnu.kai.framework.paging.adapter.PagingListAdapter;
import njnu.kai.utils.DisplayUtils;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public class TestStringListAdapter extends PagingListAdapter<Object> {

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            TextView textView = new TextView(parent.getContext());
            textView.setPadding(DisplayUtils.dp2px(16), DisplayUtils.dp2px(8), DisplayUtils.dp2px(16), DisplayUtils.dp2px(8));
            textView.setTag(R.id.tag_view_holder, new StringRecyclerViewHolder(textView));
            convertView = textView;
        }
        StringRecyclerViewHolder holder = (StringRecyclerViewHolder) convertView.getTag(R.id.tag_view_holder);
        holder.setText(getItem(position));
        return convertView;
    }


}
