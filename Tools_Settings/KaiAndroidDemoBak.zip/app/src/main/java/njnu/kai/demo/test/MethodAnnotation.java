package njnu.kai.demo.test;

import java.lang.reflect.Method;

import me.drakeet.multitype.BaseVO;
import njnu.kai.utils.LogUtils;

/**
 * @author kai
 *
 */
public class MethodAnnotation extends BaseVO {
    private static final String TAG = "MethodAnnotation";
    private Method mMethod;
    private String mAnnotation;

    public MethodAnnotation(Method method, String annotation) {
        this.mMethod = method;
        this.mAnnotation = annotation;
    }

    public void setAnnotation(String annotation) {
        mAnnotation = annotation;
    }

    public String toString() {
        return this.mAnnotation;
    }

    public void invokeMethod(Object receiver) {
        try {
            this.mMethod.setAccessible(true);
            Class<?>[] parameterTypes = mMethod.getParameterTypes();
            if (parameterTypes.length == 0) {
                this.mMethod.invoke(receiver);
            } else {
                this.mMethod.invoke(receiver, this);
            }
        } catch (Exception var3) {
            LogUtils.e(TAG, "invoke method exception: ", var3);
            var3.printStackTrace();
            throw new Error(var3);
        }

    }
}
