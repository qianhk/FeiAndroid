package njnu.kai.demo.list;

import java.util.ArrayList;
import java.util.Random;

import njnu.kai.multitype.vo.TextVO;

/**
 * @author kai
 *
 */
public final class DataMaker {

    public static ArrayList<String> mockData(int index, int count) {
        final ArrayList<String> strings = new ArrayList<>();
        for (int idx = 0; idx < count; ++idx) {
            strings.add(String.format("mock string index=%d idx=%d", index, idx + 1));
        }
        return strings;
    }

    public static ArrayList<TextVO> mockTextVoData(int index, int count) {
        final ArrayList<TextVO> strings = new ArrayList<>();
        for (int idx = 0; idx < count; ++idx) {
            TextVO vo = new TextVO();
            vo.mText = String.format("mock string index=%d idx=%d", index, idx + 1);
            strings.add(vo);
        }
        return strings;
    }

    public static ArrayList<TextVO> mockTextVoDataWithRandomLength(int index, int count) {
        final ArrayList<TextVO> strings = new ArrayList<>();
        Random random = new Random(System.currentTimeMillis());
        StringBuilder builder = new StringBuilder();
        for (int idx = 0; idx < count; ++idx) {
            builder.setLength(0);
            builder.append(String.format("mock string index=%d idx=%d", index, idx + 1));
            for (int j = random.nextInt(32); j >= 0; --j) {
                builder.append(" _");
            }
            builder.append(" over");
            TextVO itemVO = new TextVO();
            itemVO.mText = builder.toString();
            itemVO.mMaxLine = 0;
            strings.add(itemVO);
        }
        return strings;
    }

}
