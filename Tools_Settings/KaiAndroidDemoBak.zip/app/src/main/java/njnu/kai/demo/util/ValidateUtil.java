package njnu.kai.demo.util;

import android.text.TextUtils;
import android.view.View;
import android.view.animation.AnimationUtils;

import njnu.kai.utils.StringUtils;
import njnu.kai.utils.ToastUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 校验用户名或密码的工具类
 *
 */
public class ValidateUtil {
    private static final int MIN_PASSWORD_LENGTH = 6;
    private static final int MAX_PASSWORD_LENGTH = 20;
    private static final int MIN_NICK_NAME_LENGTH = 1;
    private static final int MAX_NICK_NAME_LENGTH = 30;

    /**
     * 注册用户名Validator
     */
    public static final Validator USERNAME_VALIDATOR = new Validator() {
        @Override
        public boolean validate(String username) {
            return StringUtils.isEmailFormat(username);
        }
    };

    /**
     * 登录用户名Validator，允许@符号前是.的帐号，兼容一些早期注册的用户
     */
    public static final Validator LOGIN_USERNAME_VALIDATOR = new Validator() {
        @Override
        public boolean validate(String username) {
            return !StringUtils.isEmpty(username);
        }
    };

    /**
     * 非中国大陆手机号码校验Validator，仅校验是否为数字
     */
    public static final Validator GLOBAL_PHONE_NUMBER_VALIDATOR = new Validator() {
        @Override
        public boolean validate(String phoneNumber) {
            return TextUtils.isDigitsOnly(phoneNumber);
        }
    };

    /**
     * 中国大陆手机号码校验Validator，由于中国区号码段不固定，只检测是否为11位数字
     */
    public static final Validator CHINA_MAINLAND_PHONE_NUMBER_VALIDATOR = new Validator() {
        @Override
        public boolean validate(String phoneNumber) {
            return TextUtils.isDigitsOnly(phoneNumber)
                    && phoneNumber.length() == UserUtils.CHINA_MAINLAND_PHONE_NUMBER_LENGTH;
        }
    };

    /**
     * NickName Validator
     */
    public static final Validator NICKNAME_VALIDATOR = new Validator() {
        @Override
        public boolean validate(String nickName) {
            Pattern mNickNamePattern = Pattern.compile("[=<>!'@\"*?]");
            Matcher matcher = mNickNamePattern.matcher(nickName);
            if (matcher.find()) {
                return false;
            }
            int len = 0;
            for (int idx = nickName.length() - 1; idx >= 0; --idx) {
                char c = nickName.charAt(idx);
                len += (StringUtils.isLetterOrDigit(c) || c == ' ' || c == '-' || c == '_') ? 1 : 2;
            }
            return len >= MIN_NICK_NAME_LENGTH && len <= MAX_NICK_NAME_LENGTH;
        }
    };

    /**
     * 密码Validator
     */
    public static final Validator PASSWORD_VALIDATOR = new Validator() {
        @Override
        public boolean validate(String password) {
            return StringUtils.lengthInRange(password, MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH);
        }
    };

    /**
     * 校验输入是否合法,并以Toast和动画提示
     *
     * @param input     用户名(Email)
     * @param emptyId   用户名为空时的提示信息
     * @param invalidId 用户名非法时的提示信息
     * @param view      View
     * @param animId    动画id
     * @param validator 校验器
     * @return true 用户名有效; false 用户名非法
     */
    public static boolean validate(String input, int emptyId, int invalidId,
                                   View view, int animId, Validator validator) {
        if (validator == null) {
            return true;
        }

        if (StringUtils.isEmpty(input)) {
            startAnim(view, animId);
            ToastUtils.showToast(emptyId);
            return false;
        }

        if (!validator.validate(input)) {
            startAnim(view, animId);
            ToastUtils.showToast(invalidId);
            return false;
        }
        return true;
    }

    private static void startAnim(View view, int animId) {
        if (view != null) {
            view.requestFocus();
            view.startAnimation(AnimationUtils.loadAnimation(view.getContext(), animId));
        }
    }

    /**
     * 校验器
     */
    public static interface Validator {
        /**
         * validate
         *
         * @param str 待校验字串
         * @return 校验结果, true:校验通过, false:校验失败
         */
        public boolean validate(String str);
    }
}
