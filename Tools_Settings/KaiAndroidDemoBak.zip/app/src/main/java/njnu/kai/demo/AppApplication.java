package njnu.kai.demo;


import android.content.Context;
import androidx.multidex.MultiDex;

import com.baidu.mapapi.SDKInitializer;

import njnu.kai.demo.component.ThisAppConfig;
import njnu.kai.framework.BaseApplication;
import njnu.kai.utils.DebugUtils;

/**
 * @author kai
 * @version 1.0.0
 */
public class AppApplication extends BaseApplication {

    private static final String TAG = "AppApplication";

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(base);
    }

//    @Override
//    protected void onAppCreatedNotMainNim() {
//    }

    @Override
    protected void onAppCreated() {
//        try {
//            SDKInitializer.initialize(getApplicationContext());
//        } catch (UnsatisfiedLinkError e) {
//            //目前百度地图只支持armeabi机器，尚不支持x86机型
//            DebugUtils.doNothing();
//        }
//        FacebookSdk.sdkInitialize(this.getApplicationContext());
//        AVOSCloud.initialize(this, ShareConstant.LEANCLOUD_APP_ID, ShareConstant.LEANCLOUD_APP_KEY);
//        AVOSCloud.setDebugLogEnabled(AppRuntime.Config.isTestMode());
//        Logger.level = BuildConfig.DEBUG ? Logger.VERBOSE : Logger.ERROR;
//
//        AppEventsLogger.activateApp(getApplicationContext());
//
//        try {
//            AVIMMessageManager.registerAVIMMessageType(AVIMShareMessage.class);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        ChatManager chatManager = ChatManager.getInstance();
//        chatManager.init(this);
//        SimpleUser simpleUser = AppPreferences.simpleUser();
//        if (simpleUser != null) {
//            chatManager.openClientWithSelfIdIfNeed(simpleUser.getClientId(), null);
//        }
//        chatManager.setConversationEventHandler(ConversationManager.getConversationHandler());
//        chatManager.setUserInfoFactory(new UserInfoFactory() {
//
//            @Override
//            public User getUserInfoById(String userId) {
//                return CacheService.lookupUser(userId);
//            }
//
//            @Override
//            public void cacheUserInfoByIdsInBackground(List<String> userIds) throws Exception {
//                CacheService.cacheUsers(userIds);
//            }
//
//            @Override
//            public boolean showNotificationWhenNewMessageCome(String selfId) {
//                return true;
//            }
//
//            @Override
//            public void configureNotification(Notification notification) {
//                notification.defaults = Notification.DEFAULT_ALL;
//            }
//        });
//
//        LoginInfo loginInfo = NimUtils.loginInfo();
//        NIMClient.init(this, loginInfo, options());
//
        ThisAppConfig.init(this);
        MultiTypeInstaller.start();
////        BasePublishActivity.sShowInfoView = BuildConfig.DEBUG;
//        LogUtils.i(TAG, "look ByteOrder: " + ByteOrder.nativeOrder());
//
//        new NimApplication().onCreate(this, loginInfo);

//        if (LeakCanary.isInAnalyzerProcess(this)) {
//            return; //我的baseapplication已经保证了此处只会是主进程
//        }
//        LeakCanary.install(this);
    }

    @Override
    protected String logPrefix() {
        return "AppDemo";
    }


}
