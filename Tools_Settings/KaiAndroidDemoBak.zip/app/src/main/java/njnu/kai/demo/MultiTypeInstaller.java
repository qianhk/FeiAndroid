package njnu.kai.demo;


import njnu.kai.multitype.provider.ActivityIntroProvider;
import njnu.kai.multitype.provider.BannerImageProvider;
import njnu.kai.multitype.provider.ButtonProvider;
import njnu.kai.multitype.provider.ChoosePayMethodProvider;
import njnu.kai.multitype.provider.DividerProvider;
import njnu.kai.multitype.provider.GapProvider;
import njnu.kai.multitype.provider.GeekUserIntroProvider;
import njnu.kai.multitype.provider.IconTitleSubtitleMoreProvider;
import njnu.kai.multitype.provider.ImageProvider;
import njnu.kai.multitype.provider.LabelEditInputProvider;
import njnu.kai.multitype.provider.LabelNumberMinusPlusInputProvider;
import njnu.kai.multitype.provider.LeftRightTextProvider;
import njnu.kai.multitype.provider.TextProvider;
import njnu.kai.multitype.provider.TextTagsProvider;
import njnu.kai.multitype.vo.ActivityIntroVO;
import njnu.kai.multitype.vo.BannerImageVO;
import njnu.kai.multitype.vo.ButtonVO;
import njnu.kai.multitype.vo.ChoosePayMethodVO;
import njnu.kai.multitype.vo.DividerVO;
import njnu.kai.multitype.vo.GapVO;
import njnu.kai.multitype.vo.GeekUserIntroVO;
import njnu.kai.multitype.vo.IconTitleSubtitleMoreVO;
import njnu.kai.multitype.vo.ImageVO;
import njnu.kai.multitype.vo.LabelEditInputVO;
import njnu.kai.multitype.vo.LabelNumberMinusPlusInputVO;
import njnu.kai.multitype.vo.LeftRightTextVO;
import njnu.kai.multitype.vo.TextTagsVO;
import njnu.kai.multitype.vo.TextVO;

import me.drakeet.multitype.GlobalMultiTypePool;

public final class MultiTypeInstaller {

    public static void start() {
        GlobalMultiTypePool.register(IconTitleSubtitleMoreVO.class, new IconTitleSubtitleMoreProvider());
        GlobalMultiTypePool.register(GapVO.class, new GapProvider());
        GlobalMultiTypePool.register(DividerVO.class, new DividerProvider());
        GlobalMultiTypePool.register(TextVO.class, new TextProvider());
        GlobalMultiTypePool.register(ImageVO.class, new ImageProvider());
        GlobalMultiTypePool.register(ButtonVO.class, new ButtonProvider());
        GlobalMultiTypePool.register(GeekUserIntroVO.class, new GeekUserIntroProvider());
        GlobalMultiTypePool.register(BannerImageVO.class, new BannerImageProvider());
        GlobalMultiTypePool.register(LeftRightTextVO.class, new LeftRightTextProvider());
        GlobalMultiTypePool.register(LabelEditInputVO.class, new LabelEditInputProvider());
        GlobalMultiTypePool.register(TextTagsVO.class, new TextTagsProvider());
        GlobalMultiTypePool.register(ChoosePayMethodVO.class, new ChoosePayMethodProvider());
        GlobalMultiTypePool.register(LabelNumberMinusPlusInputVO.class, new LabelNumberMinusPlusInputProvider());
        GlobalMultiTypePool.register(ActivityIntroVO.class, new ActivityIntroProvider());
    }
}
