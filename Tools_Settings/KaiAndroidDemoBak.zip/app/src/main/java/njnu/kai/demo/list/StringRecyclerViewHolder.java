package njnu.kai.demo.list;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

/**
 * @author kai
 *
 */
public class StringRecyclerViewHolder extends RecyclerView.ViewHolder {

    private TextView mTvText;

    public StringRecyclerViewHolder(View itemView) {
        super(itemView);
        mTvText = (TextView) itemView;
    }

    public void setText(Object text) {
        mTvText.setText(text.toString());
    }
}
