package njnu.kai.framework.navigator;

import android.os.Bundle;
import androidx.collection.ArrayMap;

import java.util.Map;
import java.util.Set;

public class BundleParameter implements IParameter {

    private static final String TAG = "BundleParameter";
    private Bundle mBundle;

    private BundleParameter(Bundle bundle) {
        mBundle = bundle;
    }

    public static BundleParameter from(Bundle bundle) {
        assert bundle != null;
        return new BundleParameter(bundle);
    }

    @Override
    public int getInt(String key) {
        try {
            return Integer.parseInt(mBundle.getString(key));
        } catch (Exception e) {
            try {
                return mBundle.getInt(key, 0);
            } catch (Exception e1) {
            }
            return 0;
        }
    }

    public int getInt(String key, int defaultValue) {
        try {
            return Integer.parseInt(mBundle.getString(key));
        } catch (Exception e) {
            try {
                return mBundle.getInt(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }

    @Override
    public long getLong(String key) {
        try {
            return Long.parseLong(mBundle.getString(key));
        } catch (Exception e) {
            try {
                return mBundle.getLong(key, 0);
            } catch (Exception e1) {
            }
            return 0;
        }
    }

    public long getLong(String key, long defaultValue) {
        try {
            return Long.parseLong(mBundle.getString(key));
        } catch (Exception e) {
            try {
                return mBundle.getLong(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }


    public float getFloat(String key, float defaultValue) {
        try {
            return Float.parseFloat(mBundle.getString(key));
        } catch (Exception e) {
            try {
                return mBundle.getFloat(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }


    public double getDouble(String key, double defaultValue) {
        try {
            return Double.parseDouble(mBundle.getString(key));
        } catch (Exception e) {
            try {
                return mBundle.getDouble(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        try {
            return Boolean.parseBoolean(mBundle.getString(key));
        } catch (Exception e) {
            try {
                return mBundle.getBoolean(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }

    @Override
    public String getString(String key, String defaultValue) {
        try {
            return mBundle.getString(key, defaultValue);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    @Override
    public Map<String, String> getParameters() {
        try {
            Set<String> keys = mBundle.keySet();
            Map<String, String> parameterMap = new ArrayMap<>(keys.size());
            for (String key : keys) {
                parameterMap.put(key, getString(key, ""));
            }
            return parameterMap;
        } catch (Exception e) {
            return new ArrayMap<>();
        }
    }

}
