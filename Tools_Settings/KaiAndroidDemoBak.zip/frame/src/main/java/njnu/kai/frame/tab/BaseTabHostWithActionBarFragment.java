package njnu.kai.framework.tab;

import android.os.Bundle;
import androidx.viewpager.widget.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import njnu.kai.framework.R;
import njnu.kai.framework.BaseFragment;
import njnu.kai.uikit.FreezableViewPager;
import njnu.kai.framework.ActionBarLayoutFragment;
import njnu.kai.uikit.tab.BaseFragmentTabHost;
import njnu.kai.uikit.tab.LocalFragmentTabAdapter;
import njnu.kai.uikit.tab.LocalTabViewProperties;

import java.util.ArrayList;
import java.util.List;

/**
 * @author kai
 * @version 1.0.0
 *          多tab页fragment,可以通过滑动切换，带顶部标题栏
 */
public abstract class BaseTabHostWithActionBarFragment extends ActionBarLayoutFragment implements ViewPager.OnPageChangeListener {
    /**
     * 标题容器控件
     */
    protected BaseFragmentTabHost mTabHost;
    /**
     * 页面内容容器控件
     */
    protected FreezableViewPager mViewPager;
    /**
     * 页面适配器
     */
    protected LocalFragmentTabAdapter mTabAdapter;

    @Override
    public final View onCreateContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.common_fragment_tab_host, container, false);
        mTabHost = (BaseFragmentTabHost) view.findViewById(R.id.tabhost);
        mViewPager = (FreezableViewPager) view.findViewById(R.id.viewpager);
        mTabAdapter = new LocalFragmentTabAdapter(getChildFragmentManager(), buildTabFragmentProperties());

        mViewPager.setAdapter(mTabAdapter);
        mTabHost.setTabLayoutAverageSpace(true);
        mTabHost.setViewPager(mViewPager, mTabAdapter);
        mViewPager.setOffscreenPageLimit(mTabAdapter.getCount());

        mTabHost.setOnPageChangeListener(this);
        setCurrentPosition(0);
        return view;
    }

    private List<LocalTabViewProperties> buildTabFragmentProperties() {
        List<LocalTabViewProperties> tabViewPropertyList = new ArrayList<>();
        onBuildTabFragmentProperties(tabViewPropertyList);
        return tabViewPropertyList;
    }

    /**
     * 重载此方法构建需要显示的fragment页绑定器列表
     *
     * @param tabViewPropertyList fragment页绑定器列表
     */
    protected abstract void onBuildTabFragmentProperties(List<LocalTabViewProperties> tabViewPropertyList);

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        setCurrentPosition(position);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    private boolean isSlidingAtTheLeftEdge(int position) {
        return position == 0;
    }

    private boolean isSlidingAtTheRightEdge(int position) {
        return position == mTabAdapter.getCount() - 1;
    }

    private void setCurrentPosition(int position) {
//        int slidingMode = SlidingClosableRelativeLayout.SLIDING_CLOSE_MODE_NONE;
//        if (isSlidingAtTheLeftEdge(position)) {
//            slidingMode = SlidingClosableRelativeLayout.SLIDING_CLOSE_MODE_HORIZONTAL_RIGHT;
//        } else if (isSlidingAtTheRightEdge(position)) {
//            slidingMode = SlidingClosableRelativeLayout.SLIDING_CLOSE_MODE_HORIZONTAL_LEFT;
//        }
//
    }

    /**
     * @return current fragment
     */
    public BaseFragment currentFragment() {
        int currentItem = mViewPager.getCurrentItem();
        return (BaseFragment) mTabAdapter.getItem(currentItem);
    }

    public BaseFragment getFragment(int index) {
        return (BaseFragment) mTabAdapter.getItem(index);
    }

}
