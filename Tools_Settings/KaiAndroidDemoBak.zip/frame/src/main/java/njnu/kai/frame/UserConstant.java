package njnu.kai.framework;

/**
 * Created on 2015/1/14.
 * 用户系统常量
 *
 * @version 7.8.0
 */
public interface UserConstant {

    /**
     * 用户名(手机/邮箱)
     */
    String EXTRA_USERNAME = "username";

    /**
     * 退出是否可见
     */
    String EXTRA_LOGOUT_VISIBLE = "logout_visible";

    /**
     * 请求修改封面
     */
    int REQUEST_MODIFY_COVER = 1;

    /**
     * 请求修改头像
     */
    int REQUEST_MODIFY_AVATAR = 2;

    /**
     * 默认起始年份
     */
    int DEFAULT_START_YEAR = 1900;

    /**
     * 默认结束年份
     */
    int DEFAULT_END_YEAR = 2100;

    /**
     * 最大月份
     */
    int MAX_MONTH = 12;

    /**
     * 最大天数
     */
    int MAX_MONTH_DATA = 31;

    /**
     * 手机区域码选择返回的结果tag
     */
    String TAG_PHONE_REGION_CODE_RESULT = "region_code_result";
    /**
     * 邮箱
     */
    String MAIL = "邮箱";
    /**
     * 手机
     */
    String PHONE = "手机";

    /**
     * 标识是手机或邮箱的key
     */
    String KEY_WAY = "way";
    /**
     * 性别字段
     */
    String FIELD_SEX = "sex";
    /**
     * 地区
     */
    String FIELD_LOCATION = "location";
    /**
     * 图片
     */
    String FIELD_PICTURE = "picture";
    /**
     * 拍一张
     */
    String FIELD_CAMERA = "camera";

    public static final int AVATAR_IMAGE_SIZE = 400;

    public static final String ACTION_LOGIN_SUCCESS = "com.xx.android.xxx.login_success";

    String KEY_USER_ID = "uid";
    String KEY_USER_INFO = "key_user_info";
    String KEY_AVATAR_URL = "key_avatar_url";
    String KEY_NICK_NAME = "key_nickname";
    String KEY_SEX = "key_sex";
    String KEY_CITY = "key_city";
    String KEY_PHONE = "key_phone";
    String KEY_PW = "key_pw";
    String KEY_SMS_CODE = "key_smscode";
    String KEY_BIRTHDAY = "key_birthday";
    String KEY_LOOK_ATTENTION = "key_look_attention";
    String KEY_COUNTRY_CODE = "key_country_code";
    String KEY_COUNTRY_NAME = "key_country_name";

    int GOGO_GUEST_ID = 1643;
}
