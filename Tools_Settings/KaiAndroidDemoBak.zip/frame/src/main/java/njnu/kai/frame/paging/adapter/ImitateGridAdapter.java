package njnu.kai.framework.paging.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import njnu.kai.utils.DisplayUtils;
import njnu.kai.framework.R;

import java.util.ArrayList;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public final class ImitateGridAdapter<T> extends PagingListAdapter<T> {

    private final int mColumnNumber;
    private int mGridPicSize;

    private ImitateGridListener mImitateGridListener;

    public ImitateGridAdapter(ImitateGridListener<T> imitateGridListener) {
        mImitateGridListener = imitateGridListener;
        mColumnNumber = mImitateGridListener.gridColumnNumber();
        mGridPicSize = DisplayUtils.getWidthPixels() / mColumnNumber;
    }

    protected int rowViewLayoutId() {
        return R.layout.common_imitate_grid_row;
    }

    public interface ImitateGridListener<T> {

        int gridColumnNumber();

        int horizontalMargin();

        void onGridItemClicked(T itemData);

        ItemViewHolder onCreateGridItemViewHolder();

        void configRowView(View rowView);
    }

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Object tagViewHolder = v.getTag(R.id.tag_view_holder);
            if (tagViewHolder instanceof ItemViewHolder) {
                if (mImitateGridListener != null) {
                    mImitateGridListener.onGridItemClicked(((ItemViewHolder) tagViewHolder).mItemData);
                }
            }
        }
    };

    @Override
    public int getCount() {
        int line = 0;
        if (mDataList != null && mDataList.size() > 0) {
            line = (mDataList.size() - 1) / mColumnNumber + 1;
        }
        return line;
    }

    @Override
    public T getItem(int position) {
        return mDataList.get(position * mColumnNumber);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private ArrayList<T> mTmpItemList;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(rowViewLayoutId(), parent, false);
            mImitateGridListener.configRowView(convertView);
            convertView.setTag(new ViewHolder((ViewGroup) convertView, mOnClickListener, mImitateGridListener, mColumnNumber, mGridPicSize));
        }

        ViewHolder viewHolder = (ViewHolder) convertView.getTag();
        int reallyPos = position * mColumnNumber;
        int reallySize = mDataList.size();
        if (mTmpItemList == null) {
            mTmpItemList = new ArrayList<>();
        } else {
            mTmpItemList.clear();
        }
        for (int idx = 0; idx < mColumnNumber; ++idx) {
            if (reallyPos + idx < reallySize) {
                mTmpItemList.add(mDataList.get(reallyPos + idx));
            }
        }
        viewHolder.flushView(mTmpItemList);
        return convertView;
    }

    private static class ViewHolder<T> {

        private ItemViewHolder<T>[] mSv;

        public int getSize() {
            return mSv.length;
        }

        public ViewHolder(ViewGroup mainView, View.OnClickListener onClickListener, ImitateGridListener imitateGridListener
                , int columnNumber, int picSize) {
            mSv = new ItemViewHolder[columnNumber];
            LayoutInflater inflater = LayoutInflater.from(mainView.getContext());
            int horizontalMargin = imitateGridListener.horizontalMargin();
            for (int idx = 0; idx < columnNumber; ++idx) {
                ItemViewHolder sv = imitateGridListener.onCreateGridItemViewHolder();
                View subView = sv.inflateView(inflater, mainView);
                sv.mGridPicSize = picSize;
                sv.setOriginListener(onClickListener);
                mSv[idx] = sv;
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
                layoutParams.leftMargin = horizontalMargin;
                if (idx + 1 == columnNumber) {
                    layoutParams.rightMargin = horizontalMargin;
                }
                mainView.addView(subView, layoutParams);
            }
        }

        public void flushView(ArrayList<T> itemList) {
            int viewHolderCount = mSv.length;
            int dataSize = itemList.size();
            for (int idx = 0; idx < viewHolderCount; idx++) {
                mSv[idx].flushView(idx < dataSize ? itemList.get(idx) : null);
            }
        }
    }

    public abstract static class ItemViewHolder<T> {

        protected View mRootView;

        private T mItemData;

        private int mGridPicSize;

        private void setOriginListener(View.OnClickListener originListener) {
            mRootView.setOnClickListener(originListener);
        }

        protected abstract int gridItemLayoutId();

        private View inflateView(LayoutInflater inflater, ViewGroup parentView) {
            mRootView = inflater.inflate(gridItemLayoutId(), parentView, false);
            mRootView.setTag(R.id.tag_view_holder, this);
            initView(mRootView);
            return mRootView;
        }

        protected abstract void initView(View view);

        private void flushView(T itemData) {
            mRootView.setTag(R.id.tag_bind_data, itemData);
            mItemData = itemData;
            if (itemData == null) {
                mRootView.setVisibility(View.INVISIBLE);
            } else {
                mRootView.setVisibility(View.VISIBLE);
                flushViewWithData(itemData);
            }
        }

        protected abstract void flushViewWithData(T itemData);
    }
}
