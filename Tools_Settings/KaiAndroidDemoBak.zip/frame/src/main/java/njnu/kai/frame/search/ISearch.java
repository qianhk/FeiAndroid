package njnu.kai.framework.search;

public interface ISearch {
    /**
     * 搜索
     *
     * @param word 关键词
     * @param userInput 用户输入的字符
     */
    void search(String word, String userInput);
}
