package njnu.kai.framework;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.os.PowerManager;
import njnu.kai.utils.ReflectUtils;

import java.lang.reflect.Method;

/**
 * @author kai
 * @version 7.0.0
 *          Service基类
 */
public abstract class BaseService extends Service {
    private NotificationManager mNotificationManager;
    private Method mSetForegroundMethod;
    private Method mStartForeground;
    private Method mStopForegroundMethod;

    private PowerManager.WakeLock mWakeLock;

    private void initForegroundCompact() {
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        try {
            mStartForeground = ReflectUtils.getMethod(getClass(), "startForeground", int.class, Notification.class);
            mStopForegroundMethod = ReflectUtils.getMethod(getClass(), "stopForeground", boolean.class);
            return;
        } catch (NoSuchMethodException e) {
            mStartForeground = null;
            mStopForegroundMethod = null;

            try {
                mSetForegroundMethod = ReflectUtils.getMethod(getClass(), "setForeground", boolean.class);
            } catch (NoSuchMethodException e1) {
                throw new IllegalStateException("OS doesn't have Service.startForeground OR Service.setForeground!");
            }
        }
    }

    protected void startForegroundCompact(int id, Notification notification) {
        notification.flags = Notification.FLAG_ONGOING_EVENT;
        try {
            if (mStartForeground != null) {
                mStartForeground.invoke(this, id, notification);
            } else {
                mSetForegroundMethod.invoke(this, Boolean.TRUE);
                mNotificationManager.notify(id, notification);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void stopForegroundCompact(int id) {
        try {
            if (mStopForegroundMethod != null) {
                mStopForegroundMethod.invoke(this, Boolean.TRUE);
            } else {
                mNotificationManager.cancel(id);
                mSetForegroundMethod.invoke(this, Boolean.FALSE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void notify(int id, Notification notification) {
        mNotificationManager.notify(id, notification);
    }

    protected void cancel(int id) {
        mNotificationManager.cancel(id);
    }

    protected void cancelAll() {
        mNotificationManager.cancelAll();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        initForegroundCompact();
    }

    @Override
    public void onDestroy() {
        if (mWakeLock != null) {
            mWakeLock.release();
        }
        super.onDestroy();
    }

    protected void startupWakeLock() {
        PowerManager powerManager = (PowerManager)getSystemService(Context.POWER_SERVICE);
        mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getName());
        mWakeLock.setReferenceCounted(false);
        mWakeLock.acquire();
    }
}
