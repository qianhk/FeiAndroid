package njnu.kai.framework;

import android.os.Bundle;
import android.view.View;
import njnu.kai.framework.Immersive.ImmersiveHelper;
import njnu.kai.framework.Immersive.ImmersiveObserver;
import njnu.kai.framework.Immersive.ImmersiveOnApplyStyleListener;
import njnu.kai.framework.Immersive.ImmersiveOnObserverInitedListener;
import njnu.kai.framework.BaseFragment;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public class ImmersionStyleFragment extends BaseFragment implements ImmersiveOnApplyStyleListener, ImmersiveOnObserverInitedListener {

    private ImmersiveHelper mImmersiveHelper;

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mImmersiveHelper = new ImmersiveHelper(this);
        mImmersiveHelper.applyStyle(getActivity(), this);
    }

    protected int topViewId() {
        return 0;
    }


    protected int bottomViewId() {
        return 0;
    }

    protected int topMaskViewId() {
        return 0;
    }


    protected int bottomMaskViewId() {
        return 0;
    }

    @Override
    public boolean needApplyStatusBarStyle() {
        return true;
    }

    @Override
    public boolean needApplyNavigationBarStyle() {
        return true;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mImmersiveHelper.onDestroyView();
    }

    @Override
    public void onInitImmersiveObserver(ImmersiveObserver immersiveObserver) {
        final View view = getView();
        if (view != null) {
            immersiveObserver.setImmersiveView(topViewId() != 0 ? view.findViewById(topViewId()) : null
                    , bottomViewId() != 0 ? view.findViewById(bottomViewId()) : null
                    , topMaskViewId() != 0 ? view.findViewById(topMaskViewId()) : null
                    , bottomMaskViewId() != 0 ? view.findViewById(bottomMaskViewId()) : null);
        }
    }

}
