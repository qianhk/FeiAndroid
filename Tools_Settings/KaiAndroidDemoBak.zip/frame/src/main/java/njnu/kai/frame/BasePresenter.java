package njnu.kai.framework;

import androidx.annotation.NonNull;


import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import njnu.kai.BaseResult;
import njnu.kai.network.executor.BaseObserver;
import njnu.kai.network.executor.DataFetcher;

import njnu.kai.exception.NetworkConnectionException;
import njnu.kai.network.executor.ResultCallback;

/**
 * @author kai
 * @version 1.0.0
 */
public class BasePresenter<V extends IView> implements IPageLifecycle {

    private CompositeDisposable mCompositeDisposable = new CompositeDisposable();

    protected V mBindView;

    public BasePresenter(V bindView) {
        mBindView = bindView;
    }

    protected <T> Disposable execute(@NonNull Observable<T> observable, final ResultCallback<T> resultCallback) {
        Disposable disposable = DataFetcher.fetch(getBindView(), observable, resultCallback);
        mCompositeDisposable.add(disposable);
        return disposable;
    }

    protected <T> Disposable execute(@NonNull Observable<T> observable, BaseObserver<? super T> subscriber) {
        Disposable disposable = observable.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(subscriber);
        mCompositeDisposable.add(disposable);
        return disposable;
    }

    public boolean isViewBind() {
        return mBindView != null;
    }

//    @Override
//    public void bindView(V view) {
//        mBindView = view;
//    }

    public V getBindView() {
        return mBindView;
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onStart() {

    }

    @Override
    public void onResume() {

    }

    @Override
    public void onPause() {

    }

    @Override
    public void onStop() {

    }

    @Override
    public void onDestroy() {
        mCompositeDisposable.clear();
        mBindView = null;
    }

    /**
     * @param t throwable
     * @return 将底层返回的错误异常转成ui层定义的错误码
     */
    public static int uiErrorCode(Throwable t) {
        return t instanceof NetworkConnectionException ? BaseResult.UNABLE_CONNECT_TO_SERVER : BaseResult.ERROR;
    }

}

