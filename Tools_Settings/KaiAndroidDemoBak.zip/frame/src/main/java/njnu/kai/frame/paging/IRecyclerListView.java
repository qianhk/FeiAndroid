package njnu.kai.framework.paging;

import android.content.Context;

import me.drakeet.multitype.BaseVO;
import njnu.kai.framework.BaseActivity;

import njnu.kai.framework.IView;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public interface IRecyclerListView extends IView {

    void handleVoUpdated(BaseVO baseVO);

    void handleVoRemoved(BaseVO baseVO);

    BaseVO getItemDataByVoId(String voId);

    BaseActivity getBaseActivity();

    Context getBaseContext();

}
