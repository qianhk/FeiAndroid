package njnu.kai.framework.navigator;

import java.util.Map;

/**
 * @author kai
 */
public interface IParameter {

    int getInt(String key);

    int getInt(String key, int defaultValue);

    long getLong(String key);

    long getLong(String key, long defaultValue);

    float getFloat(String key, float defaultValue);

    double getDouble(String key, double defaultValue);

    boolean getBoolean(String key, boolean defaultValue);

    String getString(String key, String defaultValue);

    Map<String, String> getParameters();

}
