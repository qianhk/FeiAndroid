package njnu.kai.framework;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public interface IPageLifecycle {

    void onCreate();

    void onStart();

    void onResume();

    void onPause();

    void onStop();

    void onDestroy();
}
