package njnu.kai.framework.exception;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Debug;

import njnu.kai.AppConfig;
import njnu.kai.AppRuntime;
import njnu.kai.framework.navigator.Navigator;
import njnu.kai.utils.DateUtils;
import njnu.kai.utils.FileUtils;
import njnu.kai.utils.LogUtils;
import njnu.kai.utils.PackageUtils;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

/**
 * 异常捕获类
 *
 * @version 1.0.0
 */
public class ExceptionReporter {
    /**
     * 进入发送错误报告的消息.
     */
    private static final int BYTES_PER_MB = 1024 * 1024;
    private static final String LOG_TAG = "ExceptionReporter";

    private static boolean mCrashing;

    /**
     * 创建异常，测试用
     */
    public static void createException() {
        throw new OutOfMemoryError();
    }

    /**
     * 捕获未知异常
     *
     * @param logName log name
     */
    public static void init(final String logName) {
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread thread, Throwable ex) {
                if (mCrashing) {
                    return;
                }
                mCrashing = true;
                Writer result = new StringWriter();
                ex.printStackTrace(new PrintWriter(result));
                String exceptionResult = result.toString();
                LogUtils.e(LOG_TAG, logName + "_Crash_Exception:\n" + exceptionResult);
                Navigator.withPage("exception")
                        .addParameter(Intent.EXTRA_SUBJECT, ex.toString())
                        .addParameter(Intent.EXTRA_TEXT, exceptionResult)
                        .addParameter(Intent.EXTRA_SHORTCUT_NAME, logName)
                        .setLaunchFlag(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .open();
                System.exit(0);
            }
        });
    }

    /**
     * 发送错误日志到后台
     *
     * @param title    异常标题
     * @param message  异常详细信息
     * @param callback 处理完时回调
     */
    public static void report(final String title, final String message, final String logName, final OnRequestFinishedListener callback) {
//        try {
//            HashMap map = buildReportParameters(title, message);
//            ExceptionReportAPI.send(map).execute(new RequestCallback<BaseResult>() {
//                @Override
//                public void onRequestSuccess(BaseResult baseResult) {
//                    callback.onRequestFinishedEvent(baseResult.isSuccess());
//                }
//
//                @Override
//                public void onRequestFailure(BaseResult baseResult) {
//                    callback.onRequestFinishedEvent(baseResult.isSuccess());
//                }
//            });
//        } catch (Exception e) {
//            // TODO Auto-generated catch block
//            callback.onRequestFinishedEvent(false);
//            e.printStackTrace();
//        }


        final SimpleDateFormat tmpDataFormat = new SimpleDateFormat("_yyyy-MM-dd_HH_mm_ss", Locale.getDefault());
        String logFileName = logName + tmpDataFormat.format(new Date()) + ".log";
        HashMap<String, Object> stringObjectHashMap = buildReportParameters(title, message);
        boolean success = FileUtils.store(stringObjectHashMap.toString(), AppConfig.getLogFolderPath() + File.separator + logFileName);
        callback.onRequestFinishedEvent(success);
    }

    private static HashMap<String, Object> buildReportParameters(String title, String message) {
        HashMap<String, Object> reportParameters = new HashMap<String, Object>();

        //这里后台不能接受值为0，所以部分值加了下划线
        reportParameters.put(ExceptionReportAPI.KEY_EXCEPTION_TIME, DateUtils.getReadableDateTime(System.currentTimeMillis()));
        reportParameters.put(ExceptionReportAPI.KEY_PACKAGE_NAME, AppRuntime.getPackageName());
        reportParameters.put(ExceptionReportAPI.KEY_VERSION, AppRuntime.Config.getAppVersion());
        reportParameters.put("versionName", PackageUtils.versionName(AppRuntime.getContext()));
        reportParameters.put("logEnable", AppRuntime.Config.isLogEnable());
        reportParameters.put("inTestMode", AppRuntime.Config.isTestMode());
        reportParameters.put("cpuInfo", AppRuntime.CPU.cpuInfo());
        reportParameters.put("SdkVersion:", Build.VERSION.SDK_INT);
        reportParameters.put("PageName:", AppRuntime.sPageName != null ? AppRuntime.sPageName : "unknown");

        reportParameters.put(ExceptionReportAPI.KEY_CHANNEL, "f" + AppRuntime.Config.getChannel());
        reportParameters.put(ExceptionReportAPI.KEY_MID, Build.MANUFACTURER + "#" + Build.MODEL);
        reportParameters.put(ExceptionReportAPI.KEY_SPLUS, Build.VERSION.RELEASE);

        HashMap<String, Object> generalParameters = AppRuntime.GeneralParameters.parameters();
        reportParameters.put(ExceptionReportAPI.KEY_S, generalParameters.get(ExceptionReportAPI.KEY_S));
        reportParameters.put(ExceptionReportAPI.KEY_ROM, Build.PRODUCT);
        reportParameters.put(ExceptionReportAPI.KEY_MEMORY, memoryInfo());
        reportParameters.put(ExceptionReportAPI.KEY_MESSAGE, message);
        reportParameters.put(ExceptionReportAPI.KEY_EXCEPTION_NAME, title);

        return reportParameters;
    }

    /**
     * 获取当前程序内存使用
     *
     * @return 返回内存使用
     */
    private static String memoryInfo() {
        double totalMem = (double) Runtime.getRuntime().totalMemory() / BYTES_PER_MB;
        double freeMem = (double) Runtime.getRuntime().freeMemory() / BYTES_PER_MB;
        double maxMem = (double) Runtime.getRuntime().maxMemory() / BYTES_PER_MB;
        double allocatedMem = (double) Debug.getNativeHeapAllocatedSize() / BYTES_PER_MB;

        DecimalFormat decimalFormat = new DecimalFormat("0.000");
        StringBuilder stringBuilder = new StringBuilder("Runtime:{total:").append(decimalFormat.format(totalMem))
                .append(",free:").append(decimalFormat.format(freeMem))
                .append(",max:").append(decimalFormat.format(maxMem))
                .append("},HeapAllocated:").append(decimalFormat.format(allocatedMem));

        return stringBuilder.toString();
    }

    /**
     * 回调接口
     */
    public interface OnRequestFinishedListener {
        /**
         * 回调接口
         *
         * @param isSuccess 是否成功
         */
        public void onRequestFinishedEvent(boolean isSuccess);
    }
}
