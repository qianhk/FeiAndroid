package njnu.kai.framework;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.bumptech.glide.Glide;
import com.umeng.analytics.MobclickAgent;

import njnu.kai.AppRuntime;
import njnu.kai.framework.navigator.IParameter;
import njnu.kai.framework.navigator.IntentParameter;
import njnu.kai.utils.LogUtils;
import njnu.kai.utils.ToastUtils;

import java.util.concurrent.TimeUnit;

/**
 * @author kai
 * @version 7.0.0
 */
public abstract class BaseActivity extends FragmentActivity {

    private static final String TAG = "BaseActivity";

    private boolean mImmersiveObserverViewCreated = false;

    private static final long DOUBLE_CLICK_DURATION = TimeUnit.MILLISECONDS.toNanos(260);
    private static final int ACTION_MOVE_GAP_PX = 48;
    private float mTouchDownX;
    private float mTouchDownY;
    private boolean mIsMoveAction = false;
    private long mLastClickTime;
    private boolean mAllowFastClickTemporarily;

    private PageLifecycleHelper mPageLifecycleHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (needOverridePendingTransition()) {
            overridePendingTransition(R.anim.page_slide_in_right, 0);
        }
        ActivityManager.instance().onCreate(this);
        mPageLifecycleHelper = new PageLifecycleHelper();

//        final View decorView = getWindow().getDecorView();
//        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
//
//        decorView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
//            @Override
//            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
//                return insets.consumeSystemWindowInsets();
//            }
//        });


        //透明状态栏
//        if (needImmersionStyle() && SDKVersionUtils.hasKitKat()) {
//            Window window = getWindow();
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
//                        | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
//                window.getDecorView().setSystemUiVisibility(
//                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
//                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//                window.setStatusBarColor(Color.TRANSPARENT);
//                window.setNavigationBarColor(Color.TRANSPARENT);
//            } else {
//                window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
//                        | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
//            }
//        }

    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        registerPageLifecycles();
        mPageLifecycleHelper.onCreate();
    }

    protected void registerPageLifecycles() {
    }

    final public void registerPageLifecycle(IPageLifecycle lifecycle) {
        mPageLifecycleHelper.register(lifecycle);
    }

    public void unregisterPageLifecycle(IPageLifecycle lifecycle) {
        mPageLifecycleHelper.unregister(lifecycle);
    }

    protected boolean needImmersionStyle() {
        return false;
    }

    @Override
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);
        initImmersiveViewObserver();
    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);
        initImmersiveViewObserver();
    }

    @Override
    public void setContentView(View view, ViewGroup.LayoutParams params) {
        super.setContentView(view, params);
        initImmersiveViewObserver();
    }

    @Override
    public void addContentView(View view, ViewGroup.LayoutParams params) {
        if (!mImmersiveObserverViewCreated) {
            initImmersiveViewObserver();
        }
        super.addContentView(view, params);
    }

    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    private void initImmersiveViewObserver() {
        mImmersiveObserverViewCreated = true;
        View view = new View(this);
        view.setVisibility(View.INVISIBLE);
        view.setId(R.id.view_immersive_observer);
        view.setFitsSystemWindows(true);
        addContentView(view, new ViewGroup.LayoutParams(0, 0));
        onImmersiveViewObserverCreated(view);
    }

    protected void onImmersiveViewObserverCreated(View observerView) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        ActivityManager.instance().onResume(this);
        mPageLifecycleHelper.onResume();
        if (AppRuntime.sUseUMeng) {
            String uiPageName = onGetUIPageName();
            if (uiPageName != null) {
                MobclickAgent.onPageStart(uiPageName);
            }
            MobclickAgent.onResume(this);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        ActivityManager.instance().onPause(this);
        mPageLifecycleHelper.onPause();
        if (AppRuntime.sUseUMeng) {
            String uiPageName = onGetUIPageName();
            if (uiPageName != null) {
                MobclickAgent.onPageEnd(uiPageName);
            }
            MobclickAgent.onPause(this);
        }
    }

    protected String onGetUIPageName() {
        return null;
    }

    @Override
    protected void onStop() {
        super.onStop();
        mPageLifecycleHelper.onStop();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mPageLifecycleHelper.onStart();
    }

    protected void setFullscreen(boolean fullscreen) {
        Window window = getWindow();
        WindowManager.LayoutParams winParams = window.getAttributes();
        final int bits = WindowManager.LayoutParams.FLAG_FULLSCREEN;
        if (fullscreen) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits;
        }
        window.setAttributes(winParams);
    }


    @Override
    protected void onDestroy() {
        hideSoftInputView();
        super.onDestroy();
        ActivityManager.instance().onDestroy(this);
        mPageLifecycleHelper.onDestroy();
    }

    protected void hideSoftInputView() {
        InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        View currentFocus = getCurrentFocus();
        if (currentFocus == null) {
            currentFocus = getWindow().getDecorView();
        }
        if (manager != null && currentFocus != null) {
            manager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

    public void showInputMethod(EditText editText) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (editText != null && inputMethodManager != null) {
            editText.requestFocus();
            inputMethodManager.showSoftInput(editText, 0);
        }
    }

    @Override
    public void onBackPressed() {
        try {
            super.onBackPressed();
        } catch (IllegalStateException e) {
            LogUtils.e(TAG, "onBackPressed时发生异常 " + e.getMessage());
            finish();
        }
    }

    @Override
    public void finish() {
        super.finish();
        if (needOverridePendingTransition()) {
            overridePendingTransition(0, R.anim.page_slide_out_right);
        }
    }

    protected boolean needOverridePendingTransition() {
        return true;
    }

    protected boolean filterException(Exception e) {
        if (e != null) {
            ToastUtils.showToast(e.getMessage());
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Glide.with(this).onTrimMemory(level);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        Glide.with(this).onLowMemory();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mTouchDownX = ev.getX();
                mTouchDownY = ev.getY();
                mIsMoveAction = false;
                break;
            case MotionEvent.ACTION_MOVE:
                mIsMoveAction = mIsMoveAction || isMoveAction(ev);
                break;
            case MotionEvent.ACTION_UP:
                if (!mAllowFastClickTemporarily && !mIsMoveAction && isClickTooFast()) {
                    ev.setAction(MotionEvent.ACTION_CANCEL);
                }
                mAllowFastClickTemporarily = false;
                break;
            default:
                break;
        }
        if (ev.getAction() == MotionEvent.ACTION_CANCEL) {
            try {
                return super.dispatchTouchEvent(ev);
            } catch (IllegalArgumentException e) {
                return true;
            }
        } else {
            return super.dispatchTouchEvent(ev);
        }
    }

    /**
     * 获取快速点击支持
     */
    public void acquireFastClickSupport() {
        mAllowFastClickTemporarily = true;
    }

    private boolean isMoveAction(MotionEvent ev) {
        return (Math.abs(ev.getX() - mTouchDownX) > ACTION_MOVE_GAP_PX || Math.abs(ev.getY() - mTouchDownY) > ACTION_MOVE_GAP_PX);
    }

    private boolean isClickTooFast() {
        long time = System.nanoTime();
        if (time - mLastClickTime < DOUBLE_CLICK_DURATION) {
            return true;
        }
        mLastClickTime = time;
        return false;
    }

    private long mLastExitTimeNs;

    protected void pressAgainExitApp() {
        if (TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - mLastExitTimeNs) > 1500) {
            ToastUtils.showToast(R.string.press_again_exit_app);
            mLastExitTimeNs = System.nanoTime();
        } else {
//            finish();
            BaseApplication.getApp().exit();
        }
    }

    public long getArgumentId() {
        return getPageParams().getInt("id");
    }

    public IParameter getPageParams() {
        return IntentParameter.from(getIntent());
    }

}
