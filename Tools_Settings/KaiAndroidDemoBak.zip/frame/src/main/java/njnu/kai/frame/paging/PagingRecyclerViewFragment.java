package njnu.kai.framework.paging;

import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import in.srain.cube.views.ptr.PtrDefaultHandler;
import in.srain.cube.views.ptr.PtrFrameLayout;
import in.srain.cube.views.ptr.PtrHandler;
import me.drakeet.multitype.BaseVO;
import me.drakeet.multitype.MultiTypeAdapter;
import me.drakeet.multitype.OnMultiTypeViewListener;
import njnu.kai.framework.R;
import njnu.kai.framework.ActivityManager;
import njnu.kai.framework.BaseActivity;
import njnu.kai.framework.StateViewFragment;
import me.drakeet.multitype.IPagingListAdapter;
import njnu.kai.framework.recycler.OnLoadMoreScrollListener;
import njnu.kai.uikit.LoadingFooterView;
import njnu.kai.uikit.StateView;

/**
 * @author kai
 *
 */
public abstract class PagingRecyclerViewFragment<PRESENTER extends PagingListPresenter> extends StateViewFragment
        implements IRecyclerListView, OnMultiTypeViewListener, IPagingListView {

    private static final String TAG = "PagingRecyclerViewFragment";

    private PtrFrameLayout mPtrFrameLayout;

    private RecyclerView mRecyclerView;

    private IPagingListAdapter mAdapter;

    protected PRESENTER mListPresenter;

    private LoadingFooterView mFooterView;

    protected int listViewLayoutId() {
        return needPtrAndLoadNextFeature() ? R.layout.common_recyclerview_with_ptr : R.layout.common_recyclerview_without_ptr;
    }

    protected View onContentViewInflated(View contentView) {
        return contentView;
    }

    protected abstract PRESENTER onCreatePresenter();

    protected abstract IPagingListAdapter onCreateAdapter();

    protected boolean needPtrAndLoadNextFeature() {
        return true;
    }

//    protected boolean needLoadNextPageFeature() {
//        return true;
//    }

    public MultiTypeAdapter makeGlobalMultiTypeAdapter() {
        MultiTypeAdapter adapter = new MultiTypeAdapter();
        adapter.setMultiTypeViewListener(this);
        adapter.applyGlobalMultiTypePool();
        return adapter;
    }

    @Override
    protected View onCreateContentView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View mainView = layoutInflater.inflate(listViewLayoutId(), viewGroup, false);
        mPtrFrameLayout = (PtrFrameLayout) mainView.findViewById(R.id.ptr_frame_layout);
        mRecyclerView = (RecyclerView) mainView.findViewById(R.id.recycler_view);
//        mRecyclerView.setLayoutManager(new LinearLayoutManager(layoutInflater.getContext(), LinearLayoutManager.VERTICAL, false));
        mRecyclerView.setHasFixedSize(true);
        mainView = onContentViewInflated(mainView);

        mAdapter = onCreateAdapter();
        RecyclerView.Adapter adapter = (RecyclerView.Adapter) mAdapter;

        if (mPtrFrameLayout != null) {
            mFooterView = new LoadingFooterView(layoutInflater.getContext());
            mFooterView.setLayoutParams(new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT
                    , RecyclerView.LayoutParams.WRAP_CONTENT));
            mRecyclerView.setAdapter(new WrapperAdapter(adapter, mFooterView));

            mFooterView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mFooterView.getState() != LoadingFooterView.State.TheEnd) {
                        mListPresenter.loadNextPage();
                    }
                }
            });

            mRecyclerView.addOnScrollListener(new OnLoadMoreScrollListener() {
                @Override
                public void onLoadMore(RecyclerView recyclerView) {
                    if (mListPresenter.canAutoLoadNextPage()) {
                        mListPresenter.loadNextPage();
                    } else {
                        refreshComplete();
                    }
                }
            });

        } else {
            mRecyclerView.setAdapter(adapter);
        }

        if (mPtrFrameLayout != null) {
            mPtrFrameLayout.setPtrHandler(new PtrHandler() {

                @Override
                public void onRefreshBegin(PtrFrameLayout ptrFrameLayout) {
                    mListPresenter.reload(true);
                }

                @Override
                public boolean checkCanDoRefresh(PtrFrameLayout ptrFrameLayout, View content, View header) {
                    return PtrDefaultHandler.checkContentCanBePulledDown(ptrFrameLayout, content, header);
                }
            });
        }

        return mainView;
    }

    @Override
    protected void onRegisterPageLifecycle() {
        super.onRegisterPageLifecycle();
        if (mListPresenter != null) {
            registerPageLifecycle(mListPresenter);
        }
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        mListPresenter = onCreatePresenter();
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    protected void onLoadFinished() {
        super.onLoadFinished();
        if (enterAutoLoading() && mListPresenter != null) {
            mListPresenter.reload(false);
        }
    }

    protected boolean enterAutoLoading() {
        return true;
    }

    @Override
    protected final StateView.State originalState() {
        return enterAutoLoading() ? StateView.State.LOADING : StateView.State.SUCCESS;
    }


    @Override
    protected void onStateViewRetryRequested() {
        mListPresenter.reload(false);
    }

    protected void refreshComplete() {
        if (mPtrFrameLayout != null) {
            mPtrFrameLayout.refreshComplete();
        }
    }

    protected void setEnableRefresh(boolean enableRefresh) {
        if (mPtrFrameLayout != null) {
            mPtrFrameLayout.setEnabled(enableRefresh);
        }
    }

    public void onStateChanged(StateView.State state, int code) {
        setStateViewState(state);
    }

    public RecyclerView getRecyclerView() {
        return mRecyclerView;
    }

    @Override
    public BaseActivity getBaseActivity() {
        FragmentActivity activity = getActivity();
        if (activity instanceof BaseActivity) {
            return (BaseActivity) activity;
        } else {
            return (BaseActivity) ActivityManager.instance().getCurrentActivity();
        }
    }

    @Override
    public Context getBaseContext() {
        return getBaseActivity();
    }

    @Override
    public void flushData(List dataList) {
        mAdapter.flushData(dataList);
    }

    @Override
    public void appendData(List dataList) {
        mAdapter.appendData(dataList);
    }

    @Override
    public void showNextPageLoading() {
        mFooterView.setState(LoadingFooterView.State.Loading);
    }

    @Override
    public void showNextPageFailure() {
        mFooterView.setState(LoadingFooterView.State.Failed);
    }

    @Override
    public void showNextPageSuccess() {
        mFooterView.setState(LoadingFooterView.State.Normal);
    }

    @Override
    public void showAllPageLoaded() {
        mFooterView.setState(LoadingFooterView.State.TheEnd);
    }

    public void setLastPageText(CharSequence lastPageText) {
        mFooterView.setLastPageText(lastPageText);
    }

    @Override
    public void showLoading() {
        setStateViewState(StateView.State.LOADING);
    }

    @Override
    public void showFailure(String message) {
        refreshComplete();
        setStateViewState(StateView.State.FAILED);
    }

    @Override
    public void showNoData() {
        refreshComplete();
        setStateViewState(StateView.State.NO_DATA);
    }

    @Override
    public void showSuccess() {
        refreshComplete();
        setStateViewState(StateView.State.SUCCESS);
    }

    @Override
    public boolean isDataEmpty() {
        return mAdapter == null || mAdapter.getRealCount() <= 0;
    }

    @Override
    public void handleVoUpdated(BaseVO baseVO) {
        if (baseVO == null) {
            mAdapter.notifyDataSetChanged();
        } else if (mAdapter instanceof MultiTypeAdapter) {
            ((MultiTypeAdapter) mAdapter).dataUpdated(baseVO);
        }
    }

    @Override
    public void handleVoRemoved(BaseVO baseVO) {
        mAdapter.removeData(baseVO);
    }

    @Override
    public BaseVO getItemDataByVoId(String voId) {
        if (mAdapter instanceof MultiTypeAdapter) {
            return ((MultiTypeAdapter) mAdapter).getItemDataByVoId(voId);
        }
        return null;
    }

    @Override
    public void onMultiTypeViewClicked(BaseVO data, String action) {
        if (mListPresenter != null) {
            mListPresenter.onMultiTypeViewClicked(data, action);
        }
    }

    @Override
    public void onMultiTypeValueChanged(BaseVO data, String action) {
        if (mListPresenter != null) {
            mListPresenter.onMultiTypeValueChanged(data, action);
        }
    }
}
