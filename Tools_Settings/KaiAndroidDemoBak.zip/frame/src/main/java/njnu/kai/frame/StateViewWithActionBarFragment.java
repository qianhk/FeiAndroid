package njnu.kai.framework;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import njnu.kai.uikit.StateView;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public abstract class StateViewWithActionBarFragment extends ActionBarLayoutFragment implements StateView.OnConfigStateViewListener {

    private StateView mStateView;

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            final int viewId = v.getId();
            if (viewId == R.id.loadingview_need_retry) {
                onStateViewRetryRequested();
            }
        }
    };

    @Override
    void initStateViewContainer(LayoutInflater inflater, StateView stateView, Bundle savedInstanceState) {
        super.initStateViewContainer(inflater, stateView, savedInstanceState);
        mStateView = stateView;
        View successView = onCreateContentView(inflater, mStateView, savedInstanceState);
        mStateView.setOnConfigStateViewListener(this);
        mStateView.setStateProperty(StateView.State.SUCCESS, successView);
    }

    @Override
    int commonActionBarLayoutId() {
        return R.layout.common_actionbar_layout_with_stateview;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mStateView.setState(originalState(), false);
    }

    @Override
    protected void onLoadFinished() {
        super.onLoadFinished();
        if (mStateView.getCurrentState() == StateView.State.LOADING) {
            mStateView.showAnimation();
        }
    }

    protected void setState(StateView.State state) {
        mStateView.setState(state, true);
    }

    public void setStateProperty(StateView.State state, int layoutId) {
        mStateView.setStateProperty(state, layoutId);
    }

    public StateView getStateView() {
        return mStateView;
    }


    /**
     * ------------------    以下供派生类重载     --------------
     */


    /**
     * 重试请求
     */
    protected abstract void onStateViewRetryRequested();

    @Override
    public void onConfigStateView(View view, StateView.State state) {
        if (state == StateView.State.FAILED || state == StateView.State.NO_DATA) {
            view.setOnClickListener(mOnClickListener);
        }
    }


    /**
     * @return 初始状态, 默认loading
     */
    protected StateView.State originalState() {
        return StateView.State.LOADING;
    }

}
