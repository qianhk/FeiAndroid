//package njnu.kai.framework.fragment;
//
//import njnu.kai.dialog.ActionItem;
//import njnu.kai.dialog.OnDropdownMenuClickListener;
//import njnu.kai.dialog.PopupUtils;
//import njnu.kai.framework.R;
//import njnu.kai.framework.ActionBarLayoutFragment;
//import njnu.kai.uikit.ActionBarLayout;
//import njnu.kai.uikit.ListPopupWindow;
//
//import java.util.Collection;
//
///**
// * @author kai
// * @version 7.0.0
// *          有ActionBar的Fragment，默认显示ActionBar
// */
//public abstract class ActionBarWithMenuFragment extends ActionBarLayoutFragment implements OnDropdownMenuClickListener {
//
//    private ActionBarLayout.Action mMenuAction;
//    private ListPopupWindow mDropDownMenu;
//
//    @Override
//    protected void onInitActionBar() {
//        super.onInitActionBar();
//        mMenuAction = addIconTextAction(-2, R.string.icon_point_horizontal);
//    }
//
//    @Override
//    protected void onActionClick(int actionId, ActionBarLayout.Action action) {
//        super.onActionClick(actionId, action);
//        if (action == mMenuAction) {
//            onToggleMenuView(true);
//        }
//    }
//
//    protected abstract Collection<ActionItem> onCreateDropDownMenu();
//
//    @Override
//    public void onDropDownMenuClicked(int menuId, ActionItem menuItem) {
//        mDropDownMenu = null;
//        switch (menuId) {
//            default:
//                break;
//        }
//    }
//
//    /**
//     * @param topRight 是否右上角显示
//     */
//    public void onToggleMenuView(boolean topRight) {
//        if (mDropDownMenu != null && mDropDownMenu.isShowing()) {
//            mDropDownMenu.dismiss();
//            mDropDownMenu = null;
//        } else {
//            if (mMenuAction.isVisible()) {
//                Collection<ActionItem> actionItemList = onCreateDropDownMenu();
//                if (actionItemList != null && !actionItemList.isEmpty()) {
//                    mDropDownMenu = PopupUtils.popupMenu(getActivity(), actionItemList, topRight, this);
//                }
//            }
//        }
//    }
//
//    @Override
//    public void onStop() {
//        super.onStop();
//        PopupUtils.dismissPopupWindow(mDropDownMenu);
//    }
//
//}
