package njnu.kai.framework.Immersive;

/**
 */
public interface ImmersiveOnObserverInitedListener {

    public void onInitImmersiveObserver(ImmersiveObserver immersiveObserver);
}
