package njnu.kai.framework.Immersive;

import android.view.View;

/**
 * @version 1.0.0
 *
 */
public interface ImmersiveOnApplyPaddingListener {
    /**
     * 当应用底部padding后
     * @param view view
     * @param bottomPadding 底部padding
     */
    public void onAppliedBottomPadding(View view, int bottomPadding);

    /**
     * 当应用顶部padding后调用
     * @param view view
     * @param topPadding 顶部padding
     */
    public void onAppliedTopPadding(View view, int topPadding);
}
