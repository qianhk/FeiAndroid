package njnu.kai.framework;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.annotation.StringRes;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import njnu.kai.framework.Immersive.ImmersiveHelper;
import njnu.kai.framework.Immersive.ImmersiveObserver;
import njnu.kai.framework.Immersive.ImmersiveOnApplyStyleListener;
import njnu.kai.framework.Immersive.ImmersiveOnObserverInitedListener;
import njnu.kai.uikit.ActionBarLayout;
import njnu.kai.uikit.StateView;
import njnu.kai.utils.AttributeUtils;

/**
 * @author kai
 * @version 1.0.0
 */
public abstract class ActionBarLayoutFragment extends BaseFragment
        implements ImmersiveOnApplyStyleListener, ImmersiveOnObserverInitedListener {

    private ActionBarLayout mActionBarLayout;
    private ViewGroup mBodyContainer;
    private View mViewShadow;

    private ImmersiveHelper mImmersiveHelper;

    private ActionBarLayout.Action mActionBack;

    private ActionBarLayout.OnActionClickListener mOnActionClickListener = new ActionBarLayout.OnActionClickListener() {
        @Override
        public void onClick(int actionId, ActionBarLayout.Action action) {
            if (action == mActionBack) {
                onBackPressed();
            } else {
                onActionClick(actionId, action);
            }
        }
    };

    public void onBackPressed() {
        finish();
    }

    /**   ------------------------  子类可能需要根据情况重载的方法   ------------------------- **/

    /**
     * 提供给子类添加自定义Action和初始化标题之类的操作
     */
    protected void onInitActionBar() {
        mActionBarLayout.setMode(ActionBarLayout.MODE_TEXT);
    }

    /**
     * on click action button
     *
     * @param actionId actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param action   action action 也是告知点的哪个按钮
     */
    protected void onActionClick(int actionId, ActionBarLayout.Action action) {
    }

    /**
     * @return 是否需要后退按钮, 默认需要
     */
    protected boolean needBackAction() {
        return true;
    }

    @Override
    public boolean needApplyStatusBarStyle() {
        return true;
    }

    @Override
    public boolean needApplyNavigationBarStyle() {
        return true;
    }

    protected abstract View onCreateContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState);

    /**
     * ------------------------  子类可能需要根据情况重载的方法  end   -------------------------
     **/

    @Override
    public final View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View contentView = buildContentView(inflater, container, savedInstanceState);
        setBusinessView(contentView);
        PageBackground.setPageBackground(getActivity(), contentView);
        return contentView;
    }

    View buildContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View mainView = inflater.inflate(commonActionBarLayoutId(), container, false);
        mActionBarLayout = (ActionBarLayout) mainView.findViewById(R.id.actionbar_layout);
        mViewShadow = mainView.findViewById(R.id.actionbar_shadow);
        mBodyContainer = (ViewGroup) mainView.findViewById(R.id.actionbar_container);
        if (mBodyContainer instanceof StateView) {
            initStateViewContainer(inflater, (StateView) mBodyContainer, savedInstanceState);
        } else {
            final View contentView = onCreateContentView(inflater, mBodyContainer, savedInstanceState);
            if (contentView != null) {
                mBodyContainer.addView(contentView);
            }
        }
        if (needBackAction()) {
            int backIconResId = AttributeUtils.getDrawableResourceId(getActivity(), R.attr.framework_actionbar_back_icon);
            mActionBack = addLeftImageAction(-1, backIconResId);
        }
        onInitActionBar();
        return mainView;
    }

    int commonActionBarLayoutId() {
        return R.layout.common_actionbar_layout;
    }

    void initStateViewContainer(LayoutInflater inflater, StateView stateView, Bundle savedInstanceState) {
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mImmersiveHelper.onDestroyView();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mImmersiveHelper = new ImmersiveHelper(this);
        mImmersiveHelper.applyStyle(getActivity(), this);
    }

    @Override
    public void onInitImmersiveObserver(ImmersiveObserver immersiveObserver) {
        final View view = getView();
        if (view != null) {
            immersiveObserver.setImmersiveView(mActionBarLayout, mBodyContainer
                    , view.findViewById(R.id.status_bar_background), view.findViewById(R.id.navigate_bar_background));
        }
    }

    public ActionBarLayout getActionBarLayout() {
        return mActionBarLayout;
    }

    /**
     * @param title 设置工具栏标题
     */
    protected void setTitle(String title) {
        mActionBarLayout.setTitle(title);
    }

    /**
     * @param titleResId 设置工具栏标题
     */
    protected void setTitle(int titleResId) {
        mActionBarLayout.setTitle(titleResId);
    }

    /**
     * @param color 设置工具栏标题颜色
     */
    protected void setTitleColor(int color) {
        mActionBarLayout.setTitleColor(color);
    }

    /**
     * 右侧增加一个图片样式的动作按钮
     *
     * @param actionId   actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param imageResId resource id
     * @return action
     */
    protected ActionBarLayout.Action addImageAction(int actionId, int imageResId) {
        ActionBarLayout.Action action = mActionBarLayout.addImageAction(actionId, imageResId);
        action.setOnActionClickListener(mOnActionClickListener);
        return action;
    }

    /**
     * 右侧增加一个文字样式的动作按钮
     *
     * @param actionId actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param txtResId resource id
     * @return action
     */
    protected ActionBarLayout.Action addTextAction(int actionId, int txtResId) {
        ActionBarLayout.Action action = mActionBarLayout.addTextAction(actionId, txtResId);
        action.setOnActionClickListener(mOnActionClickListener);
        return action;
    }

    /**
     * 右侧增加一个文字样式的动作按钮
     *
     * @param actionId actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param txt      text
     * @return action
     */
    protected ActionBarLayout.Action addTextAction(int actionId, String txt) {
        ActionBarLayout.Action action = mActionBarLayout.addTextAction(actionId, txt);
        action.setOnActionClickListener(mOnActionClickListener);
        return action;
    }

    /**
     * 右侧增加一个字体图标文字样式的动作按钮
     *
     * @param actionId      actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param iconTextResId resource id
     * @return action
     */
    protected ActionBarLayout.Action addIconTextAction(int actionId, @StringRes int iconTextResId) {
        ActionBarLayout.Action action = mActionBarLayout.addIconTextAction(actionId, iconTextResId, null);
        action.setOnActionClickListener(mOnActionClickListener);
        return action;
    }

    /**
     * 右侧增加一个图片样式的动作按钮
     *
     * @param actionId actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param drawable drawable形式的图片
     * @return action
     */
    protected ActionBarLayout.Action addImageAction(int actionId, Drawable drawable) {
        ActionBarLayout.Action action = mActionBarLayout.addImageAction(actionId, drawable);
        action.setOnActionClickListener(mOnActionClickListener);
        return action;
    }

    /**
     * 在左侧增加一个图片样式的动作按钮
     *
     * @param actionId   actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param imageResId resource id
     * @return action
     */
    protected ActionBarLayout.Action addLeftImageAction(int actionId, int imageResId) {
        ActionBarLayout.Action action = mActionBarLayout.addLeftImageAction(actionId, imageResId);
        action.setOnActionClickListener(mOnActionClickListener);
        return action;
    }

    /**
     * 在左侧增加一个文字样式的动作按钮
     *
     * @param actionId actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param txtResId resource id
     * @return action
     */
    protected ActionBarLayout.Action addLeftTextAction(int actionId, int txtResId) {
        ActionBarLayout.Action action = mActionBarLayout.addLeftTextAction(actionId, txtResId);
        action.setOnActionClickListener(mOnActionClickListener);
        return action;
    }

    /**
     * 在左侧增加一个字体图标文字样式的动作按钮
     *
     * @param actionId      actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param iconTextResId resource id
     * @return action
     */
    protected ActionBarLayout.Action addLeftIconTextAction(int actionId, int iconTextResId) {
        ActionBarLayout.Action action = mActionBarLayout.addLeftIconTextAction(actionId, iconTextResId, null);
        action.setOnActionClickListener(mOnActionClickListener);
        return action;
    }

    /**
     * 在左侧增加一个图片样式的动作按钮
     *
     * @param actionId actionId 触发点击事件后,上层可知道点击的是哪个按钮
     * @param drawable drawable形式的图片
     * @return action
     */
    protected ActionBarLayout.Action addLeftImageAction(int actionId, Drawable drawable) {
        ActionBarLayout.Action action = mActionBarLayout.addLeftImageAction(actionId, drawable);
        action.setOnActionClickListener(mOnActionClickListener);
        return action;
    }

    /**
     * @param floatingMode 顶部工具栏是否使用浮动模式
     */
    public void setFloatingMode(boolean floatingMode) {
        final RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) mBodyContainer.getLayoutParams();
        if (floatingMode) {
            layoutParams.addRule(RelativeLayout.BELOW, 0);
        } else {
            layoutParams.addRule(RelativeLayout.BELOW, R.id.actionbar_layout);
        }
        mBodyContainer.setLayoutParams(layoutParams);
    }

    /**
     * @return 顶部工具栏是否是浮动模式
     */
    public boolean isFloatingMode() {
        final RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) mBodyContainer.getLayoutParams();
        return layoutParams.getRules()[RelativeLayout.BELOW] == 0;
    }

    /**
     * @param visibility 顶部工具栏下面的阴影显示隐藏
     */
    public void setShadowVisiblity(int visibility) {
        mViewShadow.setVisibility(visibility);
    }

}
