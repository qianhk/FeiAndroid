package njnu.kai.framework.search;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import njnu.kai.framework.R;
import njnu.kai.framework.WrapFragmentWithActionbarActivity;
import njnu.kai.uikit.ActionBarLayout;
import njnu.kai.uikit.IconTextView;
import njnu.kai.utils.StringUtils;

public abstract class WrapFragmentWithSearchbarActivity extends WrapFragmentWithActionbarActivity {

    private final static int SHOW_INPUT_METHOD_DELAY = 300;

    private View mSearchInputLayout;
    private EditText mInputEditText;
    private IconTextView mClearImageView;

    @Override
    protected void onActionClick(int actionId, ActionBarLayout.Action action) {
        super.onActionClick(actionId, action);
        if (actionId == 100) {
            hideSoftInputView();
            String word = mInputEditText.getText().toString();
            doSearch(word, "actionAction");
        }
    }

    /**
     * @param keyword keyword
     * @param source actionAction(右上角按钮点击) EditorAction(输入法上的搜索)
     */
    protected abstract void doSearch(String keyword, String source);

    @Override
    protected void onInitActionBar() {
        addImageAction(100, R.drawable.uikit_img_action_search);
        ActionBarLayout actionBarLayout = getActionBarLayout();
        actionBarLayout.setMode(ActionBarLayout.MODE_SEARCH);
        mSearchInputLayout = actionBarLayout.getSearchInputLayout();
        mInputEditText = (EditText) mSearchInputLayout.findViewById(R.id.edittext_search_input);
        mClearImageView = (IconTextView) mSearchInputLayout.findViewById(R.id.imageview_search_clear);
        mClearImageView.setImageResource(R.drawable.uikit_img_search_clear);
        mClearImageView.setVisibility(View.GONE);
        mClearImageView.setOnClickListener(mOnClickListener);
        mInputEditText.addTextChangedListener(mTextWatcher);
        mInputEditText.setOnEditorActionListener(mOnEditorActionListener);
        doInitEditText(mInputEditText);
    }

//    public void onKeyPressed(int keyCode, KeyEvent event) {
//        super.onKeyPressed(keyCode, event);
//        if (keyCode == KeyEvent.KEYCODE_MENU) {
//            hideInputMethod();
//        }
//    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mInputEditText.requestFocus();
        mInputEditText.postDelayed(() -> showInputMethod(mInputEditText), SHOW_INPUT_METHOD_DELAY);

    }

    protected abstract void doInitEditText(EditText editText);

    private TextWatcher mTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (StringUtils.isEmpty(s.toString())) {
                mClearImageView.setVisibility(View.GONE);
            } else {
                mClearImageView.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    private TextView.OnEditorActionListener mOnEditorActionListener = new TextView.OnEditorActionListener() {
        @Override
        public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO
                    || actionId == EditorInfo.IME_ACTION_UNSPECIFIED || actionId == EditorInfo.IME_ACTION_SEND) {
                hideSoftInputView();
                String word = mInputEditText.getText().toString();
                doSearch(word, "EditorAction");
                return true;
            }
            return false;
        }
    };

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int viewId = view.getId();
            if (viewId == R.id.imageview_search_clear) {
                mInputEditText.setText("");
                showInputMethod(mInputEditText);
            }
        }
    };

}
