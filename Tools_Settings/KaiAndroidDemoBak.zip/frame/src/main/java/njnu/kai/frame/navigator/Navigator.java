package njnu.kai.framework.navigator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import androidx.annotation.NonNull;

import java.util.List;
import java.util.Set;

import njnu.kai.AppConfig;
import njnu.kai.AppRuntime;
import njnu.kai.framework.ActivityManager;
import njnu.kai.utils.ListUtils;
import njnu.kai.utils.LogUtils;
import njnu.kai.utils.StringUtils;

public class Navigator {

    private static final String TAG = "Navigator";

    private static final String NATIVE_ACTION = Intent.ACTION_VIEW;
    private static final String NATIVE_CATEGORY = Intent.CATEGORY_DEFAULT;

    public static final String KEY_NAVIGATOR_ORIGIN_URL = "key_navigator_origin_url";

    private int mLaunchFlag;
    private int mRequestCode;

    private Uri.Builder mUriBuilder;

    private String mOriginUrl;

    private Navigator() {
    }

    public boolean open() {
        checkPageHasSet();

        Uri uri = makeUri();
        Intent intent = makeIntent(uri);
        boolean result = startActivity(intent);
        return result;
    }

    @NonNull
    private Intent makeIntent(Uri uri) {
        Intent intent = new Intent(NATIVE_ACTION);
        intent.setData(uri);
        intent.addCategory(NATIVE_CATEGORY);
//        intent.setPackage(AppRuntime.getContext().getPackageName());
        if (mLaunchFlag != 0) {
            intent.setFlags(mLaunchFlag);
        }

        intent.putExtra(KEY_NAVIGATOR_ORIGIN_URL, mOriginUrl);
        try {
            Set<String> keys = uri.getQueryParameterNames();
            if (keys != null) {
                for (String key : keys) {
                    String value = uri.getQueryParameter(key);
                    if (value != null) {
                        intent.putExtra(key, value);
                    }
                }
            }
        } catch (UnsupportedOperationException e) {
            e.printStackTrace();
        }
        return intent;
    }

    private boolean startActivity(Intent intent) {
        PackageManager packageManager = AppRuntime.getContext().getPackageManager();

        if (intent.resolveActivity(packageManager) != null) {
            Activity activity = ActivityManager.instance().getCurrentActivity();
            if (mRequestCode > 0) {
                if (activity != null) {
                    activity.startActivityForResult(intent, mRequestCode);
                    return true;
                } else {
                    LogUtils.e(TAG, "startActivityForResult error: activity is null");
                }
            } else {
                Context context = activity;
                if (context == null) {
                    context = AppRuntime.getContext();
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                }
                if (context != null) {
                    context.startActivity(intent);
                    return true;
                } else {
                    LogUtils.e(TAG, "startActivity error: context is null");
                }
            }
        }

        return false;
    }

    private Uri makeUri() {
        Uri uri = mUriBuilder.build();
        mOriginUrl = uri.toString();
        String scheme = uri.getScheme();
        if (scheme != null) {
            if (scheme.equals("http") || scheme.equals("https")) {
                Uri.Builder builder = Uri.parse(AppConfig.sAppSchema + "://inner.page/web").buildUpon();
                builder.appendQueryParameter("url", uri.toString());
                String title = uri.getQueryParameter("title");
                if (StringUtils.isNotEmpty(title)) {
                    builder.appendQueryParameter("title", title);
                }
                uri = builder.build();
            } else if (scheme.equals(AppConfig.sAppSchema)) {
                mUriBuilder.authority("inner.page");
                uri = mUriBuilder.build();
            }
        }
        return uri;
    }

    public static boolean openUrl(String url) {
        Navigator navigator = new Navigator();
        navigator.withUrl(url);
        return navigator.open();
    }


    public static Navigator withPage(@NonNull String pageName) {
        Navigator navigator = new Navigator();
        navigator.mUriBuilder = Uri.parse(AppConfig.sAppSchema + "://page/" + pageName).buildUpon();
        return navigator;
    }

    private void checkPageHasSet() {
        if (mUriBuilder == null) {
            throw new IllegalArgumentException("还未设置pageName");
        }
    }

    public Navigator addParameter(@NonNull String key, @NonNull String value) {
        checkPageHasSet();
        mUriBuilder.appendQueryParameter(key, value);
        return this;
    }

    public Navigator addParameter(@NonNull String key, @NonNull Number value) {
        checkPageHasSet();
        mUriBuilder.appendQueryParameter(key, value.toString());
        return this;
    }

    public Navigator addParameter(@NonNull String key, @NonNull Boolean value) {
        checkPageHasSet();
        mUriBuilder.appendQueryParameter(key, value.toString());
        return this;
    }


    public Navigator withUrl(@NonNull String fullUrl) {
        mUriBuilder = Uri.parse(fullUrl).buildUpon();
        return this;
    }

    public Navigator setLaunchFlag(int launchFlag) {
        mLaunchFlag = launchFlag;
        return this;
    }

    public Navigator setRequestCode(int requestCode) {
        mRequestCode = requestCode;
        return this;
    }

    private static ResolveInfo resolveActivity(Context context, String url) {
//        if (url != null && url.startsWith(NATIVE_PREFIX)) {
//            StringBuilder sb = new StringBuilder(url);
//            url = sb.insert("xxx://".length(), "xxxxx").toString();
//        } else {
//            return null;
//        }

        Intent intent = new Intent(NATIVE_ACTION);
        intent.addCategory(NATIVE_CATEGORY);
        intent.setData(Uri.parse(url));
        intent.setPackage(context.getPackageName());
        final ResolveInfo info = context.getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
        if (info == null) {
            //for some special permission-check phone, resolveActivity will return null.
            //so we use queryIntentActivities to check again.
            final List<ResolveInfo> list = context.getPackageManager().queryIntentActivities(intent,
                    PackageManager.MATCH_DEFAULT_ONLY);

            final ResolveInfo rinfo = ListUtils.isNotEmpty(list) ? list.get(0) : null;
            if (rinfo == null) {
                // throw new ActivityNotFoundException("No Activity found to handle " + intent);
                return null;
            }
            return rinfo;
        } else {
            return info;
        }
    }


    private static List<ResolveInfo> getActivityData() {
        Intent intent = new Intent(NATIVE_ACTION);
        intent.addCategory(NATIVE_CATEGORY);
        intent.setPackage(AppRuntime.getContext().getPackageName());
        PackageManager pm = AppRuntime.getContext().getPackageManager();
        List<ResolveInfo> list = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        return list;
    }

}
