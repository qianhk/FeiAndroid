package njnu.kai.framework;

import java.util.LinkedList;

/**
 * @version 1.0.0
 */
public class PageLifecycleHelper implements IPageLifecycle {

    private LinkedList<IPageLifecycle> mPageLifecycles = new LinkedList<>();

    /**
     * register lifecycle
     *
     * @param lifecycle lifecycle
     */
    public void register(IPageLifecycle lifecycle) {
        if (mPageLifecycles.contains(lifecycle)) {
            return;
        }
        mPageLifecycles.add(lifecycle);
    }

    /**
     * unregister lifecycle
     *
     * @param lifecycle lifecycle
     */
    public void unregister(IPageLifecycle lifecycle) {
        mPageLifecycles.remove(lifecycle);
    }

    public void clear() {
        mPageLifecycles.clear();
    }

    @Override
    public void onCreate() {
        for (IPageLifecycle lifecycle : mPageLifecycles) {
            lifecycle.onCreate();
        }
    }

    @Override
    public void onStart() {
        for (IPageLifecycle lifecycle : mPageLifecycles) {
            lifecycle.onStart();
        }
    }

    @Override
    public void onResume() {
        for (IPageLifecycle lifecycle : mPageLifecycles) {
            lifecycle.onResume();
        }
    }

    @Override
    public void onPause() {
        for (IPageLifecycle lifecycle : mPageLifecycles) {
            lifecycle.onPause();
        }
    }

    @Override
    public void onStop() {
        for (IPageLifecycle lifecycle : mPageLifecycles) {
            lifecycle.onStop();
        }
    }

    @Override
    public void onDestroy() {
        for (IPageLifecycle lifecycle : mPageLifecycles) {
            lifecycle.onDestroy();
        }
        clear();
    }

}
