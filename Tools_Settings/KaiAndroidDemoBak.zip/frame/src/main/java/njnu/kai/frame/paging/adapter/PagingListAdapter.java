package njnu.kai.framework.paging.adapter;

import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.List;

import me.drakeet.multitype.IPagingListAdapter;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public abstract class PagingListAdapter<T> extends BaseAdapter implements IPagingListAdapter<T> {

    protected List<T> mDataList;

    @Override
    public void clearData() {
        if (mDataList != null) {
            mDataList.clear();
            notifyDataSetChanged();
        }
    }

    @Override
    public void flushData(List<T> data) {
        clearData();
        if (data != null) {
            if (mDataList == null) {
                mDataList = new ArrayList<T>(data);
            } else {
                mDataList.addAll(data);
            }
        }
        notifyDataSetChanged();
    }

    @Override
    public void appendData(List<T> data) {
        if (mDataList == null) {
            flushData(data);
        } else {
            mDataList.addAll(data);
            notifyDataSetChanged();
        }
    }

    @Override
    public void removeData(T data) {
        if (mDataList != null) {
            mDataList.remove(data);
            notifyDataSetChanged();
        }
    }

//    @Override
//    public List<T> getAllData() {
//        return mDataList;
//    }

    @Override
    public T getItem(int position) {
        return mDataList.get(position);
    }

    @Override
    public int getCount() {
        return getRealCount();
    }

    @Override
    public int getRealCount() {
        return mDataList != null ? mDataList.size() : 0;
    }
}
