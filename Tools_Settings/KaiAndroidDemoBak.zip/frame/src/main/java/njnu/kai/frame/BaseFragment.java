package njnu.kai.framework;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import njnu.kai.AppRuntime;
import njnu.kai.framework.navigator.BundleParameter;
import njnu.kai.framework.navigator.IParameter;
import njnu.kai.utils.ViewUtils;

import com.umeng.analytics.MobclickAgent;

import java.util.List;

/**
 * BaseFragment.java
 * Copyright (c) 2015 james. All rights reserved.
 *
 * @version 1.0.0
 */
public class BaseFragment extends Fragment {

    private enum LoadState {
        NONE,
        DOING_ANIM,
        WAITING_PARENT,
        FINISHED
    }

    private static final int ANIMATION_END_DELAY = 100; //ms
    private LoadState mLoadState = LoadState.NONE;

    private View mBusinessView;

    private PageLifecycleHelper mPageLifecycleHelper;

    @Override
    public void onDestroy() {
        mPageLifecycleHelper.onDestroy();
        super.onDestroy();
    }

    @Override
    public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {
        if (enter) {
            try {
                if (nextAnim != 0) {
                    Animation anim = AnimationUtils.loadAnimation(getActivity(), nextAnim);
                    anim.setAnimationListener(new Animation.AnimationListener() {
                        public void onAnimationStart(Animation animation) {
                        }

                        public void onAnimationRepeat(Animation animation) {
                        }

                        public void onAnimationEnd(Animation animation) {
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (mLoadState == LoadState.DOING_ANIM) {
                                        BaseFragment.this.checkLoadFinished();
                                    }
                                }
                            }, ANIMATION_END_DELAY);
                        }
                    });
                    mLoadState = LoadState.DOING_ANIM;
                    return anim;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        } else {
            onExitAnimationStart();
        }
        return super.onCreateAnimation(transit, enter, nextAnim);
    }

    @Override
    public void onResume() {
        super.onResume();
        AppRuntime.sPageName = getClass().getSimpleName();
        if (mLoadState == LoadState.NONE) {
            checkLoadFinished();
        }
        mPageLifecycleHelper.onResume();

        if (AppRuntime.sUseUMeng) {
            String uiPageName = onGetUIPageName();
            if (uiPageName != null) {
                MobclickAgent.onPageStart(uiPageName);
            }
        }
    }

    public boolean isLoadFinished() {
        return mLoadState == LoadState.FINISHED;
    }

    protected void onLoadFinished() {
    }

    @Override
    public void onPause() {
        super.onPause();
        mPageLifecycleHelper.onPause();

        if (AppRuntime.sUseUMeng) {
            String uiPageName = onGetUIPageName();
            if (uiPageName != null) {
                MobclickAgent.onPageEnd(uiPageName);
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mPageLifecycleHelper.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        mPageLifecycleHelper.onStop();
    }

    protected String onGetUIPageName() {
        return null;
    }

    @Override
    public void onDetach() {
        ViewUtils.setBackgroundDrawable(mBusinessView != null ? mBusinessView : getView(), null);
        super.onDetach();
        mBusinessView = null;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPageLifecycleHelper = new PageLifecycleHelper();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setBusinessBackground(BackgroundDrawableManager.getInstance().getGlobalBackground());
        onRegisterPageLifecycle();
        mPageLifecycleHelper.onCreate();
    }

    /**
     * 设置一个放业务主体内容的view,用来统一处理背景等
     *
     * @param businessView businessView
     */
    protected void setBusinessView(View businessView) {
        mBusinessView = businessView;
    }

    /**
     * 设置一个背景图,为节省内存,此图应该各UI页面共用
     *
     * @param drawable 背景大图
     */
    public void setBusinessBackground(Drawable drawable) {
        ViewUtils.setBackgroundDrawable(mBusinessView, drawable);
    }

    /**
     * 退出动画开始
     */
    protected void onExitAnimationStart() {

    }

    private void onParentFragmentLaunchFinished() {
        if (mLoadState == LoadState.WAITING_PARENT) {
            checkLoadFinished();
        }
    }

    protected void checkLoadFinished() {
        if (isResumed() && getUserVisibleHint()) {
            BaseFragment parentFragment = (BaseFragment) getParentFragment();
            if (parentFragment == null || parentFragment.isLoadFinished()) {
                mLoadState = LoadState.FINISHED;

                BaseFragment.this.onLoadFinished();

                List<Fragment> fragments = getChildFragmentManager().getFragments();
                if (fragments != null) {
                    for (Fragment fragment : fragments) {
                        if (fragment instanceof BaseFragment) {
                            ((BaseFragment) fragment).onParentFragmentLaunchFinished();
                        }
                    }
                }
            } else {
                mLoadState = LoadState.WAITING_PARENT;
            }
        }
    }

    public void finish() {
        hideInputMethod();
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.finish();
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (mLoadState == LoadState.NONE) {
            checkLoadFinished();
        }
    }

    public void hideInputMethod() {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            View focusView = activity.getCurrentFocus();
            if (focusView == null) {
                focusView = activity.getWindow().getDecorView();
            }
            if (focusView != null) {
                InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(focusView.getWindowToken(), 0);
            }
        }
    }

    public void showInputMethod(EditText editText) {
        FragmentActivity activity = getActivity();
        if (activity != null && editText != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            editText.requestFocus();
            inputMethodManager.showSoftInput(editText, 0);
        }
    }

    protected void onRegisterPageLifecycle() {
    }

    final public void registerPageLifecycle(IPageLifecycle lifecycle) {
        mPageLifecycleHelper.register(lifecycle);
    }

    public void unregisterPageLifecycle(IPageLifecycle lifecycle) {
        mPageLifecycleHelper.unregister(lifecycle);
    }

    public long getArgumentId() {
        return getParams().getInt("id");
    }

    public IParameter getParams() {
        if (getArguments() == null) {
            return BundleParameter.from(new Bundle());
        }

        return BundleParameter.from(getArguments());
    }

}
