package njnu.kai.framework.paging;


import java.util.List;

import me.drakeet.multitype.BaseVO;
import njnu.kai.framework.BasePresenter;
import njnu.kai.utils.LogUtils;

public abstract class PagingListPresenter<VIEW extends IPagingListView & IRecyclerListView> extends BasePresenter<VIEW> {
    private static final String TAG = "PagingListPresenter";

    private static final int STATE_IDLE = 0;
    private static final int STATE_LOADING = 1;
    private static final int STATE_FAILED = 2;
    private static final int STATE_ALL_PAGE_LOADED = 3;

    protected static final int DEFAULT_PAGE_START = 1;

    private int mLoadingPage = DEFAULT_PAGE_START;
    private int mState = STATE_IDLE;

    protected PagingListPresenter(VIEW pageDataLoadingView) {
        super(pageDataLoadingView);
    }


    /**
     * 重新开始加载数据
     */
    public void reload() {
        reload(true);
    }

    void reload(boolean force) {
        if (isLoading()) {
            return;
        }
        mLoadingPage = DEFAULT_PAGE_START;
        loadNextPageInner(force, mLoadingPage);
    }

    /**
     *
     */
    void loadNextPage() {
        if (isLoading()) {
            return;
        }
        loadNextPageInner(false, mLoadingPage);
    }

    private void loadNextPageInner(boolean force, int loadPage) {
        mState = STATE_LOADING;

        if (loadPage == DEFAULT_PAGE_START) {
            if (!hasExtraData() && mBindView.isDataEmpty()) {
                mBindView.showLoading();
            }
        } else {
            mBindView.showNextPageLoading();
        }

        load(loadPage, force);
    }

    protected boolean isLoading() {
        return mState == STATE_LOADING;
    }

    /**
     * @param page  加载第几页
     * @param force 是否强制加载  强制加载即列表中有数据的时候, 否则是无数据的时候, 此参数这两年基本没用过, 为兼容保留
     */
    protected abstract void load(int page, boolean force);

    /**
     * @param dataList  当前加载成功的数据
     * @param totalPage 总页数
     * @param page      当前加载成功的页
     */
    protected void handleLoadSuccess(List dataList, int totalPage, int page) {
        mLoadingPage = page;

        if (mLoadingPage <= DEFAULT_PAGE_START) {
            mBindView.flushData(dataList);
            if (dataList == null || dataList.isEmpty()) {
                if (hasExtraData()) {
                    mBindView.showAllPageLoaded();
                    mBindView.showSuccess();
                } else {
                    mBindView.showNoData();
                }
                mState = STATE_ALL_PAGE_LOADED;
            } else {
                mBindView.showSuccess();
                ++mLoadingPage;

                if (mLoadingPage > totalPage) {
                    mState = STATE_ALL_PAGE_LOADED;
                    mBindView.showAllPageLoaded();
                } else {
                    mState = STATE_IDLE;
                    mBindView.showNextPageSuccess();
                }
            }
        } else {
            mBindView.appendData(dataList);

            if (totalPage > mLoadingPage) {
                mBindView.showNextPageSuccess();
                ++mLoadingPage;
                mState = STATE_IDLE;
            } else {
                mState = STATE_ALL_PAGE_LOADED;
                mBindView.showAllPageLoaded();
            }
        }
    }

    /**
     * @param e exception
     */
    protected void handleLoadFailure(Throwable e) {
        if (mLoadingPage <= DEFAULT_PAGE_START) {
            mBindView.flushData(null); //原来有数据的话要清除, 避免浪费内存
            mBindView.showFailure(e != null ? e.getMessage() : null);
        } else {
            mBindView.showNextPageFailure();
        }

        mState = STATE_FAILED;
    }

    /**
     * @return 除了列表中的数据,其他是否有算作不需要显示空白页的数据条数
     */
    protected boolean hasExtraData() {
        return false;
    }

    /**
     * @return 当前请求的面数
     */
    public int getLoadingPage() {
        return mLoadingPage;
    }

    public void setLoadingPage(int mLoadingPage) {
        this.mLoadingPage = mLoadingPage;
    }

    protected VIEW getView() {
        return mBindView;
    }

    boolean canAutoLoadNextPage() {
        return mState == STATE_IDLE || mState == STATE_FAILED;
    }

    /**
     * 重置加载状态
     */
    public void reset() {
        mState = STATE_IDLE;
        mLoadingPage = DEFAULT_PAGE_START;
    }

    protected BaseVO getItemDataByVoId(String voId) {
        return mBindView != null ? mBindView.getItemDataByVoId(voId) : null;
    }

    protected void handleVoUpdated(BaseVO baseVO) {
        if (mBindView != null) {
            mBindView.handleVoUpdated(baseVO);
        }
    }

    protected void handleVoRemoved(BaseVO baseVO) {
        if (mBindView != null) {
            mBindView.handleVoRemoved(baseVO);
        }
    }

    public void onMultiTypeViewClicked(BaseVO data, String action) {
        printActionLog("viewClicked", data, action);
    }

    public void onMultiTypeValueChanged(BaseVO data, String action) {
        printActionLog("valueChanged", data, action);
    }

    private void printActionLog(String type, BaseVO data, String action) {
        LogUtils.i(TAG, "lookMultiType %s vo=%s action=%s", type, data.getClass().getSimpleName(), action);
    }
}
