package njnu.kai.framework.tab;

import android.os.Bundle;
import androidx.viewpager.widget.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import njnu.kai.framework.R;
import njnu.kai.framework.BaseFragment;
import njnu.kai.uikit.FreezableViewPager;
import njnu.kai.framework.ActionBarLayoutFragment;
import njnu.kai.uikit.ActionBarLayout;
import njnu.kai.uikit.tab.BaseFragmentTabHost;
import njnu.kai.uikit.tab.LocalFragmentTabAdapter;
import njnu.kai.uikit.tab.LocalTabViewProperties;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseTabHostUseActionBarFragment extends ActionBarLayoutFragment implements ViewPager.OnPageChangeListener {

    protected BaseFragmentTabHost mTabHost;
    protected LocalFragmentTabAdapter mTabAdapter;
    protected FreezableViewPager mViewPager;

    @Override
    protected void onInitActionBar() {
        ActionBarLayout barController = getActionBarLayout();
        barController.setMode(ActionBarLayout.MODE_TAB);
        mTabHost = barController.getTabHost();

        mTabHost.setTabLayoutAverageSpace(true);
        mTabHost.setOnPageChangeListener(this);
        mTabAdapter = new LocalFragmentTabAdapter(getChildFragmentManager(), buildTabFragmentProperties());
        mViewPager.setAdapter(mTabAdapter);
        mViewPager.setOffscreenPageLimit(mTabAdapter.getCount());
        mTabHost.setViewPager(mViewPager, mTabAdapter);

//        mTabAdapter = new LocalFragmentTabAdapter(getChildFragmentManager(), buildTabFragmentProperties());
//        mViewPager.setAdapter(mTabAdapter);
//        mTabHost.setTabLayoutAverageSpace(false);
//        mTabHost.setViewPager(mViewPager, mTabAdapter);
//        mViewPager.setOffscreenPageLimit(mTabAdapter.getCount());
//        mTabHost.setOnPageChangeListener(this);

        setCurrentPosition(0);
    }

    @Override
    public final View onCreateContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mViewPager = new FreezableViewPager(inflater.getContext());
        mViewPager.setId(R.id.viewpager);
        return mViewPager;
    }

    private List<LocalTabViewProperties> buildTabFragmentProperties() {
        List<LocalTabViewProperties> tabViewPropertyList = new ArrayList<>();
        onBuildTabFragmentProperties(tabViewPropertyList);
        return tabViewPropertyList;
    }

    /**
     * 重载此方法构建需要显示的fragment页绑定器列表
     *
     * @param tabViewPropertyList fragment页绑定器列表
     */
    protected abstract void onBuildTabFragmentProperties(List<LocalTabViewProperties> tabViewPropertyList);

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        setCurrentPosition(position);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    private boolean isSlidingAtTheLeftEdge(int position) {
        return position == 0;
    }

    private boolean isSlidingAtTheRightEdge(int position) {
        return position == mTabAdapter.getCount() - 1;
    }

    private void setCurrentPosition(int position) {
//        int slidingMode = SlidingClosableRelativeLayout.SLIDING_CLOSE_MODE_NONE;
//        if (isSlidingAtTheLeftEdge(position)) {
//            slidingMode = SlidingClosableRelativeLayout.SLIDING_CLOSE_MODE_HORIZONTAL_RIGHT;
//        } else if (isSlidingAtTheRightEdge(position)) {
//            slidingMode = SlidingClosableRelativeLayout.SLIDING_CLOSE_MODE_HORIZONTAL_LEFT;
//        }
//
    }

    /**
     * @return current fragment
     */
    public BaseFragment currentFragment() {
        int currentItem = mViewPager.getCurrentItem();
        return (BaseFragment) mTabAdapter.getItem(currentItem);
    }

    public BaseFragment getFragment(int index) {
        return (BaseFragment) mTabAdapter.getItem(index);
    }

}
