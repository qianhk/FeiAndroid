package njnu.kai.framework.paging;

import java.util.List;

import me.drakeet.multitype.BaseVO;
import njnu.kai.framework.IView;

/**
 */
public interface IPagingListView extends IView {

    void flushData(List dataList);

    void appendData(List dataList);

    void showNextPageFailure();

    void showNextPageLoading();

    void showNextPageSuccess();

    void showLoading();

    void showAllPageLoaded();

    void showFailure(String message);

    void showSuccess();

    void showNoData();

    boolean isDataEmpty();
}
