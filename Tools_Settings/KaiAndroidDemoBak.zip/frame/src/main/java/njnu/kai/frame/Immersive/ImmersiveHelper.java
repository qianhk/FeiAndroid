package njnu.kai.framework.Immersive;

import android.app.Activity;

import njnu.kai.framework.R;

/**
 * @author kai
 * @version 1.0.0
 */
public class ImmersiveHelper {

    private ImmersiveObserver mImmersiveObserver;
    private ImmersiveOnApplyStyleListener mOnApplyStyleListener;

    /**
     * @param onApplyStyleListener listener
     */
    public ImmersiveHelper(ImmersiveOnApplyStyleListener onApplyStyleListener) {
        mOnApplyStyleListener = onApplyStyleListener;
    }

    /**
     * 应用沉浸式风格,建议用在fragment的onViewCreated里
     *
     * @param activity                   activity自身或者fragment所在的activity
     * @param onInitObserverViewListener listener
     */
    public void applyStyle(Activity activity, ImmersiveOnObserverInitedListener onInitObserverViewListener) {
        mImmersiveObserver = new ImmersiveObserver(activity.findViewById(R.id.view_immersive_observer));
        if (onInitObserverViewListener != null) {
            onInitObserverViewListener.onInitImmersiveObserver(mImmersiveObserver);
        }
        mImmersiveObserver.setOnApplyStyleListener(mOnApplyStyleListener);
        mImmersiveObserver.apply();
    }

    /**
     * view destroy时调用
     */
    public void onDestroyView() {
        if (mImmersiveObserver != null) {
            mImmersiveObserver.setOnApplyPaddingListener(null);
            mImmersiveObserver.setOnApplyStyleListener(null);
            mImmersiveObserver.removeOnLayoutChangeListener();
        }
    }

}
