package njnu.kai.framework.paging;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

import in.srain.cube.views.ptr.PtrFrameLayout;
import njnu.kai.BaseResult;
import njnu.kai.uikit.list.OnScrollListenerHelper;
import njnu.kai.framework.R;
import njnu.kai.framework.StateViewFragment;
import me.drakeet.multitype.IPagingListAdapter;
import njnu.kai.uikit.DataListFooterView;
import njnu.kai.uikit.StateView;
import njnu.kai.utils.ListViewUtils;
import njnu.kai.utils.ToastUtils;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public abstract class PagingListViewFragment<T, PRESENTER extends PagingListPresenter> extends StateViewFragment {

    private static final String TAG = "PagingListViewFragment";

    private PtrFrameLayout mPtrFrameLayout;
    private ListView mListView;
    private ViewGroup mLayoutPartBlankContainer;
    private ViewGroup mLayoutFooterBlankContainer;

    private IPagingListAdapter<T> mAdapter;

    private DataListFooterView mDataListFooterView;

    private DisplayHelper mDisplayHelper = new DisplayHelper();

    private OnScrollListenerHelper mOnScrollListenerHelper;

    protected PRESENTER mListPresenter;

    protected abstract IPagingListAdapter<T> onCreateAdapter(Context context);

    /**
     * ------------------    以下供派生类选择性的重载     --------------
     */

    protected void onListItemClick(int position, long id, T item, View view) {
    }

    protected boolean needItemClickEvent() {
        return true;
    }

    protected boolean needItemLongClickEvent() {
        return false;
    }

    protected boolean onListItemLongClick(int position, long id, T item, View view) {
        return false;
    }

    protected View onCreateHeaderView(LayoutInflater inflater, ListView listView) {
        return null;
    }

    protected View onCreateFooterView(LayoutInflater inflater, ListView listView) {
        return null;
    }

    protected List<T> onReloadCacheData() {
        return null;
    }

//    @Override
//    public void onStartLoadData(final int page) {
//        if (page != Pager.DEFAULT_PAGE_START && mDataListFooterView != null) {
//            mDataListFooterView.showLoadingAnim();
//        }
//    }

    /**
     * 用来显示在列表底部,当前共有xxx首歌曲 xx张专辑 xx位歌手,鉴于新app ui设计还不确定,先默认支持
     *
     * @param count 当前有多少条数据
     * @return 列表尾巴描述文字
     */
    protected CharSequence lastPageFooterText(int count) {
        return String.format("共%d条数据", count);
    }

    /**
     * @return 当没有更多数据时是否显示没有更多数据了或者共xx条数据
     */
    protected boolean needNoMoreDataFooterText() {
        return true;
    }

    /**
     * 自定义包装layout，必须有id为listview的ListView
     *
     * @return layout resource id
     */
    protected int listViewLayoutId() {
        return R.layout.common_listview;
    }

    protected void onContentViewInflated(View contentView) {
    }

    /**
     * @return 是否需要显示加载状态的自定义view
     */
    protected boolean needNumberFooterView() {
        return true;
    }

    /**
     * ------------------    供派生类重载   end  --------------
     */


    private AdapterView.OnItemClickListener mOnItemClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            position = ListViewUtils.getValidListViewItemPosition(mListView.getHeaderViewsCount(), position, mAdapter.getCount());
            if (position >= 0) {
                T item = mAdapter.getItem(position);
                onListItemClick(position, id, item, view);
            }
        }
    };

    private AdapterView.OnItemLongClickListener mOnItemLongClickListener = new AdapterView.OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
            position = ListViewUtils.getValidListViewItemPosition(mListView.getHeaderViewsCount(), position, mAdapter.getCount());
            return position >= 0 && onListItemLongClick(position, id, mAdapter.getItem(position), view);
        }
    };

    @Override
    protected final View onCreateContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View mainView = inflater.inflate(listViewLayoutId(), container, false);
        mPtrFrameLayout = (PtrFrameLayout) mainView.findViewById(R.id.ptr_frame_layout);
        mListView = (ListView) mainView.findViewById(R.id.listview);
//        mLayoutPartBlankContainer = (ViewGroup) mainView.findViewById(R.id.layout_part_blank_container);
//        if (mLayoutPartBlankContainer != null) {
//            mLayoutPartBlankContainer.setVisibility(View.GONE);
//        }
        mOnScrollListenerHelper = new OnScrollListenerHelper(mListView);
        onContentViewInflated(mainView);
        View headerView = onCreateHeaderView(inflater, mListView);
        if (headerView != null) {
            mListView.addHeaderView(headerView, mListView, false);
        }
        View footerView = onCreateFooterView(inflater, mListView);
        if (footerView != null) {
            mListView.addFooterView(footerView, null, false);
        }
        if (needNumberFooterView()) {
            mDataListFooterView = new DataListFooterView(getActivity());
            mListView.addFooterView(mDataListFooterView, null, false);
        }
        mLayoutFooterBlankContainer = new FrameLayout(inflater.getContext());
        mListView.addFooterView(mLayoutFooterBlankContainer, null, false);
        mAdapter = onCreateAdapter(inflater.getContext());
        mListView.setAdapter((ListAdapter) mAdapter);
        if (needItemClickEvent()) {
            mListView.setOnItemClickListener(mOnItemClickListener);
        }
        if (needItemLongClickEvent()) {
            mListView.setOnItemLongClickListener(mOnItemLongClickListener);
        }
        return mainView;
    }

    protected void refreshComplete() {
        mPtrFrameLayout.refreshComplete();
    }

    public DisplayHelper getDisplayHelper() {
        return mDisplayHelper;
    }

    public void addOnScrollListener(AbsListView.OnScrollListener listener) {
        mOnScrollListenerHelper.addOnScrollListener(listener);
    }

    public void removeOnScrollListener(AbsListView.OnScrollListener listener) {
        mOnScrollListenerHelper.removeOnScrollListener(listener);
    }

//    public void onLoadDataComplete(int page, boolean success) {
//        if (mDataListFooterView != null && page != Pager.DEFAULT_PAGE_START) {
//            if (success) {
//                mDataListFooterView.hide();
//            } else {
//                mDataListFooterView.showLoadFailText();
//                mDataListFooterView.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        mDataListFooterView.showLoadingAnim();
//                        mPagingHelper.prepareReloadData(-1, false);
//                    }
//                });
//            }
//        }
//    }

//    @Override
//    public void onNoMoreData() {
//        if (mDataListFooterView != null) {
//            if (needNoMoreDataFooterText()) {
//                mDataListFooterView.showLastPageText(lastPageFooterText(getRealCount()));
//            } else {
//                mDataListFooterView.hide();
//            }
//        }
//    }

    protected boolean needAutoSateView() {
        return true;
    }

    public void hideFooterView() {
        if (mDataListFooterView != null) {
            mDataListFooterView.hide();
        }
    }

    @Override
    protected final void onStateViewRetryRequested() {
//        setStateViewState(StateView.State.LOADING);
//        mPagingHelper.prepareReloadData(Pager.DEFAULT_PAGE_START, false);
        mListPresenter.reload(false);
    }

    protected boolean enterAutoLoading() {
        return true;
    }

    @Override
    protected final StateView.State originalState() {
        return enterAutoLoading() ? StateView.State.LOADING : StateView.State.SUCCESS;
    }

    protected ListView getListView() {
        return mListView;
    }

    protected PtrFrameLayout getPtrFrameLayout() {
        return mPtrFrameLayout;
    }

    public boolean checkCanDoRefresh() {
        return true;
    }


    @Override
    protected void onLoadFinished() {
        super.onLoadFinished();
        if (enterAutoLoading()) {
            mListPresenter.reload(false);
        }
    }

    private View mPartNoDataView;

    protected View getPartNoDataView(ViewGroup parent) {
        return null;
    }

    protected void onConfigPartNoDataView(View view) {

    }

    /**
     * @return 除了列表中的数据, 其他算作不需要显示空白页的数据条数, 大于0则算取数据成功
     */
    protected boolean hasExtraData() {
        return false;
    }

    private static final boolean USE_FOOTER_VIEW = true;

    public void onStateChanged(StateView.State state, int code) {
        if (state == StateView.State.NO_DATA) {
            if (hasExtraData()) {
                state = StateView.State.SUCCESS;
            } else {
                if (mPartNoDataView == null) {
                    if (USE_FOOTER_VIEW) {
                        mPartNoDataView = getPartNoDataView(mLayoutFooterBlankContainer);
                    } else {
                        mPartNoDataView = getPartNoDataView(mLayoutPartBlankContainer);
                    }
                    if (mPartNoDataView != null) {
                        if (USE_FOOTER_VIEW) {
                            mLayoutFooterBlankContainer.addView(mPartNoDataView);
                        } else {
                            mLayoutPartBlankContainer.addView(mPartNoDataView);
                        }
                    }
                }
                if (mPartNoDataView != null) {
                    onConfigPartNoDataView(mPartNoDataView);
                    if (USE_FOOTER_VIEW) {
                        mPartNoDataView.setVisibility(View.VISIBLE);
                    } else {
                        mLayoutPartBlankContainer.setVisibility(View.VISIBLE);
                    }
                    setStateViewState(StateView.State.SUCCESS);
                    return;
                }
            }
        } else {
            if (USE_FOOTER_VIEW) {
                if (mPartNoDataView != null) {
                    mPartNoDataView.setVisibility(View.GONE);
                }
            } else {
                mLayoutPartBlankContainer.setVisibility(View.GONE);
            }
        }

        if (needAutoSateView()) {
            if (mAdapter != null && mAdapter.getRealCount() > 0) {
                if (state == StateView.State.FAILED) {
                    ToastUtils.showToast(R.string.load_data_failed);
                } else if (state == StateView.State.NO_NETWORK) {
                    ToastUtils.showToast(R.string.load_data_failed_no_network);
                } else {
                    dealSetStateAndChangeTextWenFailed(state, code);
                }
            } else {
                dealSetStateAndChangeTextWenFailed(state, code);
            }
        }
    }

    private void dealSetStateAndChangeTextWenFailed(StateView.State state, int code) {
        setStateViewState(state);
        if (state == StateView.State.FAILED) {
            View failedView = getStateView().getStateView(StateView.State.FAILED);
//                    IconTextView failedIconTextView = (IconTextView) failedView.findViewById(R.id.itv_icon);
            TextView failedTextView = (TextView) failedView.findViewById(R.id.tv_text);
            if (failedTextView != null) {
                if (code == BaseResult.UNABLE_PARSE_DATA) {
                    failedTextView.setText(R.string.load_failed_parse_error);
                } else {
                    failedTextView.setText(R.string.load_failed);
                }
            }
        }
    }

    public void notifyDataSetChanged() {
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    public int getRealCount() {
        return mAdapter != null ? mAdapter.getRealCount() : 0;
    }

    public T getFirstItem() {
        return mAdapter != null && mAdapter.getRealCount() > 0 ? mAdapter.getItem(0) : null;
    }

//    public List<T> getAllData() {
//        return mAdapter != null ? mAdapter.getAllData() : null;
//    }

}
