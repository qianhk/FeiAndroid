package njnu.kai.framework.navigator;

import android.content.Intent;
import androidx.collection.ArrayMap;

import java.util.Map;
import java.util.Set;

public class IntentParameter implements IParameter {

    private static final String TAG = "IntentParameter";
    private Intent mIntent;

    private IntentParameter(Intent intent) {
        mIntent = intent;
    }

    public static IntentParameter from(Intent intent) {
        assert intent != null;
        return new IntentParameter(intent);
    }

    @Override
    public int getInt(String key) {
        try {
            return Integer.parseInt(mIntent.getStringExtra(key));
        } catch (Exception e) {
            try {
                return mIntent.getIntExtra(key, 0);
            } catch (Exception e1) {
            }
            return 0;
        }
    }

    public int getInt(String key, int defaultValue) {
        try {
            return Integer.parseInt(mIntent.getStringExtra(key));
        } catch (Exception e) {
            try {
                return mIntent.getIntExtra(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }

    @Override
    public long getLong(String key) {
        try {
            return Long.parseLong(mIntent.getStringExtra(key));
        } catch (Exception e) {
            try {
                return mIntent.getLongExtra(key, 0);
            } catch (Exception e1) {
            }
            return 0;
        }
    }

    public long getLong(String key, long defaultValue) {
        try {
            return Long.parseLong(mIntent.getStringExtra(key));
        } catch (Exception e) {
            try {
                return mIntent.getLongExtra(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }


    public float getFloat(String key, float defaultValue) {
        try {
            return Float.parseFloat(mIntent.getStringExtra(key));
        } catch (Exception e) {
            try {
                return mIntent.getFloatExtra(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }


    public double getDouble(String key, double defaultValue) {
        try {
            return Double.parseDouble(mIntent.getStringExtra(key));
        } catch (Exception e) {
            try {
                return mIntent.getDoubleExtra(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        try {
            return Boolean.parseBoolean(mIntent.getStringExtra(key));
        } catch (Exception e) {
            try {
                return mIntent.getBooleanExtra(key, defaultValue);
            } catch (Exception e1) {
            }
            return defaultValue;
        }
    }

    @Override
    public String getString(String key, String defaultValue) {
        if (mIntent.hasExtra(key)) {
            try {
                return mIntent.getStringExtra(key);
            } catch (Exception e) {
                return defaultValue;
            }
        } else {
            return defaultValue;
        }
    }

    @Override
    public Map<String, String> getParameters() {
        try {
            Set<String> keys = mIntent.getExtras().keySet();
            Map<String, String> parameterMap = new ArrayMap<>(keys.size());
            for (String key : keys) {
                parameterMap.put(key, getString(key, ""));
            }
            return parameterMap;
        } catch (Exception e) {
            return new ArrayMap<>();
        }
    }

}
