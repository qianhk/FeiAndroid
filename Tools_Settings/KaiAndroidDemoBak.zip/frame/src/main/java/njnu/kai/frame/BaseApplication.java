package njnu.kai.framework;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Handler;
import android.os.Process;

import com.umeng.analytics.MobclickAgent;

import njnu.kai.AppConfig;
import njnu.kai.AppRuntime;
import njnu.kai.framework.exception.ExceptionReporter;
import njnu.kai.utils.DebugUtils;
import njnu.kai.utils.DisplayUtils;
import njnu.kai.utils.LogUtils;
import njnu.kai.utils.StringUtils;

import java.util.List;

/**
 * @author kai
 * @version 1.0.0
 */
public abstract class BaseApplication extends Application {
    private final static String TAG = "BaseApplication";
    private static final int KILL_SELF_DELAY = 300; //ms
    private static BaseApplication sApp = null;

    @TargetApi(Build.VERSION_CODES.GINGERBREAD)
    @Override
    public final void onCreate() {
        super.onCreate();

        String logPrefix = logPrefix();
        LogUtils.setPrefix(logPrefix + ":");

        String processName = _getProcessName();
        String packageName = getPackageName();
        if (!packageName.equals(processName)) {
            if (processName != null) {
                if (processName.endsWith("remote")) {
                    //某某sdk的进程
                }
            }
            return;
        }

        sApp = this;
        AppRuntime.init(this);

        try {
            ApplicationInfo appInfo = getPackageManager().getApplicationInfo(packageName, PackageManager.GET_META_DATA);
            String umengAppkey = appInfo.metaData.getString("UMENG_APPKEY");
            AppRuntime.sUseUMeng = StringUtils.isNotEmpty(umengAppkey);
        } catch (Exception e) {
            DebugUtils.doNothing();
        }


        AppConfig.init(this, logPrefix, true);
        DisplayUtils.init(this);
        LogUtils.setEnable(AppRuntime.Config.isLogEnable());
        LogUtils.setLogFileFolder(AppConfig.getLogFolderPath(), logPrefix);

//        if (EnvironmentUtils.Config.isLogEnable() && SDKVersionUtils.hasGingerbread() && EnvironmentUtils.Config.isTestMode()) {
//            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build());
//            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectAll().penaltyLog().build());
//        }

//        LogUtils.setWriteToFile(EnvironmentUtils.Config.isTestMode());

        ExceptionReporter.init(logPrefix);

        if (AppRuntime.sUseUMeng) {//再次以activity页面为主
            MobclickAgent.openActivityDurationTrack(false);
        }
        onAppCreated();
    }

    abstract protected void onAppCreated();

    abstract protected String logPrefix();

    /**
     * 获取Application实例
     *
     * @return Application 实例
     */
    public static BaseApplication getApp() {
        return sApp;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        DisplayUtils.onConfigurationChanged(this, newConfig);
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
//        ImageLoader.notifyMemoryLow();
    }

    /**
     * 退出应用程序，杀死主进程
     */
    public void exit() {
        if (AppRuntime.sUseUMeng) {
            MobclickAgent.onKillProcess(this);
        }
        njnu.kai.framework.ActivityManager.instance().finishActivities();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        }, KILL_SELF_DELAY);
    }

    private String _getProcessName() {
        int myPid = Process.myPid();
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<RunningAppProcessInfo> runningAppProcessInfoList = activityManager.getRunningAppProcesses();
        if (runningAppProcessInfoList != null) {
            for (RunningAppProcessInfo appProcessInfo : runningAppProcessInfoList) {
                if (myPid == appProcessInfo.pid) {
                    return appProcessInfo.processName;
                }
            }
        }
        return null;
    }
}
