package njnu.kai.framework.Immersive;

import android.view.View;

/**
 */
public interface ImmersiveOnObserverCreatedListener {
    public void onImmersiveViewObserverCreated(View observerView);
}
