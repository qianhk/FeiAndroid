package njnu.kai.framework;

import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;

import njnu.kai.AppRuntime;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public class BackgroundDrawableManager {

    private static BackgroundDrawableManager sManager;
    private static final Object[] SYNC_OBJECT = new Object[0];

    private static Drawable sDrawable;

    public static BackgroundDrawableManager getInstance() {
        if (sManager == null) {
            synchronized (SYNC_OBJECT) {
                if (sManager == null) {
                    sManager = new BackgroundDrawableManager();
                }
            }
        }
        return sManager;
    }

    private BackgroundDrawableManager() {
    }

    public static void setDrawable(Drawable drawable) {
        sDrawable = drawable;
    }

    public Drawable getGlobalBackground() {
        if (sDrawable == null) {
            Resources resources = AppRuntime.getContext().getResources();
            sDrawable = new ColorDrawable(resources.getColor(R.color.normal_background));
        }
        return sDrawable;
    }
}
