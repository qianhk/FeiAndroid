package njnu.kai.framework.Immersive;

/**
 * @version 1.0.0
 *
 */
public interface ImmersiveOnApplyStyleListener {
    /**
     * 是否需要处理沉浸模式下的状态栏
     * @return true if yes
     */
    public boolean needApplyStatusBarStyle();
    /**
     * 是否需要处理沉浸模式下的导航栏
     * @return true if yes
     */
    public boolean needApplyNavigationBarStyle();
}
