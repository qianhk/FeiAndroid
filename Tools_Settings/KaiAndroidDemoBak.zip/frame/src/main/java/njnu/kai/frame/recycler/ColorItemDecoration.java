package njnu.kai.framework.recycler;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public class ColorItemDecoration extends RecyclerView.ItemDecoration {

    private static final String TAG = "ColorItemDecoration";

    public static final int HORIZONTAL_LIST = LinearLayoutManager.HORIZONTAL;

    public static final int VERTICAL_LIST = LinearLayoutManager.VERTICAL;

    private ColorDrawable mColorDrawable;

    private int mSize;

    private int mOrientation;

    private boolean mNeedTopLeft = true;

    public ColorItemDecoration(int color, int size, int orientation) {
        if (color != Color.TRANSPARENT) {
            mColorDrawable = new ColorDrawable(color);
        }
        mSize = size;
        setOrientation(orientation);
    }

    public void setOrientation(int orientation) {
        if (orientation != HORIZONTAL_LIST && orientation != VERTICAL_LIST) {
            throw new IllegalArgumentException("invalid orientation");
        }
        mOrientation = orientation;
    }

    public boolean isNeedTopLeft() {
        return mNeedTopLeft;
    }

    public void setNeedTopLeft(boolean needTopLeft) {
        mNeedTopLeft = needTopLeft;
    }

    @Override
    public void onDraw(Canvas canvas, RecyclerView parent, RecyclerView.State state) {
        if (mColorDrawable != null) {
            if (mOrientation == VERTICAL_LIST) {
                drawVertical(canvas, parent);
            } else {
                drawHorizontal(canvas, parent);
            }
        }
    }

    public void drawVertical(Canvas c, RecyclerView parent) {
        final int left = parent.getPaddingLeft();
        final int right = parent.getWidth() - parent.getPaddingRight();

        final int childCount = parent.getChildCount();
        for (int idx = 0; idx < childCount; idx++) {
            final View childView = parent.getChildAt(idx);
            final RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) childView.getLayoutParams();
            final int top = childView.getBottom() + params.bottomMargin;
            final int bottom = top + mSize;
            mColorDrawable.setBounds(left, top, right, bottom);
            mColorDrawable.draw(c);
        }
    }

    public void drawHorizontal(Canvas c, RecyclerView parent) {
        final int top = parent.getPaddingTop();
        final int bottom = parent.getHeight() - parent.getPaddingBottom();

        final int childCount = parent.getChildCount();
        for (int idx = 0; idx < childCount; idx++) {
            final View childView = parent.getChildAt(idx);
            int adapterPosition = parent.getChildAdapterPosition(childView);
//            LogUtils.e(TAG, "lookDecoration drawHorizontal viewIndex=%d adapterIndex=%d", idx, adapterPosition);
            final RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) childView.getLayoutParams();
            int left = childView.getRight() + params.rightMargin;
            final int right = left + mSize;
            mColorDrawable.setBounds(left, top, right, bottom);
            mColorDrawable.draw(c);
            if (adapterPosition == 0) {
                left = childView.getLeft() - params.leftMargin - mSize;
                mColorDrawable.setBounds(left, top, left + mSize, bottom);
                mColorDrawable.draw(c);
            }
        }
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        int position = parent.getChildAdapterPosition(view);
//        LogUtils.e(TAG, "lookDecoration getItemOffsets position=%d", position);
        if (mOrientation == VERTICAL_LIST) {
            outRect.set(0, 0, 0, mSize);
        } else {
            outRect.set((position == 0 && mNeedTopLeft) ? mSize : 0, 0, mSize, 0);
        }
    }
}
