package njnu.kai.framework.exception;

public class ExceptionReportAPI {

    /**
     * 错误名称
     */
    public static final String KEY_EXCEPTION_NAME = "name";
    /**
     * 包名
     */
    public static final String KEY_PACKAGE_NAME = "package";
    /**
     * 错误时间
     */
    public static final String KEY_EXCEPTION_TIME = "time";
    /**
     * 版本号
     */
    public static final String KEY_VERSION = "v";
    /**
     * 渠道号
     */
    public static final String KEY_CHANNEL = "f";
    /**
     * 平台号
     */
    public static final String KEY_S = "s";
    /**
     * 构建版本号
     */
    public static final String KEY_BUILD_ID = "build";
    /**
     * 手机名称
     */
    public static final String KEY_MID = "mid";
    /**
     * Android版本号
     */
    public static final String KEY_SPLUS = "splus";
    /**
     * rom名称
     */
    public static final String KEY_ROM = "rom";
    /**
     * 内存使用状态
     */
    public static final String KEY_MEMORY = "memory";
    /**
     * 错误详细信息
     */
    public static final String KEY_MESSAGE = "message";
    private static final String URL_MAIN = "http://127.0.0.1/bug";
    private static final String METHOD_SEND = "bug";
    private static final String NAME_FORM_DATA = "json_bug";

//    /**
//     * 发送崩溃消息
//     *
//     * @param params 要发送的参数
//     * @return 返回BaseResult
//     */
//    public static Request<BaseResult> send(HashMap<String, Object> params) {
//        try {
//            return new PostMethodRequest<BaseResult>(BaseResult.class, URL_MAIN, METHOD_SEND)
//                .addPostContent(NAME_FORM_DATA, getJsonFromMap(params).toString());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//    /**
//     * HashMap转化为JSON对象
//     *
//     * @param arguments 要处理的hashmap
//     * @return 返回生成的JSON对象
//     * @throws org.json.JSONException
//     */
//    private static JSONObject getJsonFromMap(HashMap<String, Object> arguments) throws JSONException {
//        JSONObject jsonObject = new JSONObject();
//        if (arguments.size() > 0) {
//            for (String key : arguments.keySet()) {
//                jsonObject.put(key, arguments.get(key));
//            }
//        }
//        return jsonObject;
//    }
}
