package njnu.kai.framework.paging;


import njnu.kai.utils.ListUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public class DisplayHelper {

    private List<Boolean> mDisplayFlag = new ArrayList<>();

    /**
     * @param data data
     */
    public void setData(List data) {
        mDisplayFlag.clear();
        if (ListUtils.isNotEmpty(data)) {
            for (int idx = data.size() - 1; idx >= 0; --idx) {
                mDisplayFlag.add(false);
            }
        }
    }

    /**
     * @param data data
     */
    public void append(List data) {
        if (data != null && data.size() != 0) {
            for (int idx = data.size() - 1; idx >= 0; --idx) {
                mDisplayFlag.add(false);
            }
        }
    }

    /**
     */
    public void clearData() {
        mDisplayFlag.clear();
    }

    /**
     * @param position position
     * @return first display
     */
    public boolean firstDisplay(int position) {
        return !hasDisplay(position);
    }

    private boolean hasDisplay(int position) {
        if (0 <= position && position < mDisplayFlag.size()) {
            Boolean display = mDisplayFlag.get(position);
            if (display == null || !display) {
                mDisplayFlag.set(position, true);
            }
            return display;
        }
        return true;
    }

    /**
     * @param location location
     */
    public void remove(int location) {
        mDisplayFlag.remove(location);
    }
}
