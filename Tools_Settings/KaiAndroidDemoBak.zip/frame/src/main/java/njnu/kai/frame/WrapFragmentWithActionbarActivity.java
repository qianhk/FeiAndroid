package njnu.kai.framework;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import njnu.kai.network.executor.TaskScheduler;
import njnu.kai.utils.LogUtils;
import njnu.kai.utils.StringUtils;

/**
 * @author kai
 * @version 1.0.0
 */
public class WrapFragmentWithActionbarActivity extends ActionBarLayoutActivity {
    private static final String TAG = "WrapFragmentActionBarActivity";
    private BaseFragment mWrapFragment;

    /**
     * 嵌套的fragment完整class name
     */
    public static final String KEY_CLASS_NAME = "key_class_name";

    /**
     * 标题栏标题文本
     */
    public static final String KEY_ACTIONBAR_TITLE = "key_actionbar_title";

    /**
     * @return 包装的是哪个fragment
     */
    protected Class<? extends BaseFragment> wrapFragmentClass() {
        return null;
    }

    /**
     * @return 标题
     */
    protected String getActionBarTitle() {
        return null;
    }

    /**
     * @return 标题资源id
     */
    protected int getActionBarTitleResourceId() {
        return 0;
    }

    @Override
    protected View onCreateContentView(LayoutInflater inflater, ViewGroup container, Bundle bundle) {
        View root = inflater.inflate(R.layout.common_activity_empty, container, false);

        Class<?> clazz = null;
        final Intent intent = getIntent();
        if (intent.hasExtra(KEY_CLASS_NAME)) {
            try {
                clazz = Class.forName(intent.getStringExtra(KEY_CLASS_NAME));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (clazz == null) {
            clazz = wrapFragmentClass();
        }
        try {
            mWrapFragment = (BaseFragment) clazz.newInstance();
            Bundle argument = getIntent().getExtras();
            if (argument == null) {
                argument = new Bundle();
            }
            mWrapFragment.setArguments(argument);
            getSupportFragmentManager().beginTransaction().add(R.id.layout_activity_container, mWrapFragment).commitAllowingStateLoss();

        } catch (Exception e) {
            e.printStackTrace();
            LogUtils.e(TAG, "Error: 嵌套的class必须继承自BaseFragment");
//            ToastUtils.showToast("Error: 嵌套的class必须是BaseFragment");
            TaskScheduler.execute(() -> null, result -> setTitle("嵌套的class必须继承自BaseFragment"));
        }

        return root;
    }

    @Override
    protected void onInitActionBar() {
        super.onInitActionBar();
        String actionBarTitle = getActionBarTitle();
        if (StringUtils.isEmpty(actionBarTitle)) {
            int titleResId = getActionBarTitleResourceId();
            final Intent intent = getIntent();
            if (titleResId != 0) {
                setTitle(titleResId);
            } else if (intent.hasExtra(KEY_ACTIONBAR_TITLE)) {
                setTitle(intent.getStringExtra(KEY_ACTIONBAR_TITLE));
            }
        } else {
            setTitle(actionBarTitle);
        }
    }

    protected BaseFragment getWrapFragment() {
        return mWrapFragment;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mWrapFragment != null) {
            mWrapFragment.onActivityResult(requestCode & 0xffff, resultCode, data);
        }
    }

    public static void launch(Activity activity, Class fragmentClazz, String title) {
        Intent intent = new Intent(activity, WrapFragmentWithActionbarActivity.class);
        intent.putExtra(KEY_CLASS_NAME, fragmentClazz.getCanonicalName());
        intent.putExtra(KEY_ACTIONBAR_TITLE, title);
        activity.startActivity(intent);
    }
}
