package njnu.kai.framework.exception;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

import njnu.kai.dialog.OnButtonClickListener;
import njnu.kai.dialog.base.BaseDialog;
import njnu.kai.dialog.message.MessageDialog;
import njnu.kai.utils.ToastUtils;
import njnu.kai.framework.R;

/**
 * bug send activity
 *
 * @version 1.0.0
 */
public class ExceptionSendActivity extends Activity {

    private BaseDialog mBaseDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        final String subject = this.getIntent().getCharSequenceExtra(Intent.EXTRA_SUBJECT).toString();
        final String detail = this.getIntent().getCharSequenceExtra(Intent.EXTRA_TEXT).toString();
        final String logName = this.getIntent().getCharSequenceExtra(Intent.EXTRA_SHORTCUT_NAME).toString();

        try {
            MessageDialog.Builder builder = new MessageDialog.Builder(this);
            builder.setMessage(R.string.exception_content);
            builder.setTitle(R.string.exception_title);
            builder.setPositiveTitle(R.string.exception_send);
            builder.setCancelable(false);
            builder.setPositiveListener(new OnButtonClickListener<MessageDialog>() {
                @Override
                public void onClick(MessageDialog result) {
                    ExceptionSendActivity.this.finish();
                    ExceptionReporter.report(subject, detail, logName, new ExceptionReporter.OnRequestFinishedListener() {
                        @Override
                        public void onRequestFinishedEvent(boolean isSuccess) {
                            ToastUtils.showToast(isSuccess
                                    ? R.string.exception_send_success : R.string.exception_send_failure);
                        }
                    });
                    System.exit(0);
                }
            });
            builder.setNegativeListener(new OnButtonClickListener<MessageDialog>() {
                @Override
                public void onClick(MessageDialog result) {
                    ExceptionSendActivity.this.finish();
                    System.exit(0);
                }
            });
            mBaseDialog = builder.build();
            mBaseDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
            finish();
            System.exit(0);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mBaseDialog != null && mBaseDialog.isShowing()) {
            mBaseDialog.dismiss();
            mBaseDialog = null;
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, R.anim.uikit_fade_out_middle_time);
    }
}
