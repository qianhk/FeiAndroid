package njnu.kai.framework;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;

import njnu.kai.utils.ConstantUtils;
import njnu.kai.utils.LogUtils;
import njnu.kai.utils.StringUtils;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Activity的管理
 *
 * @author kai
 * @version 1.0.0
 */
public class ActivityManager {

    /**
     * 保存在栈里的所有Activity
     */
    private List<Activity> mActivities = new ArrayList<Activity>();
    /**
     * 当前显示的Activity
     */
    private Activity mCurrentActivity = null;
    /**
     * 栈顶Activity
     */
    private Activity mLastActivity = null;
    /**
     * 栈顶Activity的上一个activity，解决跳转到其他应用回来以后LastActivity和CurrentActivity是一样的问题
     */
    private Activity mSavedLastActivity = null;

    private static ActivityManager sInstance;

    private static List<String> sActivityLifeTrace = new ArrayList<String>();

    private static final String TAG = "ActivityManager";

    /**
     * 获取ActivityManager实例
     *
     * @return ActivityManager实例
     */
    public static ActivityManager instance() {
        if (sInstance == null) {
            sInstance = new ActivityManager();
        }
        return sInstance;
    }

    /**
     * 当Activity执行onCreate时调用 - 保存启动的Activity
     *
     * @param activity 执行onCreate的Activity
     */
    public void onCreate(Activity activity) {
        mActivities.add(activity);
        recordActivityTrace(activity, "onCreate");
    }

    /**
     * 当Activity执行onDestroy时调用 - 移除销毁的Activity
     *
     * @param activity 执行onDestroy时的Activity
     */
    public void onDestroy(Activity activity) {
        if (mLastActivity == activity) {
            mLastActivity = null;
        }

        if (mSavedLastActivity == activity) {
            mSavedLastActivity = null;
        }

        mActivities.remove(activity);
        recordActivityTrace(activity, "onDestroy");
    }

    /**
     * 关闭所有activity
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void finishActivities() {
        LogUtils.d(TAG, "will exit app, finishActivities");
        for (Activity activity : mActivities) {
            activity.setResult(Activity.RESULT_CANCELED);
            activity.finishAffinity();
        }
        mActivities.clear();
    }

    /**
     * 当Activity执行onResume时调用 - 保存当前显示的activity，更新栈顶Activity
     *
     * @param activity 执行onResume的Activity
     */
    public void onResume(Activity activity) {
        mCurrentActivity = activity;

        //如果LastActivity和CurrentActivity相同，则说明是从其他应用返回来，此时LastActivity应该取前一次的Activity，否则和当前Activity是一个
        if (mLastActivity == activity) {
            mLastActivity = mSavedLastActivity;
        }

        recordActivityTrace(activity, "onResume");
    }

    /**
     * 当Activity执行onPause时调用 - 清除当前显示的Activity
     *
     * @param activity 执行onPause的Activity
     */
    public void onPause(Activity activity) {
        mSavedLastActivity = mLastActivity;
        mLastActivity = activity;

        recordActivityTrace(activity, "onPause");
    }

    /**
     * 获取当前显示的Activity
     *
     * @return 当前显示的Activity，可能为空
     */
    public Activity getCurrentActivity() {
        return mCurrentActivity;
    }

    /**
     * 获取栈顶的Activity
     *
     * @return 栈顶的Activity
     */
    public Activity getLastActivity() {
        return mLastActivity;
    }

    /**
     * 获取所有的Activities
     *
     * @return Activities
     */
    public List<Activity> getActivities() {
        return mActivities;
    }

    private void recordActivityTrace(Activity activity, String lifeState) {
        sActivityLifeTrace.add(getActivityInfo(activity, lifeState));
        if (sActivityLifeTrace.size() > ConstantUtils.TEN << 1) {
            sActivityLifeTrace.remove(0);
        }
    }

    private String getFormattedTime() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        return simpleDateFormat.format(new Date());
    }

    private String getActivityInfo(Activity activity, String lifeState) {
        StringBuilder builder = new StringBuilder("\t");

        builder.append(getFormattedTime()).append("  ").append(activity.getClass().getSimpleName());

        builder.append(":{").append(lifeState);
        try {
            Field f = Activity.class.getDeclaredField("mToken");
            f.setAccessible(true);
            Object token = f.get(activity);
            builder.append(", token=").append(token.toString());
            if (StringUtils.equal(lifeState, "crash")) {
                builder.append(",action=").append(activity.getIntent());
                builder.append(",data=").append(activity.getIntent().getData());


                Bundle bundle = activity.getIntent().getExtras();
                if (bundle != null) {
                    Set<String> keys = bundle.keySet();
                    Iterator<String> it = keys.iterator();
                    builder.append(",extra=");
                    while (it.hasNext()) {
                        String key = it.next();
                        builder.append(key).append(",").append(bundle.get(key)).append("&");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (activity instanceof BaseActivity) {
            BaseActivity baseActivity = (BaseActivity) activity;
        }
        builder.append("}\r\n");
        return builder.toString();
    }

    /**
     * @return 最近打开的activity信息， 名称，token，topFragment
     */
    public String dumpRecentActivitiesInfo() {
        StringBuilder builder = new StringBuilder();
        for (String trace : sActivityLifeTrace) {
            builder.append(trace);
        }

        if (mCurrentActivity != null) {
            builder.append(getActivityInfo(mCurrentActivity, "crash"));
        }

        return builder.toString();
    }

    /**
     * @param activity  activity
     * @param lifeState lifeState
     */
    public void appendActivityTraceLog(Activity activity, String lifeState) {
        recordActivityTrace(activity, lifeState);
    }

    /**
     * 判断某个activity是否是当前activity
     *
     * @param activity activity
     * @return 是不是当前显示的activity
     */
    public boolean isCurrentActivity(Activity activity) {
        return activity != null && activity == getCurrentActivity();
    }
}
