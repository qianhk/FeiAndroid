package njnu.kai.framework;

/**
 * @author kai
 * @version 1.0.0
 *
 */
public interface IView {
}
