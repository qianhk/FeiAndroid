package njnu.kai.framework;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import njnu.kai.AppConfig;
import njnu.kai.framework.Immersive.ImmersiveHelper;
import njnu.kai.framework.Immersive.ImmersiveObserver;
import njnu.kai.framework.Immersive.ImmersiveOnApplyStyleListener;
import njnu.kai.framework.Immersive.ImmersiveOnObserverInitedListener;
import njnu.kai.utils.DisplayUtils;
import njnu.kai.utils.LogUtils;

/**
 * @author kai
 * @version 1.0.0
 */
public class WrapFragmentActivity extends BaseActivity implements ImmersiveOnApplyStyleListener, ImmersiveOnObserverInitedListener {

    /**
     * 嵌套的fragment完整class name
     */
    public static final String KEY_CLASS_NAME = "key_class_name";
    public static final String KEY_APPLY_STATUS_BAR_STYLE = "key_apply_status_bar_style";
    public static final String KEY_APPLY_NAVIGATION_BAR_STYLE = "key_apply_navigation_bar_style";

    private static final String TAG = "WrapFragmentActivity";

    private BaseFragment mFragment;

    private ImmersiveHelper mImmersiveHelper;

    /**
     * @return 包装的是哪个fragment
     */
    protected Class<? extends BaseFragment> wrapFragmentClass() {
        return null;
    }

    protected int onPrepareActivityTheme(int oldTheme) {
        return oldTheme;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int themeId = onPrepareActivityTheme(AppConfig.ACTIVITY_THEME_ID);
        if (themeId != 0) {
            setTheme(themeId);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.common_activity_empty_with_statusbar);

        Class<?> clazz = null;

        final Intent intent = getIntent();
        if (intent.hasExtra(KEY_CLASS_NAME)) {
            try {
                clazz = Class.forName(intent.getStringExtra(KEY_CLASS_NAME));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (clazz == null) {
            clazz = wrapFragmentClass();
        }
        if (clazz != null) {
            try {
                BaseFragment fragment = (BaseFragment) clazz.newInstance();
                Bundle argument = getIntent().getExtras();
                if (argument == null) {
                    argument = new Bundle();
                }
                fragment.setArguments(argument);

                int replaceId = R.id.layout_activity_container;
//                View contentView = findViewById(android.R.id.content);
//                if (contentView != null) {
////                    contentView.setPadding(0, DisplayUtils.dp2px(60), 0, 0);
//                    replaceId = android.R.id.content;
//                }
                View containerView = findViewById(R.id.layout_activity_container);
                PageBackground.setPageBackground(this, (View) containerView.getParent());
                getSupportFragmentManager().beginTransaction().replace(replaceId, fragment).commitAllowingStateLoss();

                mFragment = fragment;
            } catch (Exception e) {
                e.printStackTrace();
                LogUtils.e(TAG, "Error: 嵌套的class必须是BaseFragment");
//                finish();
            }
        } else {
            LogUtils.e(TAG, "Error: 请设置KEY_CLASS_NAME或实现wrap函数");
//            finish();
        }
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mImmersiveHelper = new ImmersiveHelper(this);
        mImmersiveHelper.applyStyle(this, this);
    }


    @Override
    public void onInitImmersiveObserver(ImmersiveObserver immersiveObserver) {
        View statusBarBkg = findViewById(R.id.status_bar_background);
        View navBarBkg = findViewById(R.id.navigate_bar_background);
        immersiveObserver.setImmersiveView(null, null
                , statusBarBkg, navBarBkg);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mImmersiveHelper.onDestroyView();
    }

    protected BaseFragment getWrapFragment() {
        return mFragment;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mFragment != null) {
            mFragment.onActivityResult(requestCode & 0xffff, resultCode, data);
        }
    }

    public static void launch(Activity activity, Class fragmentClazz) {
        Intent intent = new Intent(activity, WrapFragmentActivity.class);
        intent.putExtra(KEY_CLASS_NAME, fragmentClazz.getCanonicalName());
        activity.startActivity(intent);
    }

    @Override
    public boolean needApplyStatusBarStyle() {
        return getIntent().getBooleanExtra(KEY_APPLY_STATUS_BAR_STYLE, false);
    }

    @Override
    public boolean needApplyNavigationBarStyle() {
        return getIntent().getBooleanExtra(KEY_APPLY_NAVIGATION_BAR_STYLE, false);
    }
}
