package njnu.kai.framework;

import android.content.Context;
import android.view.View;

public class PageBackground {
    /**
     * setPageBackground
     *
     * @param context context
     * @param view    view
     */
    public static void setPageBackground(Context context, View view) {
        if (view == null || context == null) {
            return;
        }
        view.setBackgroundResource(R.color.normal_background);
    }
}
